from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
import sys
from PyQt5.uic import loadUiType
import mysql.connector

# Establish database connection
conn = mysql.connector.connect(
    user='root',
    password='',
    database='adzu',
    host='localhost'
)
cursor = conn.cursor()

ui, _ = loadUiType(r'C:\Users\cielo\Downloads\current project\sched.ui')

class MainApp(QMainWindow, ui):
    def __init__(self):  
        QMainWindow.__init__(self)
        self.setupUi(self)
        
        self.tabWidget.setCurrentIndex(0)
        self.tabWidget.tabBar().setVisible(False)
        self.menubar.setVisible(False)
        self.m6.triggered.connect(self.view_schedules)
        self.b3.clicked.connect(self.save_schedule_change)
        self.cb3.currentTextChanged.connect(self.display_timetable)
        
    def view_schedules(self):
        self.tabWidget.setCurrentIndex(5)
        self.setup_room_schedule_tab()
        
    def populate_combobox(self, combobox, query, error_message):
        try:
            cursor.execute(query)
            items = [row[0] for row in cursor.fetchall()]
            combobox.clear()
            combobox.addItems(items)
        except mysql.connector.Error as err:
            QMessageBox.warning(self, "Database Error", f"{error_message}: {err}")
            
    def setup_room_schedule_tab(self):
        query = "SELECT DISTINCT room_name FROM timetable"
        self.populate_combobox(self.cb3, query, "Error fetching room names")
        
        
    def display_timetable(self):
        selected_room = self.cb3.currentText()
        if not selected_room:
            return

        timeslots = ['8:00-9:20', '9:30-10:50', '11:00-12:20', '12:30-1:50', '2:00-3:20', '3:30-4:30', '4:30-5:50', '6:00-7:20']
        days_of_week = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
        query = """
            SELECT day, timeslot, course_assigned
            FROM timetable
            WHERE room_name = %s
        """
        cursor.execute(query, (selected_room,))
        schedule_data = cursor.fetchall()

        # Set up the table dimensions
        self.timetable.setRowCount(len(days_of_week))
        self.timetable.setColumnCount(len(timeslots))  # +1 for the Day column
        self.timetable.setHorizontalHeaderLabels(timeslots)
        self.timetable.setVerticalHeaderLabels(days_of_week)

        # Populate the table with data
        for day, timeslot, course_assigned in schedule_data:
            if day in days_of_week and timeslot in timeslots:
                day_row = days_of_week.index(day)
                timeslot_col = timeslots.index(timeslot) + 1  # +1 to account for the Day column
                self.timetable.setItem(day_row, timeslot_col, QTableWidgetItem(course_assigned))

        self.timetable.setDragEnabled(True)
        self.timetable.setAcceptDrops(True)
        self.timetable.setDropIndicatorShown(True)
        self.timetable.viewport().setAcceptDrops(True)
        self.timetable.setDragDropMode(QAbstractItemView.InternalMove)

    def dropEvent(self, event):
        # Get target index
        target_index = self.timetable.indexAt(event.pos())
        mime_data = event.mimeData()
        source_index = self.timetable.currentIndex()

        if not source_index.isValid() or not target_index.isValid():
            event.ignore()
            return

        source_item = self.timetable.item(source_index.row(), source_index.column())
        target_item = self.timetable.item(target_index.row(), target_index.column())

        # Make sure we have a valid source item to move
        if not source_item or not source_item.text():
            event.ignore()
            return

        source_text = source_item.text()
        target_text = target_item.text()

        # Check if the drop is valid (availability check)
        is_available = self.check_timeslot_availability(target_index.row(), target_index.column(), source_text)

        if is_available:
            # Swap the cell values
            source_item.setText(target_text)
            target_item.setText(source_text)

            # Update the database
            self.save_schedule_change(
                source_index.row(), source_index.column(),
                target_index.row(), target_index.column(),
                source_text, target_text
            )

            # Set background color to green (valid swap)
            target_item.setBackground(QColor(0, 255, 0))  # Green
            QTimer.singleShot(2000, lambda: target_item.setBackground(QColor(255, 255, 255)))  # Reset color after 2 seconds
        else:
            # Invalid drop, set background to red
            target_item.setBackground(QColor(255, 0, 0))  # Red
            QTimer.singleShot(2000, lambda: target_item.setBackground(QColor(255, 255, 255)))  # Reset color after 2 seconds
            QMessageBox.warning(self, "Invalid Drop", "The selected timeslot is not available for this program.")

        event.accept()

    def save_schedule_change(self, source_row, source_col, target_row, target_col, source_text, target_text):
        query = """
            UPDATE timetable
            SET course_assigned = CASE
                WHEN day = %s AND timeslot = %s THEN %s
                WHEN day = %s AND timeslot = %s THEN %s
            END
            WHERE (day = %s AND timeslot = %s)
            OR (day = %s AND timeslot = %s)
        """
        days_of_week = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
        timeslots = ['8:00-9:20', '9:30-10:50', '11:00-12:20', '12:30-1:50', '2:00-3:20', '3:30-4:30', '4:30-5:50', '6:00-7:20']

        query_params = (
            days_of_week[source_row], timeslots[source_col - 1], target_text,
            days_of_week[target_row], timeslots[target_col - 1], source_text,
            days_of_week[source_row], timeslots[source_col - 1],
            days_of_week[target_row], timeslots[target_col - 1]
        )
        try:
            cursor.execute(query, query_params)
            conn.commit()
        except mysql.connector.Error as err:
            QMessageBox.warning(self, "Database Error", f"Error saving schedule change: {err}")  
            
    def check_timeslot_availability(self, target_row, target_col, program):
        cursor.execute(f"SELECT program_year_section FROM timetable WHERE course_assigned = '{program}'")
        x = cursor.fetchall()
        if not x:
            return True  # If no record found, it's available
        program_year_sections = x[0][0]  # Fetch the first result and the program_year_section
        program_year_sections_list = program_year_sections.split(',')  # Split by commas if there are multiple sections

        # Check availability for each program_year_section
        days_of_week = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday','Saturday']
        timeslots = ['8:00-9:20', '9:30-10:50', '11:00-12:20', '12:30-1:50', '2:00-3:20', '3:30-4:30', '4:30-5:50', '6:00-7:20']

        target_day = days_of_week[target_row]
        target_timeslot = timeslots[target_col - 1]  # Adjust column index for timeslot

        # If still available
        query = """
            SELECT 1
            FROM student_schedule
            WHERE room_name = %s
            AND day = %s
            AND timeslot = %s
            AND program_year_section = %s
        """
        cursor.execute(query, (self.cb3.currentText(), target_day, target_timeslot, program_year_sections_list[0]))
        result = cursor.fetchone()

        if result:
            return True  #Available timeslot
        return False

    

def main():
    app = QApplication(sys.argv)
    window = MainApp()
    window.show()
    app.exec_()

if __name__ == '__main__':
    main()