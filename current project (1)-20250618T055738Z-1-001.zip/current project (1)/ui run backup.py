from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
import sys
from PyQt5.uic import loadUiType
import mysql.connector
import subprocess

# Establish database connection
conn = mysql.connector.connect(
    user='root',
    password='',
    database='adzu',
    host='localhost'
)
cursor = conn.cursor()

ui, _ = loadUiType(r'C:\Users\cielo\Downloads\current project\sched.ui')

# Worker thread to run the script
class Worker(QThread):
    progress = pyqtSignal(int)  # Signal to update the progress bar
    finished = pyqtSignal()  # Signal when all scripts are finished

    def __init__(self, scripts):
        super().__init__()
        self.scripts = scripts  # List of scripts to run

    def run(self):
        total_scripts = len(self.scripts)
        for i, script in enumerate(self.scripts):
            print(f"Running script {i + 1}: {script}")
            process = subprocess.Popen(
                ["python", script],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )

            # Capture the output and errors from the script
            stdout, stderr = process.communicate()  # This will wait for the process to finish

            if stderr:
                print(f"Error running {script}: {stderr.decode()}")  # Log error
            else:
                print(f"Output from {script}: {stdout.decode()}")  # Log output

            # Wait for the script to finish and monitor progress
            process.wait()  # Wait for the current script to finish
            progress_value = int(((i + 1) / total_scripts) * 100)
            self.progress.emit(progress_value)  # Emit progress signal

        self.finished.emit()


class MainApp(QMainWindow, ui):
    def __init__(self):  
        QMainWindow.__init__(self)
        self.setupUi(self)
        
        self.tabWidget.setCurrentIndex(0)
        self.tabWidget.tabBar().setVisible(False)
        self.menubar.setVisible(False)
        self.b1.clicked.connect(self.login)
        self.m1.triggered.connect(self.department_programs)
        self.m2.triggered.connect(self.student_section)
        self.m5.triggered.connect(self.create_schedule)
        self.m6.triggered.connect(self.view_schedules)
        self.b3.clicked.connect(self.save_schedule_change)
        self.m3.triggered.connect(self.avail_rooms)

        # Initialize progress bar and button
        self.progress_bar = self.p1  # Use the p1 progress bar from the UI

        # Populate the department combobox
        self.populate_departments()
        self.populate_departments2()
        self.setup_room_schedule_tab()
        self.populate_type()

        # Connect combobox selection to show_programs
        self.cb1.currentTextChanged.connect(self.show_programs)
        self.cb2.currentTextChanged.connect(self.show_programs2)
        self.cb3.currentTextChanged.connect(self.display_timetable)
        self.cb4.currentTextChanged.connect(self.show_roomlist)

    def run_scripts(self):
        self.p1.setVisible(True)
        self.p1.setValue(0)
        scripts = [
            r"C:\Users\cielo\Downloads\current project\(1) SECTIONING.py",  # Replace with the path to your script 1
            r"C:\Users\cielo\Downloads\current project\(2) GENERATE ROOM AND SECTION SCHEDS.py",  # Replace with the path to your script 2
            r"C:\Users\cielo\Downloads\current project\(3) COURSE DISTRIBUTION.py",  # Replace with the path to your script 3
            r"C:\Users\cielo\Downloads\current project\(4) LAB_LEC ASSIGNMENT.py",  # Replace with the path to your script 4
            r"C:\Users\cielo\Downloads\current project\(5) room timetabless.py",  # Replace with the path to your script 5
        ]
        self.worker = Worker(scripts)
        self.worker.progress.connect(self.update_progress)  # Connect progress signal
        self.worker.finished.connect(self.on_finished)  # Connect finished signal
        self.worker.start()  # Start the worker thread to run the scripts

    def update_progress(self, value):
        # Update the progress bar with the new value
        self.progress_bar.setValue(value)

    def on_finished(self):
        # Show a success message when the scripts are finished
        result = QMessageBox.information(self, 'Schedule Optimizer', 'Schedules Created Successfully')
        if result == QMessageBox.Ok:
            self.view_schedules()
        self.b4.setEnabled(True)  # Re-enable the button after execution
        self.p1.setVisible(False)

    def on_start(self):
        # Disable the run button while scripts are running
        self.b4.setEnabled(False)

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Return or event.key() == Qt.Key_Enter:
            self.login()

    # Login function
    def login(self):
        un = self.a1.text()
        pw = self.a2.text()
        if (un == 'admin' and pw == 'registrar'):
            self.menubar.setVisible(True)
            self.tabWidget.setCurrentIndex(1)
        else:
            QMessageBox.information(self, 'Schedule Optimizer', 'Invalid login')

    def avail_rooms(self):
        self.tabWidget.setCurrentIndex(6)
        self.populate_type()
        self.show_roomlist()
        self.w2.setVisible(False)
        self.t5.setVisible(False)

    def student_section(self):
        self.tabWidget.setCurrentIndex(3)
        self.populate_departments2()
        self.show_programs2()
        self.t2.setVisible(False)

    def create_schedule(self):
        self.tabWidget.setCurrentIndex(4)
        self.forecast_freshmen()
        self.b2.clicked.connect(self.save_forecasted_freshmen)
        self.p1.setVisible(False) 
        self.b4.clicked.connect(self.run_scripts) #add here the progress bar and run
        
    def department_programs(self):
        self.tabWidget.setCurrentIndex(2)
        self.populate_departments()
        self.show_programs()
        self.t1.setVisible(False)
        self.w1.setVisible(False)
        
    def view_schedules(self):
        self.tabWidget.setCurrentIndex(5)
        self.setup_room_schedule_tab()
        
        
    def populate_combobox(self, combobox, query, error_message):
        try:
            cursor.execute(query)
            items = [row[0] for row in cursor.fetchall()]
            combobox.clear()
            combobox.addItems(items)
        except mysql.connector.Error as err:
            QMessageBox.warning(self, "Database Error", f"{error_message}: {err}")
            
    def populate_list_widget(self, list_widget, query, params=(), error_message=""):
        try:
            cursor.execute(query, params)
            items = [row[0] for row in cursor.fetchall()]
            list_widget.clear()  # Clear the existing items in the list
            for item in items:
                list_widget.addItem(QListWidgetItem(item))  # Add each item to the QListWidget
        except mysql.connector.Error as err:
            QMessageBox.warning(self, "Database Error", f"{error_message}: {err}")
            
            
    def get_sections(self, item):
        selected_program = item.text()  # Get the clicked program from the list item

        # SQL query to fetch the number of sections per year for the selected program
        query = """
            SELECT year, COUNT(section) AS num_sections
            FROM student_sections
            WHERE program = %s
            GROUP BY year
            ORDER BY year
        """

        try:
            # Execute the query
            cursor.execute(query, (selected_program,))
            sections_data = cursor.fetchall()

            # Prepare data for the table
            year_data = {1: 0, 2: 0, 3: 0, 4: 0}  # Initialize years 1 to 4 with 0 sections
            total_sections = 0

            for year, num_sections in sections_data:
                year_data[year] = num_sections
                total_sections += num_sections

            # Populate the table (t2)
            self.t2.setColumnCount(2)
            self.t2.setHorizontalHeaderLabels(["Year", "Number of Sections"])
            self.t2.setRowCount(5)  # 4 years + 1 row for the total

            # Populate rows for 1st, 2nd, 3rd, and 4th year
            for i, year in enumerate(range(1, 5)):
                self.t2.setItem(i, 0, QTableWidgetItem(f"{year}"))
                self.t2.setItem(i, 1, QTableWidgetItem(str(year_data[year])))

            # Add the Total row
            self.t2.setItem(4, 0, QTableWidgetItem("Total"))
            self.t2.setItem(4, 1, QTableWidgetItem(str(total_sections)))

            # Make the table visible
            self.t2.setVisible(True)

        except mysql.connector.Error as err:
            QMessageBox.warning(
                self, "Database Error", f"Error fetching sections for {selected_program}: {err}"
            )

            
    def populate_departments(self):
        query = "SELECT DISTINCT department FROM department_data"
        self.populate_combobox(self.cb1, query, "Error fetching departments")
        
    def populate_type(self):
        query = "SELECT DISTINCT type FROM room_schedule"
        self.populate_combobox(self.cb4, query, "Error fetching departments")
        
    def populate_departments2(self):
        query = "SELECT DISTINCT department FROM department_data"
        self.populate_combobox(self.cb2, query, "Error fetching departments")
        
    def show_roomlist(self):
        selected_type = self.cb4.currentText()

        if not selected_type:
            return

        query = """
            SELECT DISTINCT room
            FROM room_schedule 
            WHERE type = %s
        """
        self.populate_list_widget(
            list_widget=self.l3,
            query=query,
            params=(selected_type,),
            error_message="Error fetching programs"
        )

        # Connect the itemClicked signal to display the syllabus
        self.l3.itemClicked.connect(self.get_roomtimeslots)
        
    def get_roomtimeslots(self, item):
        selected_room = item.text()
        try:
            # Fetch syllabus data from the table corresponding to the selected program
            query = f"""
                SELECT day, timeslot, size
                FROM room_schedule WHERE room = '{selected_room}'
            """
            cursor.execute(query)
            room_data = cursor.fetchall()

            # Set the number of columns in the QTableWidget
            self.t5.setColumnCount(3)  # Adjust column count to match the query
            self.t5.setHorizontalHeaderLabels(['Day', 'Timeslot','Size'])  # Set column headers

            # Clear the QTableWidget
            self.t5.setRowCount(0)

            # Populate the QTableWidget with syllabus data
            for row_number, row_data in enumerate(room_data):
                self.t5.insertRow(row_number)
                for column_number, data in enumerate(row_data):
                    self.t5.setItem(row_number, column_number, QTableWidgetItem(str(data)))

            # Make the table visible after populating it
            self.w2.setVisible(True)
            self.t5.setVisible(True)

        except mysql.connector.Error as err:
            QMessageBox.warning(self, "Database Error", f"Error fetching syllabus from {selected_room}: {err}")
        
        
    # Fetch and display programs for the selected department
    def show_programs2(self):
        selected_department = self.cb2.currentText()

        if not selected_department:
            return

        query = """
            SELECT DISTINCT program 
            FROM department_data 
            WHERE department = %s
        """
        self.populate_list_widget(
            list_widget=self.l2,
            query=query,
            params=(selected_department,),
            error_message="Error fetching programs"
        )

        # Connect the itemClicked signal to display the syllabus
        self.l2.itemClicked.connect(self.get_sections)
        
    def show_programs(self):
        selected_department = self.cb1.currentText()

        if not selected_department:
            return

        query = """
            SELECT DISTINCT program 
            FROM department_data 
            WHERE department = %s
        """
        self.populate_list_widget(
            list_widget=self.l1,
            query=query,
            params=(selected_department,),
            error_message="Error fetching programs"
        )

        # Connect the itemClicked signal to display the syllabus
        self.l1.itemClicked.connect(self.display_syllabus)


    def display_syllabus(self, item):
        selected_program = item.text()
        
        # Dictionary to map program names to table names
        programs = {
            'AEET': 'aeet',
            'BACOMM': 'ba_comm',
            'BAELS': 'ba_els',
            'BAINDIS': 'ba_indis',
            'BAINTS': 'ba_ints',
            'BAPHILO': 'ba_philo',
            'BECED': 'beced',
            'BEED': 'beed',
            'BPED': 'bped',
            'BSAC': 'bsac_abm', 
            'BSACNON': 'bsac_nonabm',
            'BSBA': 'bsba_entrep', 
            'BSBAFM': 'bsba_fm',
            'BSBAMM': 'bsba_mm',
            'BSBIO': 'bsbio', 
            'BSBIOBR': 'bsbio_br',
            'BSBIOEB': 'bsbio_eb',
            'BSBME': 'bsbme',
            'BSCE': 'bsce_cm',
            'BSCEGEO': 'bsce_geo',
            'BSCES': 'bsce_s',
            'BSCPE': 'bscpe',
            'BSCS': 'bscs',
            'BSECE': 'bsece',
            'BSED': 'bsed_english',
            'BSEDFIL': 'bsed_filipino',
            'BSEDMATH': 'bsed_math',
            'BSEDSCI': 'bsed_science',
            'BSED_SOCS': 'bsed_socstud',
            'BSEDVAL': 'bsed_values',
            'BSIT': 'bsit',
            'BSLM': 'bslm',
            'BSMATH': 'bsmath',
            'BSMA': 'bsma_abm',
            'BSMANON': 'bsma_nonabm',
            'BSN': 'bsn',
            'BSNMCA': 'bsnmca',
            'BSOA': 'bsoa',    
            'BSPSY': 'bspsyc'
        }

        table_name = programs.get(selected_program)

        if not table_name:
            QMessageBox.warning(self, "Error", f"No table found for program: {selected_program}")
            return

        try:
            query = f"""
                SELECT year, sem, course_code, course_desc, units, type
                FROM {table_name}
            """
            cursor.execute(query)
            syllabus_data = cursor.fetchall()

            self.t1.setColumnCount(6)  
            self.t1.setHorizontalHeaderLabels(['Year', 'Semester', 'Course Code', 'Course Description', 'Units', 'Type'])  # Set column headers

            # Clear the QTableWidget
            self.t1.setRowCount(0)

            for row_number, row_data in enumerate(syllabus_data):
                self.t1.insertRow(row_number)
                for column_number, data in enumerate(row_data):
                    self.t1.setItem(row_number, column_number, QTableWidgetItem(str(data)))

            self.w1.setVisible(True)
            self.t1.setVisible(True)

        except mysql.connector.Error as err:
            QMessageBox.warning(self, "Database Error", f"Error fetching syllabus from {table_name}: {err}")
            
            
    def forecast_freshmen(self):
        query = "SELECT DISTINCT program FROM department_data"

        try:
            cursor.execute(query)
            programs = [row[0] for row in cursor.fetchall()]

            self.t3.setColumnCount(2)
            self.t3.setHorizontalHeaderLabels(["Program", "Projected Freshmen"])
            self.t3.setRowCount(len(programs))

            for row, program in enumerate(programs):
                self.t3.setItem(row, 0, QTableWidgetItem(program))  
                self.t3.setItem(row, 1, QTableWidgetItem("")) 

            self.t3.resizeColumnsToContents()
            self.t3.setEditTriggers(QAbstractItemView.AllEditTriggers)

        except mysql.connector.Error as err:
            QMessageBox.warning(self, "Database Error", f"Error fetching programs: {err}")

    def save_forecasted_freshmen(self):
        row_count = self.t3.rowCount()
        data_to_save = []

        for row in range(row_count):
            program_item = self.t3.item(row, 0)
            projection_item = self.t3.item(row, 1)

            if program_item and projection_item:
                program = program_item.text()
                projection = projection_item.text()

                # Validate input 
                if not projection.isdigit():
                    QMessageBox.warning(self, "Input Error", f"Invalid number for {program}.")
                    return
                data_to_save.append((program, int(projection)))

        try:
            # Save the data to the database
            query = """
                INSERT INTO forecasted_freshmen (program, projected_number)
                VALUES (%s, %s)
                ON DUPLICATE KEY UPDATE projected_number = VALUES(projected_number)
            """
            cursor.executemany(query, data_to_save)
            conn.commit()
            QMessageBox.information(self, "Schedule Optimizer", "Saved successfully!")

        except mysql.connector.Error as err:
            QMessageBox.warning(self, "Database Error", f"Error saving forecast: {err}")
      
      
      
      
    #edit not working green red    
    def setup_room_schedule_tab(self):
        query = "SELECT DISTINCT room_name FROM timetable"
        self.populate_combobox(self.cb3, query, "Error fetching room names")
        
        
        
    def display_timetable(self):
        selected_room = self.cb3.currentText()
        if not selected_room:
            return

        timeslots = ['8:00-9:20', '9:30-10:50', '11:00-12:20', '12:30-1:50', '2:00-3:20', '3:30-4:30', '4:30-5:50', '6:00-7:20']
        days_of_week = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
        query = """
            SELECT day, timeslot, course_assigned
            FROM timetable
            WHERE room_name = %s
        """
        cursor.execute(query, (selected_room,))
        schedule_data = cursor.fetchall()

        # Set up the table dimensions
        self.timetable.setRowCount(len(days_of_week))
        self.timetable.setColumnCount(len(timeslots)) 
        self.timetable.setHorizontalHeaderLabels(timeslots)
        self.timetable.setVerticalHeaderLabels(days_of_week)

        # Populate the table with data
        for day, timeslot, course_assigned in schedule_data:
            if day in days_of_week and timeslot in timeslots:
                day_row = days_of_week.index(day)
                timeslot_col = timeslots.index(timeslot) 
                self.timetable.setItem(day_row, timeslot_col, QTableWidgetItem(course_assigned))

        self.timetable.setDragEnabled(True)
        self.timetable.setAcceptDrops(True)
        self.timetable.setDropIndicatorShown(True)
        self.timetable.viewport().setAcceptDrops(True)
        self.timetable.setDragDropMode(QAbstractItemView.InternalMove)

    def dropEvent(self, event):
        # Get target index
        target_index = self.timetable.indexAt(event.pos())
        mime_data = event.mimeData()
        source_index = self.timetable.currentIndex()

        if not source_index.isValid() or not target_index.isValid():
            event.ignore()
            return

        source_item = self.timetable.item(source_index.row(), source_index.column())
        target_item = self.timetable.item(target_index.row(), target_index.column())

        # Make sure we have a valid source item to move
        if not source_item or not source_item.text():
            event.ignore()
            return

        source_text = source_item.text()
        target_text = target_item.text()

        # Check if the drop is valid (availability check)
        is_available = self.check_timeslot_availability(target_index.row(), target_index.column(), source_text)

        if is_available:
            # Swap the cell values
            source_item.setText(target_text)
            target_item.setText(source_text)

            # Update the database
            self.save_schedule_change(
                source_index.row(), source_index.column(),
                target_index.row(), target_index.column(),
                source_text, target_text
            )

            # Set background color to green (valid swap)
            target_item.setBackground(QColor(0, 255, 0))  # Green
            QTimer.singleShot(2000, lambda: target_item.setBackground(QColor(255, 255, 255)))  
        else:
            # Invalid drop, set background to red
            target_item.setBackground(QColor(255, 0, 0))  # Red
            QTimer.singleShot(2000, lambda: target_item.setBackground(QColor(255, 255, 255))) 
            QMessageBox.warning(self, "Invalid Drop", "The selected timeslot is not available for this program.")

        event.accept()

    def save_schedule_change(self, source_row, source_col, target_row, target_col, source_text, target_text):
        query = """
            UPDATE timetable
            SET course_assigned = CASE
                WHEN day = %s AND timeslot = %s THEN %s
                WHEN day = %s AND timeslot = %s THEN %s
            END
            WHERE (day = %s AND timeslot = %s)
            OR (day = %s AND timeslot = %s)
        """
        days_of_week = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
        timeslots = ['8:00-9:20', '9:30-10:50', '11:00-12:20', '12:30-1:50', '2:00-3:20', '3:30-4:30', '4:30-5:50', '6:00-7:20']

        query_params = (
            days_of_week[source_row], timeslots[source_col - 1], target_text,
            days_of_week[target_row], timeslots[target_col - 1], source_text,
            days_of_week[source_row], timeslots[source_col - 1],
            days_of_week[target_row], timeslots[target_col - 1]
        )
        try:
            cursor.execute(query, query_params)
            conn.commit()
        except mysql.connector.Error as err:
            QMessageBox.warning(self, "Database Error", f"Error saving schedule change: {err}")  
            
    def check_timeslot_availability(self, target_row, target_col, program):
        cursor.execute(f"SELECT program_year_section FROM timetable WHERE course_assigned = '{program}'")
        x = cursor.fetchall()
        if not x:
            return True  # If no record found, it's available
        program_year_sections = x[0][0]  # Fetch the first result and the program_year_section
        program_year_sections_list = program_year_sections.split(',')  # Split by commas if there are multiple sections

        # Check availability for each program_year_section
        days_of_week = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday','Saturday']
        timeslots = ['8:00-9:20', '9:30-10:50', '11:00-12:20', '12:30-1:50', '2:00-3:20', '3:30-4:30', '4:30-5:50', '6:00-7:20']

        target_day = days_of_week[target_row]
        target_timeslot = timeslots[target_col - 1]  # Adjust column index for timeslot

        # If still available
        query = """
            SELECT 1
            FROM student_schedule
            WHERE room_name = %s
            AND day = %s
            AND timeslot = %s
            AND program_year_section = %s
        """
        cursor.execute(query, (self.cb3.currentText(), target_day, target_timeslot, program_year_sections_list[0]))
        result = cursor.fetchone()

        if result:
            return True  #Available timeslot
        return False
    
    

def main():
    app = QApplication(sys.argv)
    window = MainApp()
    window.show()
    app.exec_()

if __name__ == '__main__':
    main()
