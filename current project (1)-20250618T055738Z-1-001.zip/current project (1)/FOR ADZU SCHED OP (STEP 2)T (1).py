import mysql.connector
import math

conn = mysql.connector.connect(
    user='root',
    password='',
    database='school7',
    host='localhost'
)
cursor = conn.cursor()

cursor.execute("DELETE FROM assignment")
cursor.execute("DELETE FROM room_schedule")
cursor.execute("DELETE FROM student_schedule")
cursor.execute("UPDATE main SET SUBJECT = 'GE-ELECT-KF' WHERE SUBJECT LIKE '%KF%'")
cursor.execute("UPDATE main SET SUBJECT = 'GE-ELECT-LM' WHERE SUBJECT LIKE '%ELECT_LM%' OR SUBJECT LIKE '%ELECT-LM%'")
cursor.execute("UPDATE main SET SUBJECT = 'PATHFIT1' WHERE SUBJECT LIKE '%PATHFIT1%' OR SUBJECT LIKE '%PATHFIT 1%'")
cursor.execute("UPDATE main SET SUBJECT = 'NSTP1' WHERE SUBJECT LIKE '%NSTP101%'")
cursor.execute("DELETE FROM main WHERE SUBJECT LIKE '%OJT%' OR SUBJECT LIKE '%RLE%' OR SUBJECT_DESC LIKE '%Internship%'")
cursor.execute("DROP TABLE duplicate")
cursor.execute("CREATE TABLE duplicate AS SELECT * FROM main")
conn.commit()

print("here")
def get_room_available(enrolled):
    if enrolled <= 10:
        small_query="SELECT DISTINCT Room_Name FROM room_schedule WHERE Room_Category = 'Small_room'AND Timeslot IS NOT NULL"
        cursor.execute(small_query)
        room_available = cursor.fetchall()
    elif enrolled <= 20:
        medium_query="SELECT DISTINCT Room_Name FROM room_schedule WHERE Room_Category = 'Medium_room'AND Timeslot IS NOT NULL"
        cursor.execute(medium_query)
        room_available = cursor.fetchall()
    elif enrolled <= 45:
        big_query="SELECT DISTINCT Room_Name FROM room_schedule WHERE Room_Category = 'Big_room'AND Timeslot IS NOT NULL"
        cursor.execute(big_query)
        room_available = cursor.fetchall()
        
    room_schedule = [room[0] for room in room_available]
    return room_schedule

Rooms = {
        'Small_room': ['LRC303A','S304', 'S305', 'S404'],
        'Medium_room': ['LRC305', 'LRC311'],
        'Big_room': ['XH105', 'XH201', 'XH202', 'XH203', 'XH204', 'XH301','XH302','BC203', 'BC304', 
                    'BC305', 'BC307', 'BC308', 'BC401', 'BC402', 'BC403', 'BC405', 'BC406', 'XH303', 'XH304',
                    'XH305', 'XH401', 'XH402', 'XH403', 'XH404', 'XH405', 'BC407',
                    'BC408', 'C108', 'C110','C206','C209', 'C311', 'C403', 'S301', 'S302', 'S303', 'S401',
                    'S402', 'S403']
    }

room_schedule_data = []
room_day_available = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']

def get_room_time():
    room_timeslot = ['8:00-9:20', '9:30-10:50', '11:00-12:20', '12:30-1:50', '2:00-3:20', '3:30-4:30', '4:30-5:50', '6:00-7:20']
    return room_timeslot
room_timeslot = get_room_time()
for room_category, room_list in Rooms.items():
    for room_name in room_list:
        for day in room_day_available:
                for time in room_timeslot:
                    query = "INSERT INTO room_schedule (Room_Category, Room_Name, Day, Timeslot) VALUES (%s, %s, %s, %s)"
                    values = (room_category, room_name, day, time)
                    cursor.execute(query, values)
conn.commit()

b = ['MPCC1A','MPCC1B','MPCC1C','MPCC1D']
room_timeslot = ['8:00-10:00','10:00-12:00','1:00-3:00']
for room_name in b:
    for day in room_day_available:
        for time in room_timeslot:
            room_category = 'GYM'
            query = "INSERT INTO room_schedule (Room_Category, Room_Name, Day, Timeslot) VALUES (%s, %s, %s, %s)"
            values = (room_category, room_name, day, time)
            cursor.execute(query, values)
conn.commit()

a = ['C308','C310']
room_timeslot = ['8:00-9:20', '9:30-10:50', '11:00-12:20', '12:30-1:50', '2:00-3:20', '3:30-4:30', '4:30-5:50', '6:00-7:20']
for room_name in a:
    for day in room_day_available:
        for time in room_timeslot:
            room_category = 'Nursing Lab'
            query = "INSERT INTO room_schedule (Room_Category, Room_Name, Day, Timeslot) VALUES (%s, %s, %s, %s)"
            values = (room_category, room_name, day, time)
            cursor.execute(query, values)
conn.commit()

student_query = "SELECT DISTINCT ID, COURSE, YEAR FROM main"
cursor.execute(student_query)
students_data = cursor.fetchall()
cursor.execute("SELECT COUNT(DISTINCT ID) FROM main")
v = cursor.fetchall()
print(f"eto count: {v}")
for row in students_data:
    id_number = row[0]
    course = row[1]
    year = row[2]
    print(id_number, course, year)
    student_day_available = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
    for day in student_day_available:
        if day != 'Saturday':
            if course == 'BSN' or year == 1:
                student_timeslot = ['8:00-9:20','9:30-10:50','12:30-1:50','2:00-3:20','4:30-5:50','6:00-7:20']
            elif year == 0:
                student_timeslot = [] 
            else:
                student_timeslot = ['9:30-10:50','11:00-12:20','2:00-3:20','4:30-5:50','6:00-7:20']
        else:
            if course == 'BSN' or year == 0:
                student_timeslot = ['8:00-9:20','9:30-10:50','12:30-1:50','2:00-3:20']
            elif year == 1:
                student_timeslot = ['8:00-9:20','9:30-10:50','12:30-1:50','2:00-3:20']
            else:
                student_timeslot = ['9:30-10:50','11:00-12:20','2:00-3:20']
        for timeslot in student_timeslot:
            insert_query = "INSERT INTO student_schedule (ID_Numbers, Courses, Year, Day, Timeslot) VALUES (%s, %s, %s, %s, %s)"
            insert_values = (id_number, course, year, day, timeslot)
            cursor.execute(insert_query, insert_values)
    conn.commit()

#LABS
def get_schedule_bsn_more(students, enrolled, room_schedule, units): 
    preferred_days = ['Saturday','Wednesday','Friday', 'Tuesday', 'Monday','Thursday']
    preferred_timeslots = ['8:00-9:20','12:30-1:50']
    found_timeslot = False  
    count = 0
    print(room_schedule)
    if len(students) == enrolled:
        if units == 3 or units == 4:
            for preferred_day in preferred_days:
                if found_timeslot: 
                    break  
                else:
                    for room in room_schedule:
                        nnext_day = preferred_day
                        nnnext_day = preferred_day
                        next_day = 'None'
                        if found_timeslot:  
                            break
                        else:
                            for time in preferred_timeslots:
                                if time == '8:00-9:20':
                                    next_time = '9:30-10:50'
                                elif time == '12:30-1:50':
                                    next_time = '2:00-3:20'

                                cursor.execute(f"SELECT * FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}' ")
                                y = cursor.fetchall()
                                print(y)
                                cursor.execute(f"SELECT * FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{next_time}' ")
                                z = cursor.fetchall()
                                print(z)
                                if z:
                                    room_cat = z[0][0]
                                if y and z:
                                    for i in students:
                                        print(i)
                                        print(time, preferred_day)
                                        cursor.execute("SELECT DISTINCT Courses FROM student_schedule WHERE ID_Numbers = %s AND Day = %s AND Timeslot = %s", (i, preferred_day, time))
                                        a = cursor.fetchall()
                                        print(a)
                                        cursor.execute("SELECT DISTINCT Courses FROM student_schedule WHERE ID_Numbers = %s AND Day = %s AND Timeslot = %s", (i, preferred_day, next_time))
                                        b = cursor.fetchall()
                                        print(b)
                                        if a and b:
                                            count += 1
                                            if count == enrolled:
                                                print(count, enrolled)
                                                found_timeslot = True   
                                                print(room, preferred_day, time, room_cat)
                                                if found_timeslot:
                                                    return room, preferred_day, next_day, nnext_day, nnnext_day, time, next_time, room_cat
                                                else:
                                                    break
                                            else:
                                                continue
                                        else:
                                            print("nuway a b")
                                            break                 
                                else:
                                    print("nuway y z")
                                    continue
        elif units == 6 or units == 5:
            preferred_dayss = ['Friday','Tuesday', 'Monday']
            for room in room_schedule:
                if found_timeslot: 
                    break  
                else:
                    for preferred_day in preferred_dayss:
                        if found_timeslot:  
                            break
                        else:
                            for time in preferred_timeslots:
                                if found_timeslot:
                                    break
                                if time == '8:00-9:20':
                                    next_time = '9:30-10:50'
                                else:
                                    next_time = '2:00-3:20'

                                if preferred_day == 'Friday':
                                    next_day = 'Saturday'
                                    nnext_day = 'Saturday'
                                    nnnext_day = 'Friday'
                                elif preferred_day == 'Tuesday':
                                    next_day = 'Thursday'
                                    nnext_day = 'Tuesday'
                                    nnnext_day = 'Thursday'
                                else:
                                    next_day = 'Wednesday'
                                cursor.execute(f"SELECT * FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}' ")
                                y = cursor.fetchall()
                                print(y)
                                cursor.execute(f"SELECT * FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{next_time}' ")
                                z = cursor.fetchall()
                                print(z)
                                cursor.execute(f"SELECT * FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{next_day}'AND Timeslot = '{time}' ")
                                w = cursor.fetchall()
                                print(w)
                                cursor.execute(f"SELECT * FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{next_day}'AND Timeslot = '{next_time}' ")
                                x = cursor.fetchall()
                                print(x)
                                if x:
                                    room_cat = x[0][0]
                                if y and z and w and x:
                                    for i in students:
                                        print(i)
                                        print(time, preferred_day)
                                        cursor.execute("SELECT DISTINCT Courses FROM student_schedule WHERE ID_Numbers = %s AND Day = %s AND Timeslot = %s", (i, preferred_day, time))
                                        a = cursor.fetchall()
                                        print(a)
                                        cursor.execute("SELECT DISTINCT Courses FROM student_schedule WHERE ID_Numbers = %s AND Day = %s AND Timeslot = %s", (i, preferred_day, next_time))
                                        b = cursor.fetchall()
                                        print(b)
                                        cursor.execute("SELECT DISTINCT Courses FROM student_schedule WHERE ID_Numbers = %s AND Day = %s AND Timeslot = %s", (i, next_day, time))
                                        c = cursor.fetchall()
                                        print(c)
                                        cursor.execute("SELECT DISTINCT Courses FROM student_schedule WHERE ID_Numbers = %s AND Day = %s AND Timeslot = %s", (i, next_day, next_time))
                                        d = cursor.fetchall()
                                        print(d)
                                        if a and b and c and d:
                                            count += 1
                                            if count == enrolled:
                                                print(count, enrolled)
                                                found_timeslot = True   
                                                print(room, preferred_day, time, room_cat)
                                                if found_timeslot:
                                                    return room, preferred_day, next_day, nnext_day, nnnext_day, time, next_time, room_cat
                                                else:
                                                    break
                                            else:
                                                continue
                                        else:
                                            print("nuway a b")
                                            break                 
                                else:
                                    print("nuway y z")
                                    continue
        elif units == 9:
            preferred_dayss = ['Thursday', 'Monday']
            for time in preferred_timeslots:
                if found_timeslot:
                    break
                for room in room_schedule:
                    if found_timeslot: 
                        break  
                    else:
                        for preferred_day in preferred_dayss:
                            if found_timeslot:  
                                break
                            else:
                                if time == '8:00-9:20':
                                    next_time = '9:30-10:50'
                                else:
                                    next_time = '2:00-3:20'

                                if preferred_day == 'Monday':
                                    nnnext_day = 'Tuesday'
                                    nnext_day = 'Wednesday'
                                    next_day = 'Tuesday, Wednesday'
                                elif preferred_day == 'Thursday':
                                    nnnext_day = 'Friday'
                                    nnext_day = 'Saturday'
                                    next_day = 'Friday, Saturday'

                                cursor.execute(f"SELECT * FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}' ")
                                y = cursor.fetchall()
                                print(y)
                                cursor.execute(f"SELECT * FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{next_time}' ")
                                z = cursor.fetchall()
                                print(z)
                                cursor.execute(f"SELECT * FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnnext_day}'AND Timeslot = '{time}' ")
                                w = cursor.fetchall()
                                print(w)
                                cursor.execute(f"SELECT * FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnnext_day}'AND Timeslot = '{next_time}' ")
                                x = cursor.fetchall()
                                print(x)
                                cursor.execute(f"SELECT * FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnext_day}'AND Timeslot = '{time}' ")
                                p = cursor.fetchall()
                                print(p)
                                cursor.execute(f"SELECT * FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnext_day}'AND Timeslot = '{next_time}' ")
                                r = cursor.fetchall()
                                print(r)
                                if r:
                                    room_cat = r[0][0]
                                print(y,z,w,x,p,r)
                                if y and z and w and x and p and r:
                                    for i in students:
                                        print(i)
                                        print(time, preferred_day)
                                        cursor.execute("SELECT DISTINCT Courses FROM student_schedule WHERE ID_Numbers = %s AND Day = %s AND Timeslot = %s", (i, preferred_day, time))
                                        a = cursor.fetchall()
                                        print(a)
                                        cursor.execute("SELECT DISTINCT Courses FROM student_schedule WHERE ID_Numbers = %s AND Day = %s AND Timeslot = %s", (i, preferred_day, next_time))
                                        b = cursor.fetchall()
                                        print(b)
                                        cursor.execute("SELECT DISTINCT Courses FROM student_schedule WHERE ID_Numbers = %s AND Day = %s AND Timeslot = %s", (i, nnnext_day, time))
                                        c = cursor.fetchall()
                                        print(c)
                                        cursor.execute("SELECT DISTINCT Courses FROM student_schedule WHERE ID_Numbers = %s AND Day = %s AND Timeslot = %s", (i, nnnext_day, next_time))
                                        d = cursor.fetchall()
                                        print(d)
                                        cursor.execute("SELECT DISTINCT Courses FROM student_schedule WHERE ID_Numbers = %s AND Day = %s AND Timeslot = %s", (i, nnext_day, time))
                                        e = cursor.fetchall()
                                        print(e)
                                        cursor.execute("SELECT DISTINCT Courses FROM student_schedule WHERE ID_Numbers = %s AND Day = %s AND Timeslot = %s", (i, nnext_day, next_time))
                                        f = cursor.fetchall()
                                        print(f)
                                        if a and b and c and d and e and f:
                                            count += 1
                                            if count == enrolled:
                                                print(count, enrolled)
                                                found_timeslot = True   
                                                print(room, preferred_day, time, room_cat)
                                                if found_timeslot:
                                                    return room, preferred_day, next_day, nnext_day, nnnext_day, time, next_time, room_cat
                                                else:
                                                    break
                                            else:
                                                continue
                                        else:
                                            print("nuway a b")
                                            break                 
                                else:
                                    print("nuway y z")
                                    continue
    else:
        print("may error sa num count")
    if not found_timeslot:
            return None, None, None, None, None, None,None, None

def bsn_2units(students, enrolled, room_schedule):
    preferred_days = ['Saturday','Friday', 'Tuesday', 'Monday','Wednesday','Thursday']
    preferred_timeslots = ['8:00-9:20','12:30-1:50']
    found_timeslot = False  
    count = 0
    print(room_schedule)
    if len(students) == enrolled:
        for room in room_schedule:
            if found_timeslot: 
                break  
            else:
                for preferred_day in preferred_days:
                    next_day = 'None'
                    if found_timeslot:  
                        break
                    else:
                        for time in preferred_timeslots:
                            if time == '8:00-9:20':
                                next_time = '9:30-10:00'
                                check = '9:30-10:50'
                            elif time == '12:30-1:50':
                                next_time = '2:00-2:30'
                                check = '2:00-3:20'

                            cursor.execute(f"SELECT * FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}' ")
                            y = cursor.fetchall()
                            print(y)
                            cursor.execute(f"SELECT * FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{check}' ")
                            z = cursor.fetchall()
                            print(z)
                            if z:
                                room_cat = z[0][0]
                            if y and z:
                                for i in students:
                                    print(i)
                                    print(time, preferred_day)
                                    cursor.execute("SELECT DISTINCT Courses FROM student_schedule WHERE ID_Numbers = %s AND Day = %s AND Timeslot = %s", (i, preferred_day, time))
                                    a = cursor.fetchall()
                                    print(a)
                                    cursor.execute("SELECT DISTINCT Courses FROM student_schedule WHERE ID_Numbers = %s AND Day = %s AND Timeslot = %s", (i, preferred_day, check))
                                    b = cursor.fetchall()
                                    print(b)
                                    if a and b:
                                        count += 1
                                        if count == enrolled:
                                            print(count, enrolled)
                                            found_timeslot = True   
                                            print(room, preferred_day, time, room_cat)
                                            if found_timeslot:
                                                return room, preferred_day, next_day, time, next_time, room_cat, check
                                            else:
                                                break
                                        else:
                                            continue
                                    else:
                                        print("nuway a b")
                                        break                 
                            else:
                                print("nuway y z")
                                continue
    else:
        print("may error sa num count")
    if not found_timeslot:
            return None, None, None, None, None, None,None
    
def insert_assignment_more(cursor, conn, subject, section, room, preferred_day, time, student_ids, courses, enrolled, years, room_cat, next_day, next_time):
    try:
        query = """INSERT INTO assignment 
                   (SUBJECT, SECTION, ROOM, DAYS, TIMESLOTS, IDs, Programs, Enrolled, Year, Room_Category, NEXT_DAY, NEXT_TIMESLOT) 
                   VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"""
        values = (subject, section, room, preferred_day, time, student_ids, courses, enrolled, years, room_cat, next_day, next_time)
        cursor.execute(query, values)
        conn.commit()
        print("Record inserted successfully into assignment table")
    except Exception as e:
        print(f"Error occurred: {str(e)}")
        conn.rollback() 


def insert_assignment(cursor, conn, subject, section, room, preferred_day, next_day, time, next_timeslot, student_ids, courses, enrolled, years, room_cat):
    try:
        query = """INSERT INTO assignment 
                   (SUBJECT, SECTION, ROOM, DAYS, TIMESLOTS, IDs, Programs, Enrolled, Year, Room_Category, NEXT_DAY, NEXT_TIMESLOT) 
                   VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s,%s, %s)"""
        values = (subject, section, room, preferred_day, time, student_ids, courses, enrolled, years, room_cat, next_day, next_timeslot)
        cursor.execute(query, values)
        conn.commit()
        print("Record inserted successfully into assignment table")
    except Exception as e:
        print(f"Error occurred: {str(e)}")
        conn.rollback()  

      
def get_schedule_first(students, enrolled, room_schedule):
    print('first')
    preferred_days = ['Tuesday', 'Monday']
    preferred_timeslots = ['8:00-9:20','9:30-10:50','12:30-1:50','2:00-3:20','4:30-5:50']
    found_timeslot = False
    count = 0
    print(room_schedule)
    if len(students) == enrolled:  
        for room in room_schedule:
            if found_timeslot:  
                break 
            else:
                for preferred_day in preferred_days:
                    if found_timeslot: 
                        break 
                    else:
                        for time in preferred_timeslots:
                            if found_timeslot:
                                break  
                            else:
                                if preferred_day == 'Monday':
                                    next_day = 'Thursday'
                                elif preferred_day == 'Tuesday':
                                    next_day = 'Friday'
           
                                cursor.execute(f"SELECT * FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}' ")
                                y = cursor.fetchall()
                                print(y)
                                cursor.execute(f"SELECT * FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{next_day}'AND Timeslot = '{time}' ")
                                z = cursor.fetchall()
                                print(z)
                                if z:
                                    room_cat = z[0][0]
                                if y and z:
                                    for i in students:
                                        print(i)
                                        cursor.execute("SELECT DISTINCT Courses FROM student_schedule WHERE ID_Numbers = %s AND Day = %s AND Timeslot = %s", (i, preferred_day, time))
                                        a = cursor.fetchall()
                                        print(a)
                                        cursor.execute("SELECT DISTINCT Courses FROM student_schedule WHERE ID_Numbers = %s AND Day = %s AND Timeslot = %s", (i, next_day, time))
                                        b = cursor.fetchall()
                                        print(b)
                                        if a and b:
                                            count += 1
                                            if count == enrolled:
                                                print(count, enrolled)
                                                found_timeslot = True   
                                                next_timeslot = time
                                                print(room, preferred_day, next_day, time, next_timeslot, room_cat)
                                                if found_timeslot:
                                                    return room, preferred_day, next_day, time, next_timeslot, room_cat 
                                                else:
                                                    break
                                            else:
                                                continue
                                        else:
                                            break     
                                else:
                                    continue
    else:
        print("may error sa num count")
    if not found_timeslot:
        return None, None, None, None, None, None
def for_wed_excess (students, room_schedule):
    preferred_day = 'Wednesday'
    timeslot = ['8:00-9:20','9:30-10:50','12:30-1:50','4:30-5:50']
    found_timeslot = False
    count = 0
    for room in room_schedule:
        for time in timeslot:
            if time == '8:00-9:20':
                next_timeslot = '9:30-10:50'
            elif time == '9:30-10:50':
                next_timeslot = '11:00-12:20'
            elif time == '12:30-1:50':
                next_timeslot = '2:00-3:20'
            elif time == '4:30-5:50':
                next_timeslot = '6:00-7:20'
            cursor.execute(f"SELECT * FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}' ")
            y = cursor.fetchall()
            print(y)
            cursor.execute(f"SELECT * FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{next_timeslot}' ")
            z = cursor.fetchall()
            print(z)
            if z:
                room_cat = z[0][0]
            if y and z:
                for i in students:
                    print(i)
                    cursor.execute("SELECT DISTINCT Courses FROM student_schedule WHERE ID_Numbers = %s AND Day = %s AND Timeslot = %s", (i, preferred_day, time))
                    a = cursor.fetchall()
                    print(a)
                    cursor.execute("SELECT DISTINCT Courses FROM student_schedule WHERE ID_Numbers = %s AND Day = %s AND Timeslot = %s", (i, preferred_day, next_timeslot))
                    b = cursor.fetchall()
                    print(b)
                    if a and b:
                        count += 1
                        if count == enrolled:
                            print(count, enrolled)
                            found_timeslot = True   
                            next_day = preferred_day
                            if found_timeslot:
                                print(room, preferred_day, next_day, time, next_timeslot, room_cat)
                                return room, preferred_day, next_day, time, next_timeslot, room_cat
                        else:
                            continue
                    else:
                        break
            else:
                continue
    if not found_timeslot:
        return None, None, None, None, None, None

def late_schedule(students, enrolled, room_schedule):
    print('last')
    preferred_days = ['Monday','Tuesday']
    time = '6:00-7:20'
    found_timeslot = False
    count = 0
    print(room_schedule)
    if len(students) == enrolled:  
        for room in room_schedule:
            if found_timeslot: 
                break 
            else:
                for preferred_day in preferred_days:
                    if found_timeslot:  
                        break
                    else:
                        if preferred_day == 'Monday':
                            next_day = 'Thursday'
                        elif preferred_day == 'Tuesday':
                            next_day = 'Friday'
                        
                        cursor.execute(f"SELECT * FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}' ")
                        y = cursor.fetchall()
                        print(y)
                        cursor.execute(f"SELECT * FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{next_day}'AND Timeslot = '{time}' ")
                        z = cursor.fetchall()
                        print(z)
                        if z:
                            room_cat = z[0][0]
                        if y and z:
                            for i in students:
                                print(i)
                                cursor.execute("SELECT DISTINCT Courses FROM student_schedule WHERE ID_Numbers = %s AND Day = %s AND Timeslot = %s", (i, preferred_day, time))
                                a = cursor.fetchall()
                                print(a)
                                cursor.execute("SELECT DISTINCT Courses FROM student_schedule WHERE ID_Numbers = %s AND Day = %s AND Timeslot = %s", (i, next_day, time))
                                b = cursor.fetchall()
                                print(b)
                                if a and b:
                                    count += 1
                                    if count == enrolled:
                                        print(count, enrolled)
                                        found_timeslot = True   
                                        next_timeslot = time
                                        if found_timeslot:
                                            print(room, preferred_day, next_day, time, next_timeslot, room_cat)
                                            return room, preferred_day, next_day, time, next_timeslot, room_cat
                                        else:
                                            break
                                    else:
                                        continue
                                else:
                                    break     
                        else:
                            continue
    else:
        print('may error sa number count')
    if not found_timeslot:
        return None, None, None, None, None, None
    

def get_schedule_grad(students, enrolled, room_schedule):
    if len(students) == enrolled:
        print('grads')
        preferred_day = 'Saturday'
        preferred_timeslots = ['8:00-9:20','12:30-1:50']
        found_timeslot = False  
        count = 0
        for time in preferred_timeslots:
            if found_timeslot:  
                break 
            else:
                student_time_unavailable = False
                for room in room_schedule:
                    if found_timeslot or student_time_unavailable:  
                        break  
                    else:
                        if time == '8:00-9:20':
                            next_timeslot = '9:30-10:50'
                        elif time == '12:30-1:50':
                            next_timeslot = '2:00-3:20'
                        cursor.execute(f"SELECT * FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}' ")
                        y = cursor.fetchall()
                        print(y)
                        cursor.execute(f"SELECT * FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{next_timeslot}' ")
                        z = cursor.fetchall()
                        print(z)
                        if z:
                            room_cat = z[0][0]
                        if y and z:
                            for i in students:
                                print(i)
                                cursor.execute("SELECT DISTINCT Courses FROM student_schedule WHERE ID_Numbers = %s AND Day = %s AND Timeslot = %s", (i, preferred_day, time))
                                a = cursor.fetchall()
                                print(a)
                                cursor.execute("SELECT DISTINCT Courses FROM student_schedule WHERE ID_Numbers = %s AND Day = %s AND Timeslot = %s", (i, preferred_day, next_timeslot))
                                b = cursor.fetchall()
                                print(b)
                                if a and b:
                                    count += 1
                                    if count == enrolled:
                                        print(count, enrolled)
                                        found_timeslot = True   
                                        next_day = preferred_day  
                                        print(room, preferred_day, next_day, time, next_timeslot, room_cat)
                                        if found_timeslot:
                                            return room, preferred_day, next_day, time, next_timeslot, room_cat 
                                        else:
                                            break
                                    else:
                                        continue
                                else:
                                    student_time_unavailable = True
                                    break        
                        else:
                            continue
    else:
        print("may error sa num count")
    if not found_timeslot:
        return None, None, None, None, None, None

    
def get_schedule_mix(students, enrolled, room_schedule): 
    print('mix')
    preferred_days = ['Monday','Tuesday']
    preferred_timeslots = ['11:00-12:20','9:30-10:50','2:00-3:20','4:30-5:50']
    found_timeslot = False  
    count = 0
    print(room_schedule)
    if len(students) == enrolled:
        for room in room_schedule:
            if found_timeslot: 
                break  
            else:
                for preferred_day in preferred_days:
                    if found_timeslot:  
                        break
                    else:
                        for time in preferred_timeslots:
                            if found_timeslot :
                                break  
                            else:
                                if preferred_day == 'Monday':
                                    next_day = 'Thursday'
                                elif preferred_day == 'Tuesday':
                                    next_day = 'Friday'
                            
                                cursor.execute(f"SELECT * FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}' ")
                                y = cursor.fetchall()
                                print(y)
                                cursor.execute(f"SELECT * FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{next_day}'AND Timeslot = '{time}' ")
                                z = cursor.fetchall()
                                print(z)
                                if z:
                                    room_cat = z[0][0]
                                if y and z:
                                    for i in students:
                                        print(i)
                                        print(time, preferred_day, next_day)
                                        cursor.execute("SELECT DISTINCT Courses FROM student_schedule WHERE ID_Numbers = %s AND Day = %s AND Timeslot = %s", (i, preferred_day, time))
                                        a = cursor.fetchall()
                                        print(a)
                                        cursor.execute("SELECT DISTINCT Courses FROM student_schedule WHERE ID_Numbers = %s AND Day = %s AND Timeslot = %s", (i, next_day, time))
                                        b = cursor.fetchall()
                                        print(b)
                                        if a and b:
                                            count += 1
                                            if count == enrolled:
                                                print(count, enrolled)
                                                found_timeslot = True   
                                                next_timeslot = time 
                                                print(room, preferred_day, next_day, time, next_timeslot, room_cat)
                                                if found_timeslot:
                                                    return room, preferred_day, next_day, time, next_timeslot, room_cat 
                                                else:
                                                    break
                                            else:
                                                continue
                                        else:
                                            print("nuway a b")
                                            break                 
                                else:
                                    print("nuway y z")
                                    continue
    else:
        print("may error sa num count")
    if not found_timeslot:
            return None, None, None, None, None, None
    
def checking_for_none (all_bsn,all_first,all_grad,enrolled, subject, section, students, student_ids, courses):
    room_schedule = get_room_available(enrolled)
    room, preferred_day, next_day, time, next_timeslot, room_cat = late_schedule(students, enrolled, room_schedule)
    if room is None:
        room, preferred_day, next_day, time, next_timeslot, room_cat = for_wed_excess (students, room_schedule)
        if room is None:
            if enrolled <= 10:
                enrolled_temp = 15
                room_schedule_2 = get_room_available(enrolled=enrolled_temp)
                print(f"room sched 2: {room_schedule_2}")
                if all_bsn or all_first:
                    room, preferred_day, next_day, time, next_timeslot, room_cat = get_schedule_first(students, enrolled, room_schedule=room_schedule_2)
                elif all_grad:
                    room, preferred_day, next_day, time, next_timeslot, room_cat = get_schedule_grad(students, enrolled, room_schedule=room_schedule_2)
                else:
                    room, preferred_day, next_day, time, next_timeslot, room_cat = get_schedule_mix(students, enrolled, room_schedule=room_schedule_2)
                if room is None:
                    room, preferred_day, next_day, time, next_timeslot, room_cat = late_schedule(students, enrolled, room_schedule=room_schedule_2)
                    if room is None:
                        room, preferred_day, next_day, time, next_timeslot, room_cat = for_wed_excess (students, room_schedule=room_schedule_2)
                        if room is None:
                            enrolled_temp = 30
                            room_schedule_3 = get_room_available(enrolled=enrolled_temp)
                            if all_bsn or all_first:
                                room, preferred_day, next_day, time, next_timeslot, room_cat = get_schedule_first(students, enrolled, room_schedule=room_schedule_3)
                            elif all_grad:
                                room, preferred_day, next_day, time, next_timeslot, room_cat = get_schedule_grad(students, enrolled, room_schedule=room_schedule_3)
                            else:
                                room, preferred_day, next_day, time, next_timeslot, room_cat = get_schedule_mix(students, enrolled, room_schedule=room_schedule_3)
                            if room is None:
                                room, preferred_day, next_day, time, next_timeslot, room_cat = late_schedule(students, enrolled, room_schedule=room_schedule_3)
                                if room is None:
                                    room, preferred_day, next_day, time, next_timeslot, room_cat = for_wed_excess (students, room_schedule= room_schedule_3)
                                    print(room, preferred_day, next_day, time, next_timeslot, room_cat)
                                    for i in students:
                                        print(f"aki ya ste tan update db : {i}")
                                        cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{time}'")
                                        cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{next_day}' AND Timeslot = '{next_timeslot}'")
                                        cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                                        cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{next_day}'AND Timeslot = '{next_timeslot}'")
                                        cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', NEXTDAY = '{next_day}', TIMESLOT = '{time}', NEXTTIMESLOT = '{next_timeslot}',ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                                        cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                                        conn.commit()
                                    insert_assignment(cursor, conn, subject, section, room, preferred_day, next_day, time, next_timeslot, student_ids, courses, enrolled, years, room_cat)
                                    print('done')
                                else:
                                    print(room, preferred_day, next_day, time, next_timeslot, room_cat)
                                    for i in students:
                                        print(f"aki ya ste tan update db : {i}")
                                        cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{time}'")
                                        cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{next_day}' AND Timeslot = '{next_timeslot}'")
                                        cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                                        cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{next_day}'AND Timeslot = '{next_timeslot}'")
                                        cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', NEXTDAY = '{next_day}', TIMESLOT = '{time}', NEXTTIMESLOT = '{next_timeslot}',ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                                        cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                                        conn.commit()
                                    insert_assignment(cursor, conn, subject, section, room, preferred_day, next_day, time, next_timeslot, student_ids, courses, enrolled, years, room_cat)
                                    print('done')
                            else:
                                print(room, preferred_day, next_day, time, next_timeslot, room_cat)
                                for i in students:
                                    print(f"aki ya ste tan update db : {i}")
                                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{time}'")
                                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{next_day}' AND Timeslot = '{next_timeslot}'")
                                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{next_day}'AND Timeslot = '{next_timeslot}'")
                                    cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', NEXTDAY = '{next_day}', TIMESLOT = '{time}', NEXTTIMESLOT = '{next_timeslot}',ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                                    cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                                    conn.commit()
                                insert_assignment(cursor, conn, subject, section, room, preferred_day, next_day, time, next_timeslot, student_ids, courses, enrolled, years, room_cat)
                                print('done')
                        else:
                            print(room, preferred_day, next_day, time, next_timeslot, room_cat)
                            for i in students:
                                print(f"aki ya ste tan update db : {i}")
                                cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{time}'")
                                cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{next_day}' AND Timeslot = '{next_timeslot}'")
                                cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                                cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{next_day}'AND Timeslot = '{next_timeslot}'")
                                cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', NEXTDAY = '{next_day}', TIMESLOT = '{time}', NEXTTIMESLOT = '{next_timeslot}',ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                                cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                                conn.commit()
                            insert_assignment(cursor, conn, subject, section, room, preferred_day, next_day, time, next_timeslot, student_ids, courses, enrolled, years, room_cat)
                            print('done')
                    else:
                        print(room, preferred_day, next_day, time, next_timeslot, room_cat)
                        for i in students:
                            print(f"aki ya ste tan update db : {i}")
                            cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{time}'")
                            cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{next_day}' AND Timeslot = '{next_timeslot}'")
                            cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                            cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{next_day}'AND Timeslot = '{next_timeslot}'")
                            cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', NEXTDAY = '{next_day}', TIMESLOT = '{time}', NEXTTIMESLOT = '{next_timeslot}',ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                            cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                            conn.commit()
                        insert_assignment(cursor, conn, subject, section, room, preferred_day, next_day, time, next_timeslot, student_ids, courses, enrolled, years, room_cat)
                        print('done')
                else:
                    print(room, preferred_day, next_day, time, next_timeslot, room_cat)
                    for i in students:
                        print(f"aki ya ste tan update db : {i}")
                        cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{time}'")
                        cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{next_day}' AND Timeslot = '{next_timeslot}'")
                        cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                        cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{next_day}'AND Timeslot = '{next_timeslot}'")
                        cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', NEXTDAY = '{next_day}', TIMESLOT = '{time}', NEXTTIMESLOT = '{next_timeslot}',ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                        cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                        conn.commit()
                    insert_assignment(cursor, conn, subject, section, room, preferred_day, next_day, time, next_timeslot, student_ids, courses, enrolled, years, room_cat)
                    print('done')
            else:
                enrolled_temp = 30
                room_schedule_2 = get_room_available(enrolled=enrolled_temp)
                if all_bsn or all_first:
                    room, preferred_day, next_day, time, next_timeslot, room_cat = get_schedule_first(students, enrolled, room_schedule=room_schedule_2)
                elif all_grad:
                    room, preferred_day, next_day, time, next_timeslot, room_cat = get_schedule_grad(students, enrolled, room_schedule=room_schedule_2)
                else:
                    room, preferred_day, next_day, time, next_timeslot, room_cat = get_schedule_mix(students, enrolled, room_schedule=room_schedule_2)
                if room is None:
                    room, preferred_day, next_day, time, next_timeslot, room_cat = for_wed_excess (students, room_schedule=room_schedule_2)
                    if room is None:
                        room, preferred_day, next_day, time, next_timeslot, room_cat = late_schedule(students, enrolled, room_schedule=room_schedule_2)
                        print(room, preferred_day, next_day, time, next_timeslot, room_cat)
                        for i in students:
                            print(f"aki ya ste tan update db : {i}")
                            cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{time}'")
                            cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{next_day}' AND Timeslot = '{next_timeslot}'")
                            cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                            cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{next_day}'AND Timeslot = '{next_timeslot}'")
                            cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', NEXTDAY = '{next_day}', TIMESLOT = '{time}', NEXTTIMESLOT = '{next_timeslot}',ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                            cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                            conn.commit()
                        insert_assignment(cursor, conn, subject, section, room, preferred_day, next_day, time, next_timeslot, student_ids, courses, enrolled, years, room_cat)
                        print('done')
                    else:
                        print(room, preferred_day, next_day, time, next_timeslot, room_cat)
                        for i in students:
                            print(f"aki ya ste tan update db : {i}")
                            cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{time}'")
                            cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{next_day}' AND Timeslot = '{next_timeslot}'")
                            cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                            cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{next_day}'AND Timeslot = '{next_timeslot}'")
                            cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', NEXTDAY = '{next_day}', TIMESLOT = '{time}', NEXTTIMESLOT = '{next_timeslot}',ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                            cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                            conn.commit()
                        insert_assignment(cursor, conn, subject, section, room, preferred_day, next_day, time, next_timeslot, student_ids, courses, enrolled, years, room_cat)
                        print('done')
                else:
                    print(room, preferred_day, next_day, time, next_timeslot, room_cat)
                    for i in students:
                        print(f"aki ya ste tan update db : {i}")
                        cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{time}'")
                        cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{next_day}' AND Timeslot = '{next_timeslot}'")
                        cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                        cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{next_day}'AND Timeslot = '{next_timeslot}'")
                        cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', NEXTDAY = '{next_day}', TIMESLOT = '{time}', NEXTTIMESLOT = '{next_timeslot}',ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                        cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                        conn.commit()
                    insert_assignment(cursor, conn, subject, section, room, preferred_day, next_day, time, next_timeslot, student_ids, courses, enrolled, years, room_cat)
                    print('done')
        else:
            print(room, preferred_day, next_day, time, next_timeslot, room_cat)
            for i in students:
                print(f"aki ya ste tan update db : {i}")
                cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{time}'")
                cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{next_day}' AND Timeslot = '{next_timeslot}'")
                cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{next_day}'AND Timeslot = '{next_timeslot}'")
                cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', NEXTDAY = '{next_day}', TIMESLOT = '{time}', NEXTTIMESLOT = '{next_timeslot}',ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                conn.commit()
            insert_assignment(cursor, conn, subject, section, room, preferred_day, next_day, time, next_timeslot, student_ids, courses, enrolled, years, room_cat)
            print('done') 
    else:
        print(room, preferred_day, next_day, time, next_timeslot, room_cat)
        for i in students:
            print(f"aki ya ste tan update db : {i}")
            cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{time}'")
            cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{next_day}' AND Timeslot = '{next_timeslot}'")
            cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
            cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{next_day}'AND Timeslot = '{next_timeslot}'")
            cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', NEXTDAY = '{next_day}', TIMESLOT = '{time}', NEXTTIMESLOT = '{next_timeslot}',ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
            cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
            conn.commit()
        insert_assignment(cursor, conn, subject, section, room, preferred_day, next_day, time, next_timeslot, student_ids, courses, enrolled, years, room_cat)
        print('done')                  

def insert_assignment_path(cursor, conn, subject, section, room, preferred_day, time, student_ids, courses, enrolled, years, room_cat):
    try:
        query = """INSERT INTO assignment 
                   (SUBJECT, SECTION, ROOM, DAYS, TIMESLOTS, IDs, Programs, Enrolled, Year, Room_Category, NEXT_DAY, NEXT_TIMESLOT) 
                   VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"""
        values = (subject, section, room, preferred_day, time, student_ids, courses, enrolled, years, room_cat, 'None','None')
        cursor.execute(query, values)
        conn.commit()
    except Exception as e:
        print(f"Error occurred: {str(e)}")
        conn.rollback()  

def get_schedule_path(students, enrolled, room_schedule):
    preferred_days = ['Wednesday', 'Friday', 'Tuesday', 'Monday','Thursday','Saturday']
    preferred_timeslots = ['8:00-10:00','10:00-12:00','1:00-3:00']
    found_timeslot = False
    count = 0
    print(room_schedule)
    if len(students) == enrolled:  
        for room in room_schedule:
            if found_timeslot:  
                break 
            else:
                for preferred_day in preferred_days:
                    if found_timeslot: 
                        break 
                    else:
                        for time in preferred_timeslots:
                            if time == '8:00-10:00':
                                check = '8:00-9:20'
                                ccheck = '9:30-10:50'
                            elif time == '10:00-12:00':
                                check = '9:30-10:50'
                                ccheck = '11:00-12:20'
                            elif time == '1:00-3:00':
                                check = '12:30-1:50'
                                ccheck = '2:00-3:20'

                            if found_timeslot:
                                break  
                            else:
                                cursor.execute(f"SELECT * FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}' ")
                                z = cursor.fetchall()
                                print(z)
                                if z:
                                    room_cat = z[0][0]
                                    for i in students:
                                        print(i)
                                        cursor.execute("SELECT DISTINCT Courses FROM student_schedule WHERE ID_Numbers = %s AND Day = %s AND Timeslot = %s", (i, preferred_day, check))
                                        a = cursor.fetchall()
                                        print(a)
                                        cursor.execute("SELECT DISTINCT Courses FROM student_schedule WHERE ID_Numbers = %s AND Day = %s AND Timeslot = %s", (i, preferred_day, ccheck))
                                        b = cursor.fetchall()
                                        print(b)
                                        if a and b:
                                            count += 1
                                            if count == enrolled:
                                                print(count, enrolled)
                                                found_timeslot = True   
                                                print(room, preferred_day, time, room_cat)
                                                if found_timeslot:
                                                    return room, preferred_day, time, room_cat, check, ccheck
                                                else:
                                                    break
                                            else:
                                                continue
                                        else:
                                            break     
                                else:
                                    continue
    else:
        print("may error sa num count")
    if not found_timeslot:
        return None, None, None, None, None, None
    

def get_schedule_regular(students, enrolled, room_schedule):
    preferred_days = ['Friday', 'Tuesday', 'Monday','Thursday','Saturday']
    preferred_timeslots = ['8:00-10:00','10:00-12:00','1:00-3:00']
    found_timeslot = False
    count = 0
    print(room_schedule)
    if len(students) == enrolled:  
        for room in room_schedule:
            if found_timeslot:  
                break 
            else:
                for preferred_day in preferred_days:
                    if found_timeslot: 
                        break 
                    else:
                        for time in preferred_timeslots:
                            if time == '8:00-10:00':
                                check = '8:00-9:20'
                                ccheck = '9:30-10:50'
                            elif time == '10:00-12:00':
                                check = '9:30-10:50'
                                ccheck = '11:00-12:20'
                            elif time == '1:00-3:00':
                                check = '12:30-1:50'
                                ccheck = '2:00-3:20'

                            if found_timeslot:
                                break  
                            else:
                                cursor.execute(f"SELECT * FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{check}' ")
                                z = cursor.fetchall()
                                print(z)
                                cursor.execute(f"SELECT * FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{ccheck}' ")
                                o = cursor.fetchall()
                                print(o)
                                if z and o:
                                    room_cat = z[0][0]
                                    for i in students:
                                        print(i)
                                        cursor.execute("SELECT DISTINCT Courses FROM student_schedule WHERE ID_Numbers = %s AND Day = %s AND Timeslot = %s", (i, preferred_day, check))
                                        a = cursor.fetchall()
                                        print(a)
                                        cursor.execute("SELECT DISTINCT Courses FROM student_schedule WHERE ID_Numbers = %s AND Day = %s AND Timeslot = %s", (i, preferred_day, ccheck))
                                        b = cursor.fetchall()
                                        print(b)
                                        if a and b:
                                            count += 1
                                            if count == enrolled:
                                                print(count, enrolled)
                                                found_timeslot = True   
                                                print(room, preferred_day, time, room_cat)
                                                if found_timeslot:
                                                    return room, preferred_day, time, room_cat, check, ccheck
                                                else:
                                                    break
                                            else:
                                                continue
                                        else:
                                            break     
                                else:
                                    continue
    else:
        print("may error sa num count")
    if not found_timeslot:
        return None, None, None, None, None, None
    

def get_schedule_mix_straight(students, enrolled, room_schedule, units): 
    preferred_days = ['Saturday','Friday', 'Tuesday', 'Monday','Wednesday','Thursday']
    preferred_timeslots = ['9:30-10:50','4:30-5:50']
    found_timeslot = False  
    count = 0
    print(room_schedule)
    if len(students) == enrolled:
        if units == 3 or units == 4:
            for preferred_day in preferred_days:
                if found_timeslot: 
                    break  
                else:
                    for room in room_schedule:
                        next_day = 'None'
                        if found_timeslot:  
                            break
                        else:
                            for time in preferred_timeslots:
                                if time == '9:30-10:50':
                                    next_timeslot = '11:00-12:20'
                                elif time == '4:30-5:50':
                                    next_timeslot = '6:00-7:20'

                                cursor.execute(f"SELECT * FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}' ")
                                y = cursor.fetchall()
                                print(y)
                                cursor.execute(f"SELECT * FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{next_timeslot}' ")
                                z = cursor.fetchall()
                                print(z)
                                if z:
                                    room_cat = z[0][0]
                                if y and z:
                                    for i in students:
                                        print(i)
                                        print(time, preferred_day)
                                        cursor.execute("SELECT DISTINCT Courses FROM student_schedule WHERE ID_Numbers = %s AND Day = %s AND Timeslot = %s", (i, preferred_day, time))
                                        a = cursor.fetchall()
                                        print(a)
                                        cursor.execute("SELECT DISTINCT Courses FROM student_schedule WHERE ID_Numbers = %s AND Day = %s AND Timeslot = %s", (i, preferred_day, next_timeslot))
                                        b = cursor.fetchall()
                                        print(b)
                                        if a and b:
                                            count += 1
                                            if count == enrolled:
                                                print(count, enrolled)
                                                found_timeslot = True   
                                                print(room, preferred_day, time, room_cat)
                                                if found_timeslot:
                                                    return room, preferred_day, next_day, time, next_timeslot, room_cat
                                                else:
                                                    break
                                            else:
                                                continue
                                        else:
                                            print("nuway a b")
                                            break                 
                                else:
                                    print("nuway y z")
                                    continue


#unit9

# BSN
query = """
    SELECT
    SUBJECT,
    UNITS,
    GROUP_CONCAT(ID ORDER BY SUBJECT, COURSE, YEAR) AS id_numbers,
    COUNT(ID) AS enrolled_count
    FROM
        duplicate
    WHERE
        UNITS = 9 AND COURSE ='BSN'
    GROUP BY
        SUBJECT
    ORDER BY
        SUBJECT, COURSE, YEAR

"""

cursor.execute(query)
initial = cursor.fetchall()
counter = 0
sections = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']

for row in initial:
    counter += 1
    subject = row[0]
    units = row[1]
    total_enrolled_count = row[3]
    print(subject, total_enrolled_count)
    print(units)
    if total_enrolled_count <= 35:
        section = 'A'
        cursor.execute(f"SELECT ID, COURSE, YEAR FROM duplicate WHERE SUBJECT = '{subject}'")
        x = cursor.fetchall()
        print(x)
        print(f"este del x {len(x)}")
        students = [str(w[0]) for w in x]
        student_ids = ','.join([str(w[0]) for w in x]) 
        enrolled = len(x)
        print(f"students {len(students)}")
        print(f"enrolled {enrolled}")
        print(f"student id {student_ids}")
        course =  set([str(w[1]).strip() for w in x])
        courses = ','.join(set([str(w[1]).strip() for w in x]))
        print(f"course to {courses}")
        year = set([str(w[2]).strip() for w in x])
        years = ','.join(set([str(w[2]).strip() for w in x]))
        print(f"years to {years}")
        print(subject)
        if units == 2:
            print("yessss")
            room_schedule = ['XH105', 'XH201', 'XH202', 'XH203', 'XH204', 'XH301','XH302', 'XH303', 'XH304','XH305', 'XH401', 'XH402', 'XH403', 'XH404', 'XH405']
            print(f"room_schedule to : {room_schedule}")
            room, preferred_day, next_day, time, next_time, room_cat, check = bsn_2units(students, enrolled, room_schedule)
            if room is None:
                print("Wala room")
            else:
                for i in students:
                    print(f"aki ya ste tan update db : {i}")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{check}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{check}'")
                    cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', NEXTDAY = '{next_day}', TIMESLOT = '{time}', NEXTTIMESLOT = '{next_time}',ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                    cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                    conn.commit()
                insert_assignment_more(cursor, conn, subject, section, room, preferred_day, time, student_ids, courses, enrolled, years, room_cat, next_day, next_time)
                print('inserted ya')
        elif subject == 'NURBIO LEC':
            room_schedule = ['C311']
            print(f"room_schedule to : {room_schedule}")
            room, preferred_day, next_day, nnext_day, nnnext_day, time, next_time, room_cat = get_schedule_bsn_more(students, enrolled, room_schedule, units = 3)
            if room is None:
                preferred_day = None
                next_day = None
                nnext_day = None
                nnnext_day = None
                time = None
                next_time = None
                room_cat = None
            else:
                print(room, preferred_day, time, room_cat)
                for i in students:
                    print(f"aki ya ste tan update db : {i}")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnext_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnext_day}' AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnnext_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnnext_day}' AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnext_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnext_day}'AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnnext_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnnext_day}'AND Timeslot = '{next_time}'")
                    cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', NEXTDAY = '{next_day}', TIMESLOT = '{time}', NEXTTIMESLOT = '{next_time}',ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                    cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                    conn.commit()
                insert_assignment_more(cursor, conn, subject, section, room, preferred_day, time, student_ids, courses, enrolled, years, room_cat, next_day, next_time)
                print('inserted ya')
        elif subject == 'NURBIO LAB':
            room_schedule = ['C308','C310']
            print(f"room_schedule to : {room_schedule}")
            room, preferred_day, next_day, nnext_day, nnnext_day, time, next_time, room_cat = get_schedule_bsn_more(students, enrolled, room_schedule, units = 6)   
            if room is None:
                preferred_day = None
                next_day = None
                nnext_day = None
                nnnext_day = None
                time = None
                next_time = None
                room_cat = None
            else:
                print(room, preferred_day, time, room_cat)
                for i in students:
                    print(f"aki ya ste tan update db : {i}")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnext_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnext_day}' AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnnext_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnnext_day}' AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnext_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnext_day}'AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnnext_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnnext_day}'AND Timeslot = '{next_time}'")
                    cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', NEXTDAY = '{next_day}', TIMESLOT = '{time}', NEXTTIMESLOT = '{next_time}',ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                    cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                    conn.commit()
                insert_assignment_more(cursor, conn, subject, section, room, preferred_day, time, student_ids, courses, enrolled, years, room_cat, next_day, next_time)
                print('inserted ya')
        else:
            room_schedule = ['XH105', 'XH201', 'XH202', 'XH203', 'XH204', 'XH301','XH302', 'XH303', 'XH304','XH305', 'XH401', 'XH402', 'XH403', 'XH404', 'XH405']
            room, preferred_day, next_day, nnext_day, nnnext_day, time, next_time, room_cat = get_schedule_bsn_more(students, enrolled, room_schedule, units)
            if room is None:
                preferred_day = None
                next_day = None
                nnext_day = None
                nnnext_day = None
                time = None
                next_time = None
                room_cat = None
            else:
                print(room, preferred_day, time, room_cat)
                for i in students:
                    print(f"aki ya ste tan update db : {i}")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnext_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnext_day}' AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnnext_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnnext_day}' AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnext_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnext_day}'AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnnext_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnnext_day}'AND Timeslot = '{next_time}'")
                    cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', NEXTDAY = '{next_day}', TIMESLOT = '{time}', NEXTTIMESLOT = '{next_time}',ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                    cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                    conn.commit()
                insert_assignment_more(cursor, conn, subject, section, room, preferred_day, time, student_ids, courses, enrolled, years, room_cat, next_day, next_time)
                print('inserted ya')
    elif total_enrolled_count <=50:
        section = 'A'
        cursor.execute(f"SELECT ID, COURSE, YEAR FROM duplicate WHERE SUBJECT = '{subject}' LIMIT 10")
        x = cursor.fetchall()
        print(f"este del x {len(x)}")
        students = [str(w[0]) for w in x]
        student_ids = ','.join([str(w[0]) for w in x]) 
        enrolled = len(x)
        print(f"students {len(students)}")
        print(f"enrolled {enrolled}")
        print(f"student id {student_ids}")
        course =  set([str(w[1]).strip() for w in x])
        courses = ','.join(set([str(w[1]).strip() for w in x]))
        year = set([str(w[2]).strip() for w in x])
        years = ','.join(set([str(w[2]).strip() for w in x]))
        print(f"course to {courses}")
        print(f"years to {years}")
        print(subject)
        if units == 2:
            room_schedule = ['XH105', 'XH201', 'XH202', 'XH203', 'XH204', 'XH301','XH302', 'XH303', 'XH304','XH305', 'XH401', 'XH402', 'XH403', 'XH404', 'XH405']
            print(f"room_schedule to : {room_schedule}")
            room, preferred_day, next_day, time, next_time, room_cat, check = bsn_2units(students, enrolled, room_schedule)
            if room is None:
                print("Wala room")
            else:
                for i in students:
                    print(f"aki ya ste tan update db : {i}")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{check}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{check}'")
                    cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', NEXTDAY = '{next_day}', TIMESLOT = '{time}', NEXTTIMESLOT = '{next_time}',ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                    cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                    conn.commit()
                insert_assignment_more(cursor, conn, subject, section, room, preferred_day, time, student_ids, courses, enrolled, years, room_cat, next_day, next_time)
                print('inserted ya')
        elif subject == 'NURBIO LEC':
            room_schedule = ['C311']
            print(f"room_schedule to : {room_schedule}")
            room, preferred_day, next_day, nnext_day, nnnext_day, time, next_time, room_cat = get_schedule_bsn_more(students, enrolled, room_schedule, units = 3)
            if room is None:
                preferred_day = None
                next_day = None
                nnext_day = None
                nnnext_day = None
                time = None
                next_time = None
                room_cat = None
            else:
                print(room, preferred_day, time, room_cat)
                for i in students:
                    print(f"aki ya ste tan update db : {i}")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnext_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnext_day}' AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnnext_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnnext_day}' AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnext_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnext_day}'AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnnext_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnnext_day}'AND Timeslot = '{next_time}'")
                    cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', NEXTDAY = '{next_day}', TIMESLOT = '{time}', NEXTTIMESLOT = '{next_time}',ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                    cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                    conn.commit()
                insert_assignment_more(cursor, conn, subject, section, room, preferred_day, time, student_ids, courses, enrolled, years, room_cat, next_day, next_time)
                print('inserted ya')
        elif subject == 'NURBIO LAB':
            room_schedule = ['C308','C310']
            print(f"room_schedule to : {room_schedule}")
            room, preferred_day, next_day, nnext_day, nnnext_day, time, next_time, room_cat = get_schedule_bsn_more(students, enrolled, room_schedule, units = 6)   
            if room is None:
                preferred_day = None
                next_day = None
                nnext_day = None
                nnnext_day = None
                time = None
                next_time = None
                room_cat = None
            else:
                print(room, preferred_day, time, room_cat)
                for i in students:
                    print(f"aki ya ste tan update db : {i}")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnext_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnext_day}' AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnnext_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnnext_day}' AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnext_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnext_day}'AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnnext_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnnext_day}'AND Timeslot = '{next_time}'")
                    cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', NEXTDAY = '{next_day}', TIMESLOT = '{time}', NEXTTIMESLOT = '{next_time}',ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                    cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                    conn.commit()
                insert_assignment_more(cursor, conn, subject, section, room, preferred_day, time, student_ids, courses, enrolled, years, room_cat, next_day, next_time)
                print('inserted ya')
        else:
            room_schedule = ['XH105', 'XH201', 'XH202', 'XH203', 'XH204', 'XH301','XH302', 'XH303', 'XH304','XH305', 'XH401', 'XH402', 'XH403', 'XH404', 'XH405']
            room, preferred_day, next_day, nnext_day, nnnext_day, time, next_time, room_cat = get_schedule_bsn_more(students, enrolled, room_schedule, units)
            if room is None:
                preferred_day = None
                next_day = None
                nnext_day = None
                nnnext_day = None
                time = None
                next_time = None
                room_cat = None
            else:
                print(room, preferred_day, time, room_cat)
                for i in students:
                    print(f"aki ya ste tan update db : {i}")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnext_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnext_day}' AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnnext_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnnext_day}' AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnext_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnext_day}'AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnnext_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnnext_day}'AND Timeslot = '{next_time}'")
                    cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', NEXTDAY = '{next_day}', TIMESLOT = '{time}', NEXTTIMESLOT = '{next_time}',ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                    cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                    conn.commit()
                insert_assignment_more(cursor, conn, subject, section, room, preferred_day, time, student_ids, courses, enrolled, years, room_cat, next_day, next_time)
                print('inserted ya')
        section = 'B'
        print("second ya")
        remainder = total_enrolled_count-10
        cursor.execute(f"SELECT ID, COURSE, YEAR FROM duplicate WHERE SUBJECT = '{subject}' LIMIT {remainder}")
        x = cursor.fetchall()
        print(len(x))
        students = [str(w[0]) for w in x]
        student_ids = ','.join([str(w[0]) for w in x]) 
        enrolled = len(x)
        print(f"student {len(students)}")
        print(enrolled)
        print(student_ids)
        course =  set([str(w[1]).strip() for w in x])
        courses = ','.join(set([str(w[1]).strip() for w in x]))
        year = set([str(w[2]).strip() for w in x])
        years = ','.join(set([str(w[2]).strip() for w in x]))
        print(f"course to {courses}")
        print(f"years to {years}")
        print(subject)
        if units == 2:
            room_schedule = ['XH105', 'XH201', 'XH202', 'XH203', 'XH204', 'XH301','XH302', 'XH303', 'XH304','XH305', 'XH401', 'XH402', 'XH403', 'XH404', 'XH405']
            print(f"room_schedule to : {room_schedule}")
            room, preferred_day, next_day, time, next_time, room_cat, check = bsn_2units(students, enrolled, room_schedule)
            if room is None:
                print("Wala room")
            else:
                for i in students:
                    print(f"aki ya ste tan update db : {i}")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{check}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{check}'")
                    cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', NEXTDAY = '{next_day}', TIMESLOT = '{time}', NEXTTIMESLOT = '{next_time}',ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                    cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                    conn.commit()
                insert_assignment_more(cursor, conn, subject, section, room, preferred_day, time, student_ids, courses, enrolled, years, room_cat, next_day, next_time)
                print('inserted ya')
        elif subject == 'NURBIO LEC':
            room_schedule = ['C311']
            print(f"room_schedule to : {room_schedule}")
            room, preferred_day, next_day, nnext_day, nnnext_day, time, next_time, room_cat = get_schedule_bsn_more(students, enrolled, room_schedule, units = 3)
            if room is None:
                preferred_day = None
                next_day = None
                nnext_day = None
                nnnext_day = None
                time = None
                next_time = None
                room_cat = None
            else:
                print(room, preferred_day, time, room_cat)
                for i in students:
                    print(f"aki ya ste tan update db : {i}")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnext_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnext_day}' AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnnext_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnnext_day}' AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnext_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnext_day}'AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnnext_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnnext_day}'AND Timeslot = '{next_time}'")
                    cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', NEXTDAY = '{next_day}', TIMESLOT = '{time}', NEXTTIMESLOT = '{next_time}',ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                    cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                    conn.commit()
                insert_assignment_more(cursor, conn, subject, section, room, preferred_day, time, student_ids, courses, enrolled, years, room_cat, next_day, next_time)
                print('inserted ya')
        elif subject == 'NURBIO LAB':
            room_schedule = ['C308','C310']
            print(f"room_schedule to : {room_schedule}")
            room, preferred_day, next_day, nnext_day, nnnext_day, time, next_time, room_cat = get_schedule_bsn_more(students, enrolled, room_schedule, units = 6)   
            if room is None:
                preferred_day = None
                next_day = None
                nnext_day = None
                nnnext_day = None
                time = None
                next_time = None
                room_cat = None
            else:
                print(room, preferred_day, time, room_cat)
                for i in students:
                    print(f"aki ya ste tan update db : {i}")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnext_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnext_day}' AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnnext_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnnext_day}' AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnext_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnext_day}'AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnnext_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnnext_day}'AND Timeslot = '{next_time}'")
                    cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', NEXTDAY = '{next_day}', TIMESLOT = '{time}', NEXTTIMESLOT = '{next_time}',ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                    cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                    conn.commit()
                insert_assignment_more(cursor, conn, subject, section, room, preferred_day, time, student_ids, courses, enrolled, years, room_cat, next_day, next_time)
                print('inserted ya')
        else:
            room_schedule = ['XH105', 'XH201', 'XH202', 'XH203', 'XH204', 'XH301','XH302', 'XH303', 'XH304','XH305', 'XH401', 'XH402', 'XH403', 'XH404', 'XH405']
            room, preferred_day, next_day, nnext_day, nnnext_day, time, next_time, room_cat = get_schedule_bsn_more(students, enrolled, room_schedule, units)
            if room is None:
                preferred_day = None
                next_day = None
                nnext_day = None
                nnnext_day = None
                time = None
                next_time = None
                room_cat = None
            else:
                print(room, preferred_day, time, room_cat)
                for i in students:
                    print(f"aki ya ste tan update db : {i}")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnext_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnext_day}' AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnnext_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnnext_day}' AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnext_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnext_day}'AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnnext_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnnext_day}'AND Timeslot = '{next_time}'")
                    cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', NEXTDAY = '{next_day}', TIMESLOT = '{time}', NEXTTIMESLOT = '{next_time}',ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                    cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                    conn.commit()
                insert_assignment_more(cursor, conn, subject, section, room, preferred_day, time, student_ids, courses, enrolled, years, room_cat, next_day, next_time)
                print('inserted ya')
    elif total_enrolled_count > 50:
        iterations = math.ceil(total_enrolled_count/35)
        print(iterations)
        for n in range(iterations):
            print(n)
            section = sections[n]
            print(section)
            cursor.execute(f"SELECT ID, COURSE, YEAR FROM duplicate WHERE SUBJECT = '{subject}' LIMIT 35")
            x = cursor.fetchall()
            print(x)
            print(f"este del x {len(x)}")
            students = [str(w[0]) for w in x]
            student_ids = ','.join([str(w[0]) for w in x]) 
            enrolled = len(x)
            print(f"student {len(students)}")
            print(f"enrolled {enrolled}")
            print(f"student id {student_ids}")
            course =  set([str(w[1]).strip() for w in x])
            courses = ','.join(set([str(w[1]).strip() for w in x]))
            year = set([str(w[2]).strip() for w in x])
            years = ','.join(set([str(w[2]).strip() for w in x]))
            print(f"course to {courses}")
            print(f"years to {years}")
            print(subject)
            if units == 2:
                room_schedule = ['XH105', 'XH201', 'XH202', 'XH203', 'XH204', 'XH301','XH302', 'XH303', 'XH304','XH305', 'XH401', 'XH402', 'XH403', 'XH404', 'XH405']
                print(f"room_schedule to : {room_schedule}")
                room, preferred_day, next_day, time, next_time, room_cat, check = bsn_2units(students, enrolled, room_schedule)
                if room is None:
                    print("Wala room")
                else:
                    for i in students:
                        print(f"aki ya ste tan update db : {i}")
                        cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{time}'")
                        cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{check}'")
                        cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                        cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{check}'")
                        cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', NEXTDAY = '{next_day}', TIMESLOT = '{time}', NEXTTIMESLOT = '{next_time}',ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                        cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                        conn.commit()
                    insert_assignment_more(cursor, conn, subject, section, room, preferred_day, time, student_ids, courses, enrolled, years, room_cat, next_day, next_time)
                    print('inserted ya')
            elif subject == 'NURBIO LEC':
                room_schedule = ['C311']
                print(f"room_schedule to : {room_schedule}")
                room, preferred_day, next_day, nnext_day, nnnext_day, time, next_time, room_cat = get_schedule_bsn_more(students, enrolled, room_schedule, units = 3)
                if room is None:
                    preferred_day = None
                    next_day = None
                    nnext_day = None
                    nnnext_day = None
                    time = None
                    next_time = None
                    room_cat = None
                else:
                    print(room, preferred_day, time, room_cat)
                    for i in students:
                        print(f"aki ya ste tan update db : {i}")
                        cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{time}'")
                        cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{next_time}'")
                        cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnext_day}' AND Timeslot = '{time}'")
                        cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnext_day}' AND Timeslot = '{next_time}'")
                        cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnnext_day}' AND Timeslot = '{time}'")
                        cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnnext_day}' AND Timeslot = '{next_time}'")
                        cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                        cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{next_time}'")
                        cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnext_day}'AND Timeslot = '{time}'")
                        cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnext_day}'AND Timeslot = '{next_time}'")
                        cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnnext_day}'AND Timeslot = '{time}'")
                        cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnnext_day}'AND Timeslot = '{next_time}'")
                        cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', NEXTDAY = '{next_day}', TIMESLOT = '{time}', NEXTTIMESLOT = '{next_time}',ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                        cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                        conn.commit()
                    insert_assignment_more(cursor, conn, subject, section, room, preferred_day, time, student_ids, courses, enrolled, years, room_cat, next_day, next_time)
                    print('inserted ya')
            elif subject == 'NURBIO LAB':
                room_schedule = ['C308','C310']
                print(f"room_schedule to : {room_schedule}")
                room, preferred_day, next_day, nnext_day, nnnext_day, time, next_time, room_cat = get_schedule_bsn_more(students, enrolled, room_schedule, units = 6)   
                if room is None:
                    preferred_day = None
                    next_day = None
                    nnext_day = None
                    nnnext_day = None
                    time = None
                    next_time = None
                    room_cat = None
                else:
                    print(room, preferred_day, time, room_cat)
                    for i in students:
                        print(f"aki ya ste tan update db : {i}")
                        cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{time}'")
                        cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{next_time}'")
                        cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnext_day}' AND Timeslot = '{time}'")
                        cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnext_day}' AND Timeslot = '{next_time}'")
                        cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnnext_day}' AND Timeslot = '{time}'")
                        cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnnext_day}' AND Timeslot = '{next_time}'")
                        cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                        cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{next_time}'")
                        cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnext_day}'AND Timeslot = '{time}'")
                        cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnext_day}'AND Timeslot = '{next_time}'")
                        cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnnext_day}'AND Timeslot = '{time}'")
                        cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnnext_day}'AND Timeslot = '{next_time}'")
                        cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', NEXTDAY = '{next_day}', TIMESLOT = '{time}', NEXTTIMESLOT = '{next_time}',ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                        cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                        conn.commit()
                    insert_assignment_more(cursor, conn, subject, section, room, preferred_day, time, student_ids, courses, enrolled, years, room_cat, next_day, next_time)
                    print('inserted ya')
            else:
                room_schedule = ['XH105', 'XH201', 'XH202', 'XH203', 'XH204', 'XH301','XH302', 'XH303', 'XH304','XH305', 'XH401', 'XH402', 'XH403', 'XH404', 'XH405']
                room, preferred_day, next_day, nnext_day, nnnext_day, time, next_time, room_cat = get_schedule_bsn_more(students, enrolled, room_schedule, units)
                if room is None:
                    preferred_day = None
                    next_day = None
                    nnext_day = None
                    nnnext_day = None
                    time = None
                    next_time = None
                    room_cat = None
                else:
                    print(room, preferred_day, time, room_cat)
                    for i in students:
                        print(f"aki ya ste tan update db : {i}")
                        cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{time}'")
                        cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{next_time}'")
                        cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnext_day}' AND Timeslot = '{time}'")
                        cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnext_day}' AND Timeslot = '{next_time}'")
                        cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnnext_day}' AND Timeslot = '{time}'")
                        cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnnext_day}' AND Timeslot = '{next_time}'")
                        cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                        cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{next_time}'")
                        cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnext_day}'AND Timeslot = '{time}'")
                        cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnext_day}'AND Timeslot = '{next_time}'")
                        cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnnext_day}'AND Timeslot = '{time}'")
                        cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnnext_day}'AND Timeslot = '{next_time}'")
                        cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', NEXTDAY = '{next_day}', TIMESLOT = '{time}', NEXTTIMESLOT = '{next_time}',ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                        cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                        conn.commit()
                    insert_assignment_more(cursor, conn, subject, section, room, preferred_day, time, student_ids, courses, enrolled, years, room_cat, next_day, next_time)
                    print('inserted ya')

#pathfit
query = """
    SELECT
    SUBJECT,
    GROUP_CONCAT(ID ORDER BY SUBJECT) AS id_numbers,
    COUNT(ID) AS enrolled_count
    FROM
        duplicate
    WHERE
        UNITS = 2 AND SUBJECT NOT LIKE '%LAB%' AND SUBJECT NOT LIKE '%NCM%'
    GROUP BY
        SUBJECT
    ORDER BY
        SUBJECT

"""

cursor.execute(query)
initial = cursor.fetchall()
counter = 0
sections = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z','AA','BB','CC','DD','EE','FF','GG','HH','II','JJ','KK','LL','MM','NN','OO','PP','QQ','RR']

for row in initial:
    counter += 1
    subject = row[0]
    total_enrolled_count = row[2]
    print(subject, total_enrolled_count)
    if total_enrolled_count <= 35:
        section = 'A'
        cursor.execute(f"SELECT ID, COURSE, YEAR FROM duplicate WHERE SUBJECT = '{subject}'")
        x = cursor.fetchall()
        print(x)
        print(f"este del x {len(x)}")
        students = [str(w[0]) for w in x]
        student_ids = ','.join([str(w[0]) for w in x]) 
        enrolled = len(x)
        print(f"students {len(students)}")
        print(f"enrolled {enrolled}")
        print(f"student id {student_ids}")
        course =  set([str(w[1]).strip() for w in x])
        courses = ','.join(set([str(w[1]).strip() for w in x]))
        print(f"course to {courses}")
        year = set([str(w[2]).strip() for w in x])
        years = ','.join(set([str(w[2]).strip() for w in x]))
        print(f"years to {years}")
        if subject == 'PATHFIT1' or subject == 'PATHFIT 3'or subject == 'PATHFIT3':
            room_schedule = ['MPCC1A','MPCC1B','MPCC1C','MPCC1D']
            print(f"room_schedule to : {room_schedule}")
            room, preferred_day, time, room_cat, check, ccheck = get_schedule_path(students, enrolled, room_schedule)
            if room is None:
                print("wala")
            else:
                print(room, preferred_day, time, room_cat)
                for i in students:
                    print(f"aki ya ste tan update db : {i}")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{check}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{ccheck}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', TIMESLOT = '{time}', ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                    cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                    conn.commit()
                insert_assignment_path(cursor, conn, subject, section, room, preferred_day, time, student_ids, courses, enrolled, years, room_cat)
                print('done')
        else:
            room_schedule = get_room_available(enrolled)
            print(f"room_schedule to : {room_schedule}")
            room, preferred_day, time, room_cat, check, ccheck = get_schedule_regular(students, enrolled, room_schedule)
            if room is None:
                print("wala")
            else:
                print(room, preferred_day, time, room_cat)
                for i in students:
                    print(f"aki ya ste tan update db : {i}")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{check}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{ccheck}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', TIMESLOT = '{time}', ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                    cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                    conn.commit()
                insert_assignment_path(cursor, conn, subject, section, room, preferred_day, time, student_ids, courses, enrolled, years, room_cat)
                print('done')
    elif total_enrolled_count <=50:
        section = 'A'
        cursor.execute(f"SELECT ID, COURSE, YEAR FROM duplicate WHERE SUBJECT = '{subject}' LIMIT 10")
        x = cursor.fetchall()
        print(f"este del x {len(x)}")
        students = [str(w[0]) for w in x]
        student_ids = ','.join([str(w[0]) for w in x]) 
        enrolled = len(x)
        print(f"students {len(students)}")
        print(f"enrolled {enrolled}")
        print(f"student id {student_ids}")
        course =  set([str(w[1]).strip() for w in x])
        courses = ','.join(set([str(w[1]).strip() for w in x]))
        year = set([str(w[2]).strip() for w in x])
        years = ','.join(set([str(w[2]).strip() for w in x]))
        print(f"course to {courses}")
        print(f"years to {years}")
        if subject == 'PATHFIT1' or subject == 'PATHFIT 3'or subject == 'PATHFIT3':
            room_schedule = ['MPCC1A','MPCC1B','MPCC1C','MPCC1D']
            print(f"room_schedule to : {room_schedule}")
            room, preferred_day, time, room_cat, check, ccheck = get_schedule_path(students, enrolled, room_schedule)
            if room is None:
                print("wala")
            else:
                print(room, preferred_day, time, room_cat)
                for i in students:
                    print(f"aki ya ste tan update db : {i}")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{check}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{ccheck}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', TIMESLOT = '{time}', ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                    cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                    conn.commit()
                insert_assignment_path(cursor, conn, subject, section, room, preferred_day, time, student_ids, courses, enrolled, years, room_cat)
                print('done')
        else:
            room_schedule = get_room_available(enrolled)
            print(f"room_schedule to : {room_schedule}")
            room, preferred_day, time, room_cat, check, ccheck = get_schedule_regular(students, enrolled, room_schedule)
            if room is None:
                print("wala")
            else:
                print(room, preferred_day, time, room_cat)
                for i in students:
                    print(f"aki ya ste tan update db : {i}")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{check}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{ccheck}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', TIMESLOT = '{time}', ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                    cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                    conn.commit()
                insert_assignment_path(cursor, conn, subject, section, room, preferred_day, time, student_ids, courses, enrolled, years, room_cat)
                print('done')

        section = 'B'
        print("second ya")
        remainder = total_enrolled_count-10
        cursor.execute(f"SELECT ID, COURSE, YEAR FROM duplicate WHERE SUBJECT = '{subject}' LIMIT {remainder}")
        x = cursor.fetchall()
        print(len(x))
        students = [str(w[0]) for w in x]
        student_ids = ','.join([str(w[0]) for w in x]) 
        enrolled = len(x)
        print(f"student {len(students)}")
        print(enrolled)
        print(student_ids)
        course =  set([str(w[1]).strip() for w in x])
        courses = ','.join(set([str(w[1]).strip() for w in x]))
        year = set([str(w[2]).strip() for w in x])
        years = ','.join(set([str(w[2]).strip() for w in x]))
        print(f"course to {courses}")
        print(f"years to {years}")
        if subject == 'PATHFIT1' or subject == 'PATHFIT 3'or subject == 'PATHFIT3':
            room_schedule = ['MPCC1A','MPCC1B','MPCC1C','MPCC1D']
            print(f"room_schedule to : {room_schedule}")
            room, preferred_day, time, room_cat, check, ccheck = get_schedule_path(students, enrolled, room_schedule)
            if room is None:
                print("wala")
            else:
                print(room, preferred_day, time, room_cat)
                for i in students:
                    print(f"aki ya ste tan update db : {i}")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{check}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{ccheck}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', TIMESLOT = '{time}', ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                    cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                    conn.commit()
                insert_assignment_path(cursor, conn, subject, section, room, preferred_day, time, student_ids, courses, enrolled, years, room_cat)
                print('done')
        else:
            room_schedule = get_room_available(enrolled)
            print(f"room_schedule to : {room_schedule}")
            room, preferred_day, time, room_cat, check, ccheck = get_schedule_regular(students, enrolled, room_schedule)
            if room is None:
                print("wala")
            else:
                print(room, preferred_day, time, room_cat)
                for i in students:
                    print(f"aki ya ste tan update db : {i}")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{check}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{ccheck}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', TIMESLOT = '{time}', ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                    cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                    conn.commit()
                insert_assignment_path(cursor, conn, subject, section, room, preferred_day, time, student_ids, courses, enrolled, years, room_cat)
                print('done')   
    elif total_enrolled_count > 50:
        iterations = math.ceil(total_enrolled_count/35)
        print(iterations)
        for n in range(iterations):
            print(n)
            section = sections[n]
            print(section)
            cursor.execute(f"SELECT ID, COURSE, YEAR FROM duplicate WHERE SUBJECT = '{subject}' LIMIT 35")
            x = cursor.fetchall()
            print(x)
            print(f"este del x {len(x)}")
            students = [str(w[0]) for w in x]
            student_ids = ','.join([str(w[0]) for w in x]) 
            enrolled = len(x)
            print(f"student {len(students)}")
            print(f"enrolled {enrolled}")
            print(f"student id {student_ids}")
            course =  set([str(w[1]).strip() for w in x])
            courses = ','.join(set([str(w[1]).strip() for w in x]))
            year = set([str(w[2]).strip() for w in x])
            years = ','.join(set([str(w[2]).strip() for w in x]))
            print(f"course to {courses}")
            print(f"years to {years}")
            if subject == 'PATHFIT1' or subject == 'PATHFIT 3'or subject == 'PATHFIT3':
                room_schedule = ['MPCC1A','MPCC1B','MPCC1C','MPCC1D']
                print(f"room_schedule to : {room_schedule}")
                room, preferred_day, time, room_cat, check, ccheck = get_schedule_path(students, enrolled, room_schedule)
                if room is None:
                    print("wala")
                else:
                    print(room, preferred_day, time, room_cat)
                    for i in students:
                        print(f"aki ya ste tan update db : {i}")
                        cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{check}'")
                        cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{ccheck}'")
                        cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                        cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', TIMESLOT = '{time}', ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                        cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                        conn.commit()
                    insert_assignment_path(cursor, conn, subject, section, room, preferred_day, time, student_ids, courses, enrolled, years, room_cat)
                    print('done')
            else:
                room_schedule = get_room_available(enrolled)
                print(f"room_schedule to : {room_schedule}")
                room, preferred_day, time, room_cat, check, ccheck = get_schedule_regular(students, enrolled, room_schedule)
                if room is None:
                    print("wala")
                else:
                    print(room, preferred_day, time, room_cat)
                    for i in students:
                        print(f"aki ya ste tan update db : {i}")
                        cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{check}'")
                        cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{ccheck}'")
                        cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                        cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', TIMESLOT = '{time}', ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                        cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                        conn.commit()
                    insert_assignment_path(cursor, conn, subject, section, room, preferred_day, time, student_ids, courses, enrolled, years, room_cat)
                    print('done')



#NSTPP
query = """
    SELECT
    SUBJECT,
    UNITS,
    GROUP_CONCAT(ID ORDER BY SUBJECT, COURSE, YEAR) AS id_numbers,
    COUNT(ID) AS enrolled_count
    FROM
        duplicate
    WHERE
        SUBJECT LIKE '%NSTP%'
    GROUP BY
        SUBJECT
    ORDER BY
        SUBJECT, COURSE, YEAR

"""
cursor.execute(query)
initial = cursor.fetchall()
counter = 0
sections = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z','AA','BB','CC','DD','EE','FF','GG','HH','II','JJ','KK','LL','MM','NN','OO','PP','QQ','RR']

for row in initial:
    counter += 1
    subject = row[0]
    units = row[1]
    total_enrolled_count = row[3]
    print(subject, total_enrolled_count)
    print(units)
    if total_enrolled_count <= 35:
        section = 'A'
        cursor.execute(f"SELECT ID, COURSE, YEAR FROM duplicate WHERE SUBJECT = '{subject}'")
        x = cursor.fetchall()
        print(x)
        print(f"este del x {len(x)}")
        students = [str(w[0]) for w in x]
        student_ids = ','.join([str(w[0]) for w in x]) 
        enrolled = len(x)
        print(f"students {len(students)}")
        print(f"enrolled {enrolled}")
        print(f"student id {student_ids}")
        course =  set([str(w[1]).strip() for w in x])
        courses = ','.join(set([str(w[1]).strip() for w in x]))
        print(f"course to {courses}")
        year = set([str(w[2]).strip() for w in x])
        years = ','.join(set([str(w[2]).strip() for w in x]))
        print(f"years to {years}")
        print(subject)
        all_bsn = all(c.strip() == 'BSN' for c in course)
        all_first = all_first = all(y.strip()== '1' for y in year)
        if all_bsn or all_first:
            if all_bsn:
                room_schedule = ['XH105', 'XH201', 'XH202', 'XH203', 'XH204', 'XH301','XH302', 'XH303', 'XH304','XH305', 'XH401', 'XH402', 'XH403', 'XH404', 'XH405']
            elif all_first:
                room_schedule = get_room_available(enrolled)
            room, preferred_day, next_day, nnext_day, nnnext_day, time, next_time, room_cat = get_schedule_bsn_more(students, enrolled, room_schedule, units = 3)
            for i in students:
                print(f"aki ya ste tan update db : {i}")
                cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{time}'")
                cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{next_day}' AND Timeslot = '{next_time}'")
                cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{next_day}'AND Timeslot = '{next_time}'")
                cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', NEXTDAY = '{next_day}', TIMESLOT = '{time}', NEXTTIMESLOT = '{next_time}',ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                conn.commit()
            next_timeslot = next_time
            insert_assignment(cursor, conn, subject, section, room, preferred_day, next_day, time, next_timeslot, student_ids, courses, enrolled, years, room_cat)
            print('done')
        else:
            room_schedule = get_room_available(enrolled)
            room, preferred_day, next_day, time, next_timeslot, room_cat = get_schedule_mix_straight(students, enrolled, room_schedule, units)
            if room is None:
                print("wala")
            else:
                print(room, preferred_day, next_day, time, next_time, room_cat)
                for i in students:
                    print(f"aki ya ste tan update db : {i}")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{next_day}' AND Timeslot = '{next_timeslot}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{next_day}'AND Timeslot = '{next_timeslot}'")
                    cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', NEXTDAY = '{next_day}', TIMESLOT = '{time}', NEXTTIMESLOT = '{next_timeslot}',ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                    cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                    conn.commit()
                insert_assignment(cursor, conn, subject, section, room, preferred_day, next_day, time, next_timeslot, student_ids, courses, enrolled, years, room_cat)
                print('done')
    elif total_enrolled_count <=50:
        section = 'A'
        cursor.execute(f"SELECT ID, COURSE, YEAR FROM duplicate WHERE SUBJECT = '{subject}' LIMIT 10")
        x = cursor.fetchall()
        print(f"este del x {len(x)}")
        students = [str(w[0]) for w in x]
        student_ids = ','.join([str(w[0]) for w in x]) 
        enrolled = len(x)
        print(f"students {len(students)}")
        print(f"enrolled {enrolled}")
        print(f"student id {student_ids}")
        course =  set([str(w[1]).strip() for w in x])
        courses = ','.join(set([str(w[1]).strip() for w in x]))
        year = set([str(w[2]).strip() for w in x])
        years = ','.join(set([str(w[2]).strip() for w in x]))
        print(f"course to {courses}")
        print(f"years to {years}")
        print(subject)
        all_bsn = all(c.strip() == 'BSN' for c in course)
        all_first = all_first = all(y.strip()== '1' for y in year)
        if all_bsn or all_first:
            if all_bsn:
                room_schedule = ['XH105', 'XH201', 'XH202', 'XH203', 'XH204', 'XH301','XH302', 'XH303', 'XH304','XH305', 'XH401', 'XH402', 'XH403', 'XH404', 'XH405']
            elif all_first:
                room_schedule = get_room_available(enrolled)
            room, preferred_day, next_day, nnext_day, nnnext_day, time, next_time, room_cat = get_schedule_bsn_more(students, enrolled, room_schedule, units = 3)
            for i in students:
                print(f"aki ya ste tan update db : {i}")
                cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{time}'")
                cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{next_day}' AND Timeslot = '{next_time}'")
                cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{next_day}'AND Timeslot = '{next_time}'")
                cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', NEXTDAY = '{next_day}', TIMESLOT = '{time}', NEXTTIMESLOT = '{next_time}',ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                conn.commit()
            next_timeslot = next_time
            insert_assignment(cursor, conn, subject, section, room, preferred_day, next_day, time, next_timeslot, student_ids, courses, enrolled, years, room_cat)
            print('done')
        else:
            room_schedule = get_room_available(enrolled)
            room, preferred_day, next_day, time, next_timeslot, room_cat = get_schedule_mix_straight(students, enrolled, room_schedule, units)
            if room is None:
                print("wala")
            else:
                print(room, preferred_day, next_day, time, next_time, room_cat)
                for i in students:
                    print(f"aki ya ste tan update db : {i}")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{next_day}' AND Timeslot = '{next_timeslot}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{next_day}'AND Timeslot = '{next_timeslot}'")
                    cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', NEXTDAY = '{next_day}', TIMESLOT = '{time}', NEXTTIMESLOT = '{next_timeslot}',ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                    cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                    conn.commit()
                insert_assignment(cursor, conn, subject, section, room, preferred_day, next_day, time, next_timeslot, student_ids, courses, enrolled, years, room_cat)
                print('done')
    elif total_enrolled_count > 50:
        iterations = math.ceil(total_enrolled_count/35)
        print(iterations)
        for n in range(iterations):
            print(n)
            section = sections[n]
            print(section)
            cursor.execute(f"SELECT ID, COURSE, YEAR FROM duplicate WHERE SUBJECT = '{subject}' LIMIT 35")
            x = cursor.fetchall()
            print(x)
            print(f"este del x {len(x)}")
            students = [str(w[0]) for w in x]
            student_ids = ','.join([str(w[0]) for w in x]) 
            enrolled = len(x)
            print(f"student {len(students)}")
            print(f"enrolled {enrolled}")
            print(f"student id {student_ids}")
            course =  set([str(w[1]).strip() for w in x])
            courses = ','.join(set([str(w[1]).strip() for w in x]))
            year = set([str(w[2]).strip() for w in x])
            years = ','.join(set([str(w[2]).strip() for w in x]))
            print(f"course to {courses}")
            print(f"years to {years}")
            print(subject)
            all_bsn = all(c.strip() == 'BSN' for c in course)
            all_first = all_first = all(y.strip()== '1' for y in year)
            if all_bsn or all_first:
                if all_bsn:
                    room_schedule = ['XH105', 'XH201', 'XH202', 'XH203', 'XH204', 'XH301','XH302', 'XH303', 'XH304','XH305', 'XH401', 'XH402', 'XH403', 'XH404', 'XH405']
                elif all_first:
                    room_schedule = get_room_available(enrolled)
                room, preferred_day, next_day, nnext_day, nnnext_day, time, next_time, room_cat = get_schedule_bsn_more(students, enrolled, room_schedule, units = 3)
                for i in students:
                    print(f"aki ya ste tan update db : {i}")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{next_day}' AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{next_day}'AND Timeslot = '{next_time}'")
                    cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', NEXTDAY = '{next_day}', TIMESLOT = '{time}', NEXTTIMESLOT = '{next_time}',ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                    cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                    conn.commit()
                next_timeslot = next_time
                insert_assignment(cursor, conn, subject, section, room, preferred_day, next_day, time, next_timeslot, student_ids, courses, enrolled, years, room_cat)
                print('done')
            else:
                room_schedule = get_room_available(enrolled)
                room, preferred_day, next_day, time, next_timeslot, room_cat = get_schedule_mix_straight(students, enrolled, room_schedule, units)
                if room is None:
                    print("wala")
                else:
                    print(room, preferred_day, next_day, time, next_time, room_cat)
                    for i in students:
                        print(f"aki ya ste tan update db : {i}")
                        cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{time}'")
                        cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{next_day}' AND Timeslot = '{next_timeslot}'")
                        cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                        cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{next_day}'AND Timeslot = '{next_timeslot}'")
                        cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', NEXTDAY = '{next_day}', TIMESLOT = '{time}', NEXTTIMESLOT = '{next_timeslot}',ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                        cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                        conn.commit()
                    insert_assignment(cursor, conn, subject, section, room, preferred_day, next_day, time, next_timeslot, student_ids, courses, enrolled, years, room_cat)
                    print('done')

# BSN
query = """
    SELECT
    SUBJECT,
    UNITS,
    GROUP_CONCAT(ID ORDER BY SUBJECT, COURSE, YEAR) AS id_numbers,
    COUNT(ID) AS enrolled_count
    FROM
        duplicate
    WHERE
        COURSE = 'BSN' AND (SUBJECT LIKE '%NCM%' OR SUBJECT LIKE '%NUR%')
    GROUP BY
        SUBJECT
    ORDER BY
        SUBJECT, COURSE, YEAR

"""

cursor.execute(query)
initial = cursor.fetchall()
counter = 0
sections = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']

for row in initial:
    counter += 1
    subject = row[0]
    units = row[1]
    total_enrolled_count = row[3]
    print(subject, total_enrolled_count)
    print(units)
    if total_enrolled_count <= 35:
        section = 'A'
        cursor.execute(f"SELECT ID, COURSE, YEAR FROM duplicate WHERE SUBJECT = '{subject}'")
        x = cursor.fetchall()
        print(x)
        print(f"este del x {len(x)}")
        students = [str(w[0]) for w in x]
        student_ids = ','.join([str(w[0]) for w in x]) 
        enrolled = len(x)
        print(f"students {len(students)}")
        print(f"enrolled {enrolled}")
        print(f"student id {student_ids}")
        course =  set([str(w[1]).strip() for w in x])
        courses = ','.join(set([str(w[1]).strip() for w in x]))
        print(f"course to {courses}")
        year = set([str(w[2]).strip() for w in x])
        years = ','.join(set([str(w[2]).strip() for w in x]))
        print(f"years to {years}")
        print(subject)
        if units == 2:
            print("yessss")
            room_schedule = ['XH105', 'XH201', 'XH202', 'XH203', 'XH204', 'XH301','XH302', 'XH303', 'XH304','XH305', 'XH401', 'XH402', 'XH403', 'XH404', 'XH405']
            print(f"room_schedule to : {room_schedule}")
            room, preferred_day, next_day, time, next_time, room_cat, check = bsn_2units(students, enrolled, room_schedule)
            if room is None:
                print("Wala room")
            else:
                for i in students:
                    print(f"aki ya ste tan update db : {i}")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{check}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{check}'")
                    cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', NEXTDAY = '{next_day}', TIMESLOT = '{time}', NEXTTIMESLOT = '{next_time}',ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                    cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                    conn.commit()
                insert_assignment_more(cursor, conn, subject, section, room, preferred_day, time, student_ids, courses, enrolled, years, room_cat, next_day, next_time)
                print('inserted ya')
        elif subject == 'NURBIO LEC':
            room_schedule = ['C311']
            print(f"room_schedule to : {room_schedule}")
            room, preferred_day, next_day, nnext_day, nnnext_day, time, next_time, room_cat = get_schedule_bsn_more(students, enrolled, room_schedule, units = 3)
            if room is None:
                preferred_day = None
                next_day = None
                nnext_day = None
                nnnext_day = None
                time = None
                next_time = None
                room_cat = None
            else:
                print(room, preferred_day, time, room_cat)
                for i in students:
                    print(f"aki ya ste tan update db : {i}")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnext_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnext_day}' AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnnext_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnnext_day}' AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnext_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnext_day}'AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnnext_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnnext_day}'AND Timeslot = '{next_time}'")
                    cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', NEXTDAY = '{next_day}', TIMESLOT = '{time}', NEXTTIMESLOT = '{next_time}',ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                    cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                    conn.commit()
                insert_assignment_more(cursor, conn, subject, section, room, preferred_day, time, student_ids, courses, enrolled, years, room_cat, next_day, next_time)
                print('inserted ya')
        elif subject == 'NURBIO LAB':
            room_schedule = ['C308','C310']
            print(f"room_schedule to : {room_schedule}")
            room, preferred_day, next_day, nnext_day, nnnext_day, time, next_time, room_cat = get_schedule_bsn_more(students, enrolled, room_schedule, units = 6)   
            if room is None:
                preferred_day = None
                next_day = None
                nnext_day = None
                nnnext_day = None
                time = None
                next_time = None
                room_cat = None
            else:
                print(room, preferred_day, time, room_cat)
                for i in students:
                    print(f"aki ya ste tan update db : {i}")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnext_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnext_day}' AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnnext_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnnext_day}' AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnext_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnext_day}'AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnnext_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnnext_day}'AND Timeslot = '{next_time}'")
                    cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', NEXTDAY = '{next_day}', TIMESLOT = '{time}', NEXTTIMESLOT = '{next_time}',ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                    cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                    conn.commit()
                insert_assignment_more(cursor, conn, subject, section, room, preferred_day, time, student_ids, courses, enrolled, years, room_cat, next_day, next_time)
                print('inserted ya')
        else:
            room_schedule = ['XH105', 'XH201', 'XH202', 'XH203', 'XH204', 'XH301','XH302', 'XH303', 'XH304','XH305', 'XH401', 'XH402', 'XH403', 'XH404', 'XH405']
            room, preferred_day, next_day, nnext_day, nnnext_day, time, next_time, room_cat = get_schedule_bsn_more(students, enrolled, room_schedule, units)
            if room is None:
                preferred_day = None
                next_day = None
                nnext_day = None
                nnnext_day = None
                time = None
                next_time = None
                room_cat = None
            else:
                print(room, preferred_day, time, room_cat)
                for i in students:
                    print(f"aki ya ste tan update db : {i}")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnext_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnext_day}' AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnnext_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnnext_day}' AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnext_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnext_day}'AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnnext_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnnext_day}'AND Timeslot = '{next_time}'")
                    cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', NEXTDAY = '{next_day}', TIMESLOT = '{time}', NEXTTIMESLOT = '{next_time}',ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                    cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                    conn.commit()
                insert_assignment_more(cursor, conn, subject, section, room, preferred_day, time, student_ids, courses, enrolled, years, room_cat, next_day, next_time)
                print('inserted ya')
    elif total_enrolled_count <=50:
        section = 'A'
        cursor.execute(f"SELECT ID, COURSE, YEAR FROM duplicate WHERE SUBJECT = '{subject}' LIMIT 10")
        x = cursor.fetchall()
        print(f"este del x {len(x)}")
        students = [str(w[0]) for w in x]
        student_ids = ','.join([str(w[0]) for w in x]) 
        enrolled = len(x)
        print(f"students {len(students)}")
        print(f"enrolled {enrolled}")
        print(f"student id {student_ids}")
        course =  set([str(w[1]).strip() for w in x])
        courses = ','.join(set([str(w[1]).strip() for w in x]))
        year = set([str(w[2]).strip() for w in x])
        years = ','.join(set([str(w[2]).strip() for w in x]))
        print(f"course to {courses}")
        print(f"years to {years}")
        print(subject)
        if units == 2:
            room_schedule = ['XH105', 'XH201', 'XH202', 'XH203', 'XH204', 'XH301','XH302', 'XH303', 'XH304','XH305', 'XH401', 'XH402', 'XH403', 'XH404', 'XH405']
            print(f"room_schedule to : {room_schedule}")
            room, preferred_day, next_day, time, next_time, room_cat, check = bsn_2units(students, enrolled, room_schedule)
            if room is None:
                print("Wala room")
            else:
                for i in students:
                    print(f"aki ya ste tan update db : {i}")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{check}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{check}'")
                    cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', NEXTDAY = '{next_day}', TIMESLOT = '{time}', NEXTTIMESLOT = '{next_time}',ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                    cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                    conn.commit()
                insert_assignment_more(cursor, conn, subject, section, room, preferred_day, time, student_ids, courses, enrolled, years, room_cat, next_day, next_time)
                print('inserted ya')
        elif subject == 'NURBIO LEC':
            room_schedule = ['C311']
            print(f"room_schedule to : {room_schedule}")
            room, preferred_day, next_day, nnext_day, nnnext_day, time, next_time, room_cat = get_schedule_bsn_more(students, enrolled, room_schedule, units = 3)
            if room is None:
                preferred_day = None
                next_day = None
                nnext_day = None
                nnnext_day = None
                time = None
                next_time = None
                room_cat = None
            else:
                print(room, preferred_day, time, room_cat)
                for i in students:
                    print(f"aki ya ste tan update db : {i}")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnext_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnext_day}' AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnnext_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnnext_day}' AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnext_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnext_day}'AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnnext_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnnext_day}'AND Timeslot = '{next_time}'")
                    cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', NEXTDAY = '{next_day}', TIMESLOT = '{time}', NEXTTIMESLOT = '{next_time}',ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                    cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                    conn.commit()
                insert_assignment_more(cursor, conn, subject, section, room, preferred_day, time, student_ids, courses, enrolled, years, room_cat, next_day, next_time)
                print('inserted ya')
        elif subject == 'NURBIO LAB':
            room_schedule = ['C308','C310']
            print(f"room_schedule to : {room_schedule}")
            room, preferred_day, next_day, nnext_day, nnnext_day, time, next_time, room_cat = get_schedule_bsn_more(students, enrolled, room_schedule, units = 6)   
            if room is None:
                preferred_day = None
                next_day = None
                nnext_day = None
                nnnext_day = None
                time = None
                next_time = None
                room_cat = None
            else:
                print(room, preferred_day, time, room_cat)
                for i in students:
                    print(f"aki ya ste tan update db : {i}")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnext_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnext_day}' AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnnext_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnnext_day}' AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnext_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnext_day}'AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnnext_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnnext_day}'AND Timeslot = '{next_time}'")
                    cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', NEXTDAY = '{next_day}', TIMESLOT = '{time}', NEXTTIMESLOT = '{next_time}',ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                    cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                    conn.commit()
                insert_assignment_more(cursor, conn, subject, section, room, preferred_day, time, student_ids, courses, enrolled, years, room_cat, next_day, next_time)
                print('inserted ya')
        else:
            room_schedule = ['XH105', 'XH201', 'XH202', 'XH203', 'XH204', 'XH301','XH302', 'XH303', 'XH304','XH305', 'XH401', 'XH402', 'XH403', 'XH404', 'XH405']
            room, preferred_day, next_day, nnext_day, nnnext_day, time, next_time, room_cat = get_schedule_bsn_more(students, enrolled, room_schedule, units)
            if room is None:
                preferred_day = None
                next_day = None
                nnext_day = None
                nnnext_day = None
                time = None
                next_time = None
                room_cat = None
            else:
                print(room, preferred_day, time, room_cat)
                for i in students:
                    print(f"aki ya ste tan update db : {i}")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnext_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnext_day}' AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnnext_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnnext_day}' AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnext_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnext_day}'AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnnext_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnnext_day}'AND Timeslot = '{next_time}'")
                    cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', NEXTDAY = '{next_day}', TIMESLOT = '{time}', NEXTTIMESLOT = '{next_time}',ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                    cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                    conn.commit()
                insert_assignment_more(cursor, conn, subject, section, room, preferred_day, time, student_ids, courses, enrolled, years, room_cat, next_day, next_time)
                print('inserted ya')
        section = 'B'
        print("second ya")
        remainder = total_enrolled_count-10
        cursor.execute(f"SELECT ID, COURSE, YEAR FROM duplicate WHERE SUBJECT = '{subject}' LIMIT {remainder}")
        x = cursor.fetchall()
        print(len(x))
        students = [str(w[0]) for w in x]
        student_ids = ','.join([str(w[0]) for w in x]) 
        enrolled = len(x)
        print(f"student {len(students)}")
        print(enrolled)
        print(student_ids)
        course =  set([str(w[1]).strip() for w in x])
        courses = ','.join(set([str(w[1]).strip() for w in x]))
        year = set([str(w[2]).strip() for w in x])
        years = ','.join(set([str(w[2]).strip() for w in x]))
        print(f"course to {courses}")
        print(f"years to {years}")
        print(subject)
        if units == 2:
            room_schedule = ['XH105', 'XH201', 'XH202', 'XH203', 'XH204', 'XH301','XH302', 'XH303', 'XH304','XH305', 'XH401', 'XH402', 'XH403', 'XH404', 'XH405']
            print(f"room_schedule to : {room_schedule}")
            room, preferred_day, next_day, time, next_time, room_cat, check = bsn_2units(students, enrolled, room_schedule)
            if room is None:
                print("Wala room")
            else:
                for i in students:
                    print(f"aki ya ste tan update db : {i}")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{check}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{check}'")
                    cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', NEXTDAY = '{next_day}', TIMESLOT = '{time}', NEXTTIMESLOT = '{next_time}',ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                    cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                    conn.commit()
                insert_assignment_more(cursor, conn, subject, section, room, preferred_day, time, student_ids, courses, enrolled, years, room_cat, next_day, next_time)
                print('inserted ya')
        elif subject == 'NURBIO LEC':
            room_schedule = ['C311']
            print(f"room_schedule to : {room_schedule}")
            room, preferred_day, next_day, nnext_day, nnnext_day, time, next_time, room_cat = get_schedule_bsn_more(students, enrolled, room_schedule, units = 3)
            if room is None:
                preferred_day = None
                next_day = None
                nnext_day = None
                nnnext_day = None
                time = None
                next_time = None
                room_cat = None
            else:
                print(room, preferred_day, time, room_cat)
                for i in students:
                    print(f"aki ya ste tan update db : {i}")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnext_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnext_day}' AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnnext_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnnext_day}' AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnext_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnext_day}'AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnnext_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnnext_day}'AND Timeslot = '{next_time}'")
                    cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', NEXTDAY = '{next_day}', TIMESLOT = '{time}', NEXTTIMESLOT = '{next_time}',ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                    cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                    conn.commit()
                insert_assignment_more(cursor, conn, subject, section, room, preferred_day, time, student_ids, courses, enrolled, years, room_cat, next_day, next_time)
                print('inserted ya')
        elif subject == 'NURBIO LAB':
            room_schedule = ['C308','C310']
            print(f"room_schedule to : {room_schedule}")
            room, preferred_day, next_day, nnext_day, nnnext_day, time, next_time, room_cat = get_schedule_bsn_more(students, enrolled, room_schedule, units = 6)   
            if room is None:
                preferred_day = None
                next_day = None
                nnext_day = None
                nnnext_day = None
                time = None
                next_time = None
                room_cat = None
            else:
                print(room, preferred_day, time, room_cat)
                for i in students:
                    print(f"aki ya ste tan update db : {i}")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnext_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnext_day}' AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnnext_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnnext_day}' AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnext_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnext_day}'AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnnext_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnnext_day}'AND Timeslot = '{next_time}'")
                    cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', NEXTDAY = '{next_day}', TIMESLOT = '{time}', NEXTTIMESLOT = '{next_time}',ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                    cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                    conn.commit()
                insert_assignment_more(cursor, conn, subject, section, room, preferred_day, time, student_ids, courses, enrolled, years, room_cat, next_day, next_time)
                print('inserted ya')
        else:
            room_schedule = ['XH105', 'XH201', 'XH202', 'XH203', 'XH204', 'XH301','XH302', 'XH303', 'XH304','XH305', 'XH401', 'XH402', 'XH403', 'XH404', 'XH405']
            room, preferred_day, next_day, nnext_day, nnnext_day, time, next_time, room_cat = get_schedule_bsn_more(students, enrolled, room_schedule, units)
            if room is None:
                preferred_day = None
                next_day = None
                nnext_day = None
                nnnext_day = None
                time = None
                next_time = None
                room_cat = None
            else:
                print(room, preferred_day, time, room_cat)
                for i in students:
                    print(f"aki ya ste tan update db : {i}")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnext_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnext_day}' AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnnext_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnnext_day}' AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnext_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnext_day}'AND Timeslot = '{next_time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnnext_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnnext_day}'AND Timeslot = '{next_time}'")
                    cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', NEXTDAY = '{next_day}', TIMESLOT = '{time}', NEXTTIMESLOT = '{next_time}',ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                    cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                    conn.commit()
                insert_assignment_more(cursor, conn, subject, section, room, preferred_day, time, student_ids, courses, enrolled, years, room_cat, next_day, next_time)
                print('inserted ya')
    elif total_enrolled_count > 50:
        iterations = math.ceil(total_enrolled_count/35)
        print(iterations)
        for n in range(iterations):
            print(n)
            section = sections[n]
            print(section)
            cursor.execute(f"SELECT ID, COURSE, YEAR FROM duplicate WHERE SUBJECT = '{subject}' LIMIT 35")
            x = cursor.fetchall()
            print(x)
            print(f"este del x {len(x)}")
            students = [str(w[0]) for w in x]
            student_ids = ','.join([str(w[0]) for w in x]) 
            enrolled = len(x)
            print(f"student {len(students)}")
            print(f"enrolled {enrolled}")
            print(f"student id {student_ids}")
            course =  set([str(w[1]).strip() for w in x])
            courses = ','.join(set([str(w[1]).strip() for w in x]))
            year = set([str(w[2]).strip() for w in x])
            years = ','.join(set([str(w[2]).strip() for w in x]))
            print(f"course to {courses}")
            print(f"years to {years}")
            print(subject)
            if units == 2:
                room_schedule = ['XH105', 'XH201', 'XH202', 'XH203', 'XH204', 'XH301','XH302', 'XH303', 'XH304','XH305', 'XH401', 'XH402', 'XH403', 'XH404', 'XH405']
                print(f"room_schedule to : {room_schedule}")
                room, preferred_day, next_day, time, next_time, room_cat, check = bsn_2units(students, enrolled, room_schedule)
                if room is None:
                    print("Wala room")
                else:
                    for i in students:
                        print(f"aki ya ste tan update db : {i}")
                        cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{time}'")
                        cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{check}'")
                        cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                        cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{check}'")
                        cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', NEXTDAY = '{next_day}', TIMESLOT = '{time}', NEXTTIMESLOT = '{next_time}',ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                        cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                        conn.commit()
                    insert_assignment_more(cursor, conn, subject, section, room, preferred_day, time, student_ids, courses, enrolled, years, room_cat, next_day, next_time)
                    print('inserted ya')
            elif subject == 'NURBIO LEC':
                room_schedule = ['C311']
                print(f"room_schedule to : {room_schedule}")
                room, preferred_day, next_day, nnext_day, nnnext_day, time, next_time, room_cat = get_schedule_bsn_more(students, enrolled, room_schedule, units = 3)
                if room is None:
                    preferred_day = None
                    next_day = None
                    nnext_day = None
                    nnnext_day = None
                    time = None
                    next_time = None
                    room_cat = None
                else:
                    print(room, preferred_day, time, room_cat)
                    for i in students:
                        print(f"aki ya ste tan update db : {i}")
                        cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{time}'")
                        cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{next_time}'")
                        cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnext_day}' AND Timeslot = '{time}'")
                        cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnext_day}' AND Timeslot = '{next_time}'")
                        cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnnext_day}' AND Timeslot = '{time}'")
                        cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnnext_day}' AND Timeslot = '{next_time}'")
                        cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                        cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{next_time}'")
                        cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnext_day}'AND Timeslot = '{time}'")
                        cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnext_day}'AND Timeslot = '{next_time}'")
                        cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnnext_day}'AND Timeslot = '{time}'")
                        cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnnext_day}'AND Timeslot = '{next_time}'")
                        cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', NEXTDAY = '{next_day}', TIMESLOT = '{time}', NEXTTIMESLOT = '{next_time}',ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                        cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                        conn.commit()
                    insert_assignment_more(cursor, conn, subject, section, room, preferred_day, time, student_ids, courses, enrolled, years, room_cat, next_day, next_time)
                    print('inserted ya')
            elif subject == 'NURBIO LAB':
                room_schedule = ['C308','C310']
                print(f"room_schedule to : {room_schedule}")
                room, preferred_day, next_day, nnext_day, nnnext_day, time, next_time, room_cat = get_schedule_bsn_more(students, enrolled, room_schedule, units = 6)   
                if room is None:
                    preferred_day = None
                    next_day = None
                    nnext_day = None
                    nnnext_day = None
                    time = None
                    next_time = None
                    room_cat = None
                else:
                    print(room, preferred_day, time, room_cat)
                    for i in students:
                        print(f"aki ya ste tan update db : {i}")
                        cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{time}'")
                        cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{next_time}'")
                        cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnext_day}' AND Timeslot = '{time}'")
                        cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnext_day}' AND Timeslot = '{next_time}'")
                        cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnnext_day}' AND Timeslot = '{time}'")
                        cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnnext_day}' AND Timeslot = '{next_time}'")
                        cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                        cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{next_time}'")
                        cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnext_day}'AND Timeslot = '{time}'")
                        cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnext_day}'AND Timeslot = '{next_time}'")
                        cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnnext_day}'AND Timeslot = '{time}'")
                        cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnnext_day}'AND Timeslot = '{next_time}'")
                        cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', NEXTDAY = '{next_day}', TIMESLOT = '{time}', NEXTTIMESLOT = '{next_time}',ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                        cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                        conn.commit()
                    insert_assignment_more(cursor, conn, subject, section, room, preferred_day, time, student_ids, courses, enrolled, years, room_cat, next_day, next_time)
                    print('inserted ya')
            else:
                room_schedule = ['XH105', 'XH201', 'XH202', 'XH203', 'XH204', 'XH301','XH302', 'XH303', 'XH304','XH305', 'XH401', 'XH402', 'XH403', 'XH404', 'XH405']
                room, preferred_day, next_day, nnext_day, nnnext_day, time, next_time, room_cat = get_schedule_bsn_more(students, enrolled, room_schedule, units)
                if room is None:
                    preferred_day = None
                    next_day = None
                    nnext_day = None
                    nnnext_day = None
                    time = None
                    next_time = None
                    room_cat = None
                else:
                    print(room, preferred_day, time, room_cat)
                    for i in students:
                        print(f"aki ya ste tan update db : {i}")
                        cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{time}'")
                        cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{next_time}'")
                        cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnext_day}' AND Timeslot = '{time}'")
                        cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnext_day}' AND Timeslot = '{next_time}'")
                        cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnnext_day}' AND Timeslot = '{time}'")
                        cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{nnnext_day}' AND Timeslot = '{next_time}'")
                        cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                        cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{next_time}'")
                        cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnext_day}'AND Timeslot = '{time}'")
                        cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnext_day}'AND Timeslot = '{next_time}'")
                        cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnnext_day}'AND Timeslot = '{time}'")
                        cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{nnnext_day}'AND Timeslot = '{next_time}'")
                        cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', NEXTDAY = '{next_day}', TIMESLOT = '{time}', NEXTTIMESLOT = '{next_time}',ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                        cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                        conn.commit()
                    insert_assignment_more(cursor, conn, subject, section, room, preferred_day, time, student_ids, courses, enrolled, years, room_cat, next_day, next_time)
                    print('inserted ya')

#BS BIOO
query = """
    SELECT
    SUBJECT,
    GROUP_CONCAT(ID ORDER BY SUBJECT) AS id_numbers,
    COUNT(ID) AS enrolled_count
    FROM
        duplicate
    WHERE
        SUBJECT LIKE '%B%' AND COURSE = 'BSBIO'
    GROUP BY
        SUBJECT
    ORDER BY
        SUBJECT
"""

cursor.execute(query)
initial = cursor.fetchall()
counter = 0
sections = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z','AA','BB','CC','DD','EE','FF','GG','HH','II','JJ','KK','LL','MM','NN','OO','PP','QQ','RR']

for row in initial:
    counter += 1
    subject = row[0]
    total_enrolled_count = row[2]
    print(subject, total_enrolled_count)
    if total_enrolled_count <= 35:
        section = 'A'
        cursor.execute(f"SELECT ID, COURSE, YEAR FROM duplicate WHERE SUBJECT = '{subject}'")
        x = cursor.fetchall()
        print(x)
        print(f"este del x {len(x)}")
        students = [str(w[0]) for w in x]
        student_ids = ','.join([str(w[0]) for w in x]) 
        enrolled = len(x)
        print(f"students {len(students)}")
        print(f"enrolled {enrolled}")
        print(f"student id {student_ids}")
        course =  set([str(w[1]).strip() for w in x])
        courses = ','.join(set([str(w[1]).strip() for w in x]))
        print(f"course to {courses}")
        year = set([str(w[2]).strip() for w in x])
        years = ','.join(set([str(w[2]).strip() for w in x]))
        print(f"years to {years}")
        room_schedule = ['C108','C110']
        room, preferred_day, next_day, time, next_timeslot, room_cat  = get_schedule_mix(students, enrolled, room_schedule)
        if room is None:
            print("not assign")
        else:
            print(room, preferred_day, time, room_cat)
            for i in students:
                print(f"aki ya ste tan update db : {i}")
                cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{time}'")
                cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', TIMESLOT = '{time}', ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                conn.commit()
            insert_assignment(cursor, conn, subject, section, room, preferred_day, next_day, time, next_timeslot, student_ids, courses, enrolled, years, room_cat)
            print('done')
    elif total_enrolled_count <=50:
        section = 'A'
        cursor.execute(f"SELECT ID, COURSE, YEAR FROM duplicate WHERE SUBJECT = '{subject}' LIMIT 20")
        x = cursor.fetchall()
        print(f"este del x {len(x)}")
        students = [str(w[0]) for w in x]
        student_ids = ','.join([str(w[0]) for w in x]) 
        enrolled = len(x)
        print(f"students {len(students)}")
        print(f"enrolled {enrolled}")
        print(f"student id {student_ids}")
        course =  set([str(w[1]).strip() for w in x])
        courses = ','.join(set([str(w[1]).strip() for w in x]))
        print(f"course to {courses}")
        year = set([str(w[2]).strip() for w in x])
        years = ','.join(set([str(w[2]).strip() for w in x]))
        print(f"years to {years}")
        room_schedule = ['C108','C110']
        room, preferred_day, next_day, time, next_timeslot, room_cat  = get_schedule_mix(students, enrolled, room_schedule)
        if room is None:
            print("not assign")
        else:
            print(room, preferred_day, time, room_cat)
            for i in students:
                print(f"aki ya ste tan update db : {i}")
                cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{time}'")
                cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', TIMESLOT = '{time}', ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                conn.commit()
            insert_assignment(cursor, conn, subject, section, room, preferred_day, next_day, time, next_timeslot, student_ids, courses, enrolled, years, room_cat)
            print('done')

        section = 'B'
        print("second ya")
        remainder = total_enrolled_count-20
        cursor.execute(f"SELECT ID, COURSE, YEAR FROM duplicate WHERE SUBJECT = '{subject}' LIMIT {remainder}")
        x = cursor.fetchall()
        print(len(x))
        students = [str(w[0]) for w in x]
        student_ids = ','.join([str(w[0]) for w in x]) 
        enrolled = len(x)
        print(f"student {len(students)}")
        print(enrolled)
        print(student_ids)
        course =  set([str(w[1]).strip() for w in x])
        courses = ','.join(set([str(w[1]).strip() for w in x]))
        year = set([str(w[2]).strip() for w in x])
        years = ','.join(set([str(w[2]).strip() for w in x]))
        print(f"course to {courses}")
        print(f"years to {years}")
        room_schedule = ['C108','C110']
        room, preferred_day, next_day, time, next_timeslot, room_cat  = get_schedule_mix(students, enrolled, room_schedule)
        if room is None:
            print("not assign")
        else:
            print(room, preferred_day, time, room_cat)
            for i in students:
                print(f"aki ya ste tan update db : {i}")
                cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{time}'")
                cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', TIMESLOT = '{time}', ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                conn.commit()
            insert_assignment(cursor, conn, subject, section, room, preferred_day, next_day, time, next_timeslot, student_ids, courses, enrolled, years, room_cat)
            print('done')    
    elif total_enrolled_count > 50:
        iterations = math.ceil(total_enrolled_count/35)
        print(iterations)
        for n in range(iterations):
            print(n)
            section = sections[n]
            print(section)
            cursor.execute(f"SELECT ID, COURSE, YEAR FROM duplicate WHERE SUBJECT = '{subject}' LIMIT 35")
            x = cursor.fetchall()
            print(x)
            print(f"este del x {len(x)}")
            students = [str(w[0]) for w in x]
            student_ids = ','.join([str(w[0]) for w in x]) 
            enrolled = len(x)
            print(f"student {len(students)}")
            print(f"enrolled {enrolled}")
            print(f"student id {student_ids}")
            course =  set([str(w[1]).strip() for w in x])
            courses = ','.join(set([str(w[1]).strip() for w in x]))
            year = set([str(w[2]).strip() for w in x])
            years = ','.join(set([str(w[2]).strip() for w in x]))
            print(f"course to {courses}")
            print(f"years to {years}")
            room_schedule = ['C108','C110']
            room, preferred_day, next_day, time, next_timeslot, room_cat  = get_schedule_mix(students, enrolled, room_schedule)
            print(room_cat, years)
            if room is None:
                print("not assign")
            else:
                print(room, preferred_day, time, room_cat)
                for i in students:
                    print(f"aki ya ste tan update db : {i}")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', TIMESLOT = '{time}', ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                    cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                    conn.commit()
                insert_assignment(cursor, conn, subject, section, room, preferred_day, next_day, time, next_timeslot, student_ids, courses, enrolled, years, room_cat)
                print('done')
#remainder
query = """
    SELECT
        SUBJECT,
        GROUP_CONCAT(ID ORDER BY SUBJECT, COURSE, YEAR) AS id_numbers,
        COUNT(ID) AS enrolled_count
    FROM
        main
    WHERE
        UNITS != 2 AND SUBJECT NOT LIKE '%LAB%'
    GROUP BY
        SUBJECT
    ORDER BY
        SUBJECT
"""

cursor.execute(query)
initial = cursor.fetchall()
counter = 0
sections = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z','AA','BB','CC','DD','EE','FF','GG','HH','II','JJ','KK','LL','MM','NN','OO','PP','QQ','RR']
num_sections = len(sections)
print(num_sections)
for row in initial:
    counter += 1
    subject = row[0]
    total_enrolled_count = row[2]
    print(subject, total_enrolled_count)
    if total_enrolled_count <= 35:
        section = 'A'
        cursor.execute(f"SELECT ID, COURSE, YEAR FROM duplicate WHERE SUBJECT = '{subject}'")
        x = cursor.fetchall()
        print(x)
        print(f"este del x {len(x)}")
        students = [str(w[0]) for w in x]
        student_ids = ','.join([str(w[0]) for w in x]) 
        enrolled = len(x)
        print(f"students {len(students)}")
        print(f"enrolled {enrolled}")
        print(f"student id {student_ids}")
        course =  set([str(w[1]).strip() for w in x])
        courses = ','.join(set([str(w[1]).strip() for w in x]))
        print(f"course to {courses}")
        year = set([str(w[2]).strip() for w in x])
        years = ','.join(set([str(w[2]).strip() for w in x]))
        print(f"years to {years}")
        room_schedule = get_room_available(enrolled)
        print(f"room_schedule to : {room_schedule}")
        all_bsn = all(c.strip() == 'BSN' for c in course)
        all_first = all(y.strip()== '1' for y in year)
        all_grad = all(y.strip()== '0' for y in year)
        if all_bsn or all_first:
            room, preferred_day, next_day, time, next_timeslot, room_cat = get_schedule_first(students, enrolled, room_schedule)
        elif all_grad:
            room, preferred_day, next_day, time, next_timeslot, room_cat = get_schedule_grad(students, enrolled, room_schedule)
        else:
            room, preferred_day, next_day, time, next_timeslot, room_cat = get_schedule_mix(students, enrolled, room_schedule)
        if room is None:
            checking_for_none (all_bsn,all_first,all_grad,enrolled, subject, section, students, student_ids, courses)
        else:
            print(room, preferred_day, next_day, time, next_timeslot, room_cat)
            for i in students:
                print(f"aki ya ste tan update db : {i}")
                cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{time}'")
                cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{next_day}' AND Timeslot = '{next_timeslot}'")
                cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{next_day}'AND Timeslot = '{next_timeslot}'")
                cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', NEXTDAY = '{next_day}', TIMESLOT = '{time}', NEXTTIMESLOT = '{next_timeslot}',ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                conn.commit()
            insert_assignment(cursor, conn, subject, section, room, preferred_day, next_day, time, next_timeslot, student_ids, courses, enrolled, years, room_cat)
            print('done')
    elif total_enrolled_count <=50:
        section = 'A'
        cursor.execute(f"SELECT ID, COURSE, YEAR FROM duplicate WHERE SUBJECT = '{subject}' LIMIT 10")
        x = cursor.fetchall()
        print(f"este del x {len(x)}")
        students = [str(w[0]) for w in x]
        student_ids = ','.join([str(w[0]) for w in x]) 
        enrolled = len(x)
        print(f"students {len(students)}")
        print(f"enrolled {enrolled}")
        print(f"student id {student_ids}")
        course =  set([str(w[1]).strip() for w in x])
        courses = ','.join(set([str(w[1]).strip() for w in x]))
        year = set([str(w[2]).strip() for w in x])
        years = ','.join(set([str(w[2]).strip() for w in x]))
        print(f"course to {courses}")
        print(f"years to {years}")
        room_schedule = get_room_available(enrolled)
        print(f"room_schedule to : {room_schedule}")
        all_bsn = all(c.strip() == 'BSN' for c in course)
        all_first = all(y.strip()== '1' for y in year)
        all_grad = all(y.strip()== '0' for y in year)
        if all_bsn or all_first:
            room, preferred_day, next_day, time, next_timeslot, room_cat = get_schedule_first(students, enrolled, room_schedule)
        elif all_grad:
            room, preferred_day, next_day, time, next_timeslot, room_cat = get_schedule_grad(students, enrolled, room_schedule)
        else:
            room, preferred_day, next_day, time, next_timeslot, room_cat = get_schedule_mix(students, enrolled, room_schedule)
        if room is None:
            checking_for_none (all_bsn,all_first,all_grad,enrolled, subject, section, students, student_ids, courses)
        else:
            print(room, preferred_day, next_day, time, next_timeslot, room_cat)
            for i in students:
                print(f"aki ya ste tan update db : {i}")
                cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{time}'")
                cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{next_day}' AND Timeslot = '{next_timeslot}'")
                cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{next_day}'AND Timeslot = '{next_timeslot}'")
                cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', NEXTDAY = '{next_day}', TIMESLOT = '{time}', NEXTTIMESLOT = '{next_timeslot}',ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                conn.commit()
            insert_assignment(cursor, conn, subject, section, room, preferred_day, next_day, time, next_timeslot, student_ids, courses, enrolled, years, room_cat)
            print('done')
        section = 'B'
        print("second ya")
        remainder = total_enrolled_count-10
        cursor.execute(f"SELECT ID, COURSE, YEAR FROM duplicate WHERE SUBJECT = '{subject}' LIMIT {remainder}")
        x = cursor.fetchall()
        print(len(x))
        students = [str(w[0]) for w in x]
        student_ids = ','.join([str(w[0]) for w in x]) 
        enrolled = len(x)
        print(f"student {len(students)}")
        print(enrolled)
        print(student_ids)
        course =  set([str(w[1]).strip() for w in x])
        courses = ','.join(set([str(w[1]).strip() for w in x]))
        year = set([str(w[2]).strip() for w in x])
        years = ','.join(set([str(w[2]).strip() for w in x]))
        print(f"course to {courses}")
        print(f"years to {years}")
        room_schedule = get_room_available(enrolled)
        print(f"room_schedule to : {room_schedule}")
        all_bsn = all(c.strip() == 'BSN' for c in course)
        all_first = all(y.strip()== '1' for y in year)
        all_grad = all(y.strip()== '0' for y in year)
        if all_bsn or all_first:
            room, preferred_day, next_day, time, next_timeslot, room_cat = get_schedule_first(students, enrolled, room_schedule)
        elif all_grad:
            room, preferred_day, next_day, time, next_timeslot, room_cat = get_schedule_grad(students, enrolled, room_schedule)
        else:
            room, preferred_day, next_day, time, next_timeslot, room_cat = get_schedule_mix(students, enrolled, room_schedule)
        if room is None:
            checking_for_none (all_bsn,all_first,all_grad,enrolled, subject, section, students, student_ids, courses)
        else:
            print(room, preferred_day, next_day, time, next_timeslot, room_cat)
            for i in students:
                print(f"aki ya ste tan update db : {i}")
                cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{time}'")
                cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{next_day}' AND Timeslot = '{next_timeslot}'")
                cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{next_day}'AND Timeslot = '{next_timeslot}'")
                cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', NEXTDAY = '{next_day}', TIMESLOT = '{time}', NEXTTIMESLOT = '{next_timeslot}',ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                conn.commit()
            insert_assignment(cursor, conn, subject, section, room, preferred_day, next_day, time, next_timeslot, student_ids, courses, enrolled, years, room_cat)
            print('done')     
    elif total_enrolled_count > 50:
        iterations = math.ceil(total_enrolled_count/35)
        print(f"iterations to:{iterations}")
        for n in range(iterations):
            print(n)
            section = sections[n]
            print(section)
            cursor.execute(f"SELECT ID, COURSE, YEAR FROM duplicate WHERE SUBJECT = '{subject}' LIMIT 35")
            x = cursor.fetchall()
            print(x)
            print(f"este del x {len(x)}")
            students = [str(w[0]) for w in x]
            student_ids = ','.join([str(w[0]) for w in x]) 
            enrolled = len(x)
            print(f"student {len(students)}")
            print(f"enrolled {enrolled}")
            print(f"student id {student_ids}")
            course =  set([str(w[1]).strip() for w in x])
            courses = ','.join(set([str(w[1]).strip() for w in x]))
            year = set([str(w[2]).strip() for w in x])
            years = ','.join(set([str(w[2]).strip() for w in x]))
            print(f"course to {courses}")
            print(f"years to {years}")
            room_schedule = get_room_available(enrolled)
            print(f"room_schedule to : {room_schedule}")
            all_bsn = all(c.strip() == 'BSN' for c in course)
            all_first = all(y.strip()== '1' for y in year)
            all_grad = all(y.strip()== '0' for y in year)
            if all_bsn or all_first:
                room, preferred_day, next_day, time, next_timeslot, room_cat = get_schedule_first(students, enrolled, room_schedule)
            elif all_grad:
                room, preferred_day, next_day, time, next_timeslot, room_cat = get_schedule_grad(students, enrolled, room_schedule)
            else:
                room, preferred_day, next_day, time, next_timeslot, room_cat = get_schedule_mix(students, enrolled, room_schedule)
            if room is None:
                checking_for_none(all_bsn,all_first,all_grad,enrolled, subject, section, students, student_ids, courses)
            else:
                print(room, preferred_day, next_day, time, next_timeslot, room_cat)
                for i in students:
                    print(f"aki ya ste tan update db : {i}")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{preferred_day}' AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM student_schedule WHERE ID_Numbers = {i} AND Day = '{next_day}' AND Timeslot = '{next_timeslot}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{preferred_day}'AND Timeslot = '{time}'")
                    cursor.execute(f"DELETE FROM room_schedule WHERE Room_Name = '{room}' AND Day = '{next_day}'AND Timeslot = '{next_timeslot}'")
                    cursor.execute(f"UPDATE main SET SECTION = '{section}', DAY = '{preferred_day}', NEXTDAY = '{next_day}', TIMESLOT = '{time}', NEXTTIMESLOT = '{next_timeslot}',ROOM = '{room}' WHERE ID = {i} AND SUBJECT LIKE '%{subject}%'")
                    cursor.execute(f"DELETE FROM duplicate WHERE ID = {i}  AND SUBJECT = '{subject}'")
                    conn.commit()
                insert_assignment(cursor, conn, subject, section, room, preferred_day, next_day, time, next_timeslot, student_ids, courses, enrolled, years, room_cat)
                print('done')        
cursor.close()
conn.close()
