#pwede to i as one function
import mysql.connector
from assignment_functions import *

conn = mysql.connector.connect(
    user='root',
    password='',
    database='adzu',
    host='localhost'
)
cursor = conn.cursor()
cursor.execute("DELETE FROM initial WHERE program = 'BSN'") #DELETE BSN MUNA
cursor.execute("DROP TABLE initial_backup")
cursor.execute("CREATE TABLE IF NOT EXISTS initial_backup AS SELECT * FROM initial")
cursor.execute("DELETE FROM assignment")
conn.commit()

program_year_section_assigned = {}
room_day_timeslots = {}   
programs_room = {
               'BSBIO': 'BIOLAB',
               'BSPSY':'PSYCHOLOGYLAB',
               'BACOMM':'MASSCOMLAB', 
               'BSECE':'ECELAB',
               'BSCE':'CELAB',
               'BSBME':'ECELAB', 
               'AEET':'ENGLAB', 
               }

#NSTP
cursor.execute("SELECT DISTINCT course_code, course_section, size FROM initial WHERE course_code LIKE '%NSTP%'")   
k = cursor.fetchall()
for l in k:
    print(l)
    assigned = False
    course_code = l[0]
    course_section = l[1]
    size = l[2]
    timeslots, days = get_timeslots_days(type = 'NSTP')
    room = 'KIOSK'
    for day in days:
        if assigned:
            break
        for timeslot in timeslots:
            check1, check2 = lec2_checktimes(timeslot)
            nextday = day
            if assigned:
                break
            student_available = student_avail_remove(cursor, course_code, course_section, day, nextday, check1, check2, program_year_section_assigned, conn)
            if student_available:
                for_printing_assignment(cursor, conn, day, course_code, course_section, nextday, timeslot, room)
                assigned = True
                break
            else:
                continue

#PE
cursor.execute("SELECT DISTINCT course_code, course_section FROM initial WHERE type = 'PE'")   
k = cursor.fetchall()
for l in k:
    print(l)
    print(room_day_timeslots)
    assigned = False
    course_code = l[0]
    course_section = l[1]
    timeslots, days = get_timeslots_days(type = 'PE')
    room_list = get_room(cursor, size = 'L' ,type = 'PE', dep_assigned = 'NONE')
    print(room_list)
    for room in room_list:
        if assigned:
            break
        for day in days:
            nextday = day
            if assigned:
                break
            for timeslot in timeslots:
                print(room, day, timeslot)
                check1, check2 = pe_checktimes(timeslot)
                room_combi_avail = check_dict(room_day_timeslots, room, day, nextday, check1 = timeslot, check2 = timeslot) #PANGCHECK ROOM DAY TIME COMBI SA DICT
                if assigned:
                    break
                elif room_combi_avail:
                    student_available = student_avail_remove(cursor, course_code, course_section, day, nextday, check1, check2, program_year_section_assigned, conn) #PANGCHECK SA STUDENT
                    if student_available:
                        removal_db("room_schedule", "room", room, cursor, conn, day, nextday, check1 = timeslot, check2 = timeslot) #PARA ITANGGAL ANG MGA NAASSIGN
                        appending(room_day_timeslots, room, day, nextday, check1 = timeslot, check2 = timeslot) #APPEND SA DICT FOR CHECKING PURPOSES
                        for_printing_assignment(cursor, conn, day, course_code, course_section, nextday, timeslot, room) #OUTPUT SA FINAL TABLE NA ASSIGNMENT
                        assigned = True
                        break
                    else:
                        continue    
                else:
                    continue 
  
                          
#gen subs
gen_subs = ['MOD','PHIHIS','UNDSELF','SPIECO','ARTAPP','CONWOR','ETHICS','ELECTLM','ELECTGB','PURCOM','SCITECS','VOCMIS','RIZAL','FFP'] #CHECKLIST SA UI
for x in gen_subs:
    cursor.execute(f"SELECT DISTINCT course_code, course_section, size, department FROM initial WHERE course_code LIKE '%{x}%'") 
    print("here na") 
    k = cursor.fetchall()
    for l in k:
        print(l)
        assigned = False
        course_code = l[0]
        course_section = l[1]
        department = l[3]
        size = l[2]
        timeslots, days = get_timeslots_days(type = 'LEC')
        room_list = get_room(cursor, size ,type = 'LEC', dep_assigned = 'NONE')
        if not room_list:
            if size == 'S':
                room_list = get_room(cursor, size = 'M' ,type = 'LEC', dep_assigned = 'NONE')
            else:
                room_list = get_room(cursor, size = 'L' ,type = 'LEC', dep_assigned = 'NONE')
        print(room_list)
        for room in room_list:
            if assigned:
                break
            for day in days:
                if assigned:
                    break
                for timeslot in timeslots:
                    if assigned:
                        break
                    check1 = timeslot
                    check2 = timeslot
                    nextday = get_nextday(day)
                    room_combi_avail = check_dict(room_day_timeslots, room, day, nextday, check1, check2)
                    print(room_combi_avail)
                    if room_combi_avail:#here na
                        student_available = student_avail_remove(cursor, course_code, course_section, day, nextday, check1, check2, program_year_section_assigned, conn)
                        if student_available:
                            removal_db("room_schedule", "room", room, cursor, conn, day, nextday, check1, check2)
                            appending(room_day_timeslots, room, day, nextday, check1, check2)
                            for_printing_assignment(cursor, conn, day, course_code, course_section, nextday, timeslot, room)
                            assigned = True
                            break
                        else:
                            continue
                    else:
                        continue
                    
cursor.execute(f"SELECT DISTINCT course_code, course_section, size, department FROM initial WHERE course_code LIKE '%OA%'")
print("here na") 
k = cursor.fetchall()
for l in k:
    print(l)
    assigned = False
    course_code = l[0]
    course_section = l[1]
    department = l[3]
    size = l[2]
    timeslots, days = get_timeslots_days(type = 'LEC')
    room_list = ['BC305']
    for room in room_list:
        if assigned:
            break
        for day in days:
            if assigned:
                break
            for timeslot in timeslots:
                if assigned:
                    break
                check1 = timeslot
                check2 = timeslot
                nextday = get_nextday(day)
                room_combi_avail = check_dict(room_day_timeslots, room, day, nextday, check1, check2)
                print(room_combi_avail)
                if room_combi_avail:#here na
                    student_available = student_avail_remove(cursor, course_code, course_section, day, nextday, check1, check2, program_year_section_assigned, conn)
                    if student_available:
                        removal_db("room_schedule", "room", room, cursor, conn, day, nextday, check1, check2)
                        appending(room_day_timeslots, room, day, nextday, check1, check2)
                        for_printing_assignment(cursor, conn, day, course_code, course_section, nextday, timeslot, room)
                        assigned = True
                        break
                    else:
                        continue
                else:
                    continue                   
                                    

add_in_query = """
    course_desc NOT LIKE '%programming%' 
    AND course_desc NOT LIKE '%computer%' 
    AND course_desc NOT LIKE '%computing%' 
    AND course_desc NOT LIKE '%Statistics%'
"""

cursor.execute(f"SELECT DISTINCT course_code, course_section, size, department FROM initial WHERE size != 'L' AND {add_in_query}")
print("here na") 
k = cursor.fetchall()
for l in k:
    print(l)
    assigned = False
    course_code = l[0]
    course_section = l[1]
    department = l[3]
    size = l[2]
    timeslots, days = get_timeslots_days(type = 'LEC')
    room_list = room_query(cursor, 'LEC', department, size)
    if not room_list:
        room_list = room_query(cursor, 'LEC', 'IGNORE', size)
    print(room_list)
    for room in room_list:
        if assigned:
            break
        for day in days:
            if assigned:
                break
            for timeslot in timeslots:
                if assigned:
                    break
                check1 = timeslot
                check2 = timeslot
                nextday = get_nextday(day)
                room_combi_avail = check_dict(room_day_timeslots, room, day, nextday, check1, check2)
                print(room_combi_avail)
                if room_combi_avail:#here na
                    student_available = student_avail_remove(cursor, course_code, course_section, day, nextday, check1, check2, program_year_section_assigned, conn)
                    if student_available:
                        removal_db("room_schedule", "room", room, cursor, conn, day, nextday, check1, check2)
                        appending(room_day_timeslots, room, day, nextday, check1, check2)
                        for_printing_assignment(cursor, conn, day, course_code, course_section, nextday, timeslot, room)
                        assigned = True
                        break
                    else:
                        continue
                else:
                    continue







#csite programs
for x in programs_room:
    cursor.execute(f"""
    SELECT DISTINCT course_code, course_section, size, department, type 
    FROM initial 
    WHERE program = '{x}' 
    AND type != 'OJT' 
    AND {add_in_query}
    ORDER BY 
        CASE 
            WHEN type LIKE '%LAB%' THEN 1 
            WHEN type LIKE '%LEC%' THEN 2 
            ELSE 3 
        END
    """)
    print("here na")
    k = cursor.fetchall()
    for l in k:
        print(l)
        assigned = False
        course_code = l[0]
        course_section = l[1]
        department = l[3]
        size = l[2]
        type1 = l[4]
        print(department)
        rtype = programs_room.get(x)
        timeslots, days = get_timeslots_days(type1)
        room_list = room_query(cursor, rtype, 'IGNORE', size)
        if not room_list:
            room_list = room_query(cursor, rtype, 'IGNORE', 'IGNORE')
        for day in days:
            if assigned:
                break
            for room in room_list:
                if assigned:
                    break
                for timeslot in timeslots:
                    check1, check2, nextday = get_timesdays(type1, timeslot, day)
                    if assigned:
                        break
                    print(nextday)
                    room_combi_avail = check_dict(room_day_timeslots, room, day, nextday, check1, check2)
                    print(room_combi_avail)
                    if room_combi_avail:
                        student_available = student_avail_remove(cursor, course_code, course_section, day, nextday, check1, check2, program_year_section_assigned, conn)
                        if student_available:
                            removal_db("room_schedule", "room", room, cursor, conn, day, nextday, check1, check2)
                            appending(room_day_timeslots, room, day, nextday, check1, check2)
                            for_printing_assignment(cursor, conn, day, course_code, course_section, nextday, timeslot, room)
                            assigned = True
                            break
                        else:
                            continue
                    else:
                        continue
        if not assigned:
            a = ws_consecutive(conn, cursor, course_code, course_section, room_list, program_year_section_assigned, room_day_timeslots)
            if a:
                assigned = True
            else:
                print("notmuch room") #add late here if ever pwede pa gamitin ang labs as lecs
                

#lecs
cursor.execute(f"SELECT DISTINCT course_code, course_section, size, department FROM initial WHERE type != 'OJT' AND {add_in_query}") 
print("here na")  
k = cursor.fetchall()
for l in k:
    print(l)
    assigned = False
    course_code = l[0]
    course_section = l[1]
    department = l[3]
    size = l[2]
    timeslots, days = get_timeslots_days('LEC')
    type1 = 'LEC'
    room_list = room_query(cursor, 'IGNORE', department, size)
    if not room_list:
        room_list = room_query(cursor, 'LEC', department, size)
        if not room_list:
            room_list = room_query(cursor, 'IGNORE', department, 'L')
            
    for room in room_list:
        if assigned:
            break
        for day in days:
            if assigned:
                break
            for timeslot in timeslots:
                check1, check2, nextday = get_timesdays(type1, timeslot, day)
                if assigned:
                    break
                print(nextday)
                room_combi_avail = check_dict(room_day_timeslots, room, day, nextday, check1, check2)
                print(room_combi_avail)
                if room_combi_avail:
                    student_available = student_avail_remove(cursor, course_code, course_section, day, nextday, check1, check2, program_year_section_assigned, conn)
                    if student_available:
                        removal_db("room_schedule", "room", room, cursor, conn, day, nextday, check1, check2)
                        appending(room_day_timeslots, room, day, nextday, check1, check2)
                        for_printing_assignment(cursor, conn, day, course_code, course_section, nextday, timeslot, room)
                        assigned = True
                        break
                    else:
                        continue
                else:
                    continue
    if not assigned:
        a = ws_consecutive(conn, cursor, course_code, course_section, room_list, program_year_section_assigned, room_day_timeslots)
        if a:
            assigned = True
        else:
            room_list = room_query(cursor, 'LEC', 'NONE', size)
            for room in room_list:
                if assigned:
                    break
                for day in days:
                    if assigned:
                        break
                    for timeslot in timeslots:
                        check1, check2, nextday = get_timesdays(type1, timeslot, day)
                        if assigned:
                            break
                        print(nextday)
                        room_combi_avail = check_dict(room_day_timeslots, room, day, nextday, check1, check2)
                        print(room_combi_avail)
                        if room_combi_avail:
                            student_available = student_avail_remove(cursor, course_code, course_section, day, nextday, check1, check2, program_year_section_assigned, conn)
                            if student_available:
                                removal_db("room_schedule", "room", room, cursor, conn, day, nextday, check1, check2)
                                appending(room_day_timeslots, room, day, nextday, check1, check2)
                                for_printing_assignment(cursor, conn, day, course_code, course_section, nextday, timeslot, room)
                                assigned = True
                                break
                            else:
                                continue
                        else:
                            continue
            if not assigned:
                a = ws_consecutive(conn, cursor, course_code, course_section, room_list, program_year_section_assigned, room_day_timeslots)
                if a:
                    assigned = True
                else:
                    b = late(conn, cursor, course_code, days, course_section, room_list, program_year_section_assigned, room_day_timeslots)
                    if b:
                        assigned = True
                    room_list = room_query(cursor, 'LEC', 'NONE', 'L')
                    for room in room_list:
                        if assigned:
                            break
                        for day in days:
                            if assigned:
                                break
                            for timeslot in timeslots:
                                check1, check2, nextday = get_timesdays(type1, timeslot, day)
                                if assigned:
                                    break
                                print(nextday)
                                room_combi_avail = check_dict(room_day_timeslots, room, day, nextday, check1, check2)
                                print(room_combi_avail)
                                if room_combi_avail:
                                    student_available = student_avail_remove(cursor, course_code, course_section, day, nextday, check1, check2, program_year_section_assigned, conn)
                                    if student_available:
                                        removal_db("room_schedule", "room", room, cursor, conn, day, nextday, check1, check2)
                                        appending(room_day_timeslots, room, day, nextday, check1, check2)
                                        for_printing_assignment(cursor, conn, day, course_code, course_section, nextday, timeslot, room)
                                        assigned = True
                                        break
                                    else:
                                        continue
                                else:
                                    continue
                    if not assigned:
                        a = ws_consecutive(conn, cursor, course_code, course_section, room_list, program_year_section_assigned, room_day_timeslots)
                        if a:
                            assigned = True
                        else:
                            b = late(conn, cursor, course_code, days, course_section, room_list, program_year_section_assigned, room_day_timeslots)
                            if b:
                                assigned = True
                            print("notmuch room")
        
                    