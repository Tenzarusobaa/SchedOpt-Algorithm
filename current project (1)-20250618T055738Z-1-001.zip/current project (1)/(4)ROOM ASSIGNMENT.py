#COURSE COMBINATION

            
            
#COURSE LABELING


cursor.execute("SELECT id, course_code FROM initial ORDER BY course_code, id")
j = cursor.fetchall()
current_course_code = None
section_counter = -1
for i in j:
    id = i[0]
    print(id)
    course_code = i[1]
    if course_code != current_course_code: #if magiba magreset
        current_course_code = course_code
        section_counter = 0
    else:
        section_counter += 1
    
    section = get_section_letter(section_counter)
    print(section)
    cursor.execute(f"UPDATE initial SET course_section = '{section}' WHERE id = {id}")
    conn.commit()

print("Course sections updated.")



cursor.execute(f"UPDATE initial SET program = '{program}', section = 'NONE', year = 0, size = 'L' WHERE id = {id}")
                cursor.execute(f"DELETE FROM initial WHERE id = {id_to_delete}")
                conn.commit() 