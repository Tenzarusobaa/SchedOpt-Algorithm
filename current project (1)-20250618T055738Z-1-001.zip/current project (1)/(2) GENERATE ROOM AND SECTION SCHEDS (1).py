import mysql.connector

conn = mysql.connector.connect(
    user='root',
    password='',
    database='adzu',
    host='localhost'
)
cursor = conn.cursor()

cursor.execute("DELETE FROM room_schedule")
cursor.execute("DELETE FROM student_schedule")
cursor.execute("DROP TABLE room_sched_remaining")      
cursor.execute("DROP TABLE section_sched_remaining") 

conn.commit()

#sa room
cursor.execute("SELECT room, size, type FROM rooms_data")
room_data = cursor.fetchall()
days = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday']
timeslots = ['8:00-9:20','9:30-10:50','11:00-12:20','12:30-1:50','2:00-3:20','3:30-4:30','4:30-5:50','6:00-7:20'] #dapat i get to pag may ui na
for x in room_data:
    room = x[0]
    size = x[1]
    type = x[2]
    for day in days:
        if type != 'PE':
            for timeslot in timeslots:
                cursor.execute(f"INSERT INTO room_schedule (room, size, type, day, timeslot) VALUES ('{room}','{size}','{type}','{day}','{timeslot}')")
                conn.commit()
        else:
            timeslot1 = ['8:00-10:00','10:00-12:00','1:00-3:00','3:00-5:00']
            for timeslot in timeslot1:
                cursor.execute(f"INSERT INTO room_schedule (room, size, type, day, timeslot) VALUES ('{room}','{size}','{type}','{day}','{timeslot}')")
                conn.commit()
#sa sections
cursor.execute("SELECT program, year, section FROM student_sections")
section_data = cursor.fetchall()
for y in section_data:
    program = y[0]
    year = y[1]
    section = y[2]
    program_year_section = f"{program}-{year}-{section}"
    for day in days:
        if day != 'Saturday':
            for timeslot in timeslots:
                cursor.execute(f"INSERT INTO student_schedule (program_year_section, day, timeslot) VALUES ('{program_year_section}','{day}','{timeslot}')")
                conn.commit() 
        else:
            timeslots1 = ['8:00-9:20','9:30-10:50','11:00-12:20','12:30-1:50','2:00-3:20']
            for timeslot in timeslots1:
                cursor.execute(f"INSERT INTO student_schedule (program_year_section, day, timeslot) VALUES ('{program_year_section}','{day}','{timeslot}')")
                conn.commit() 
 
#in preparation sa assignment           
cursor.execute("CREATE TABLE room_sched_remaining AS SELECT * FROM room_schedule")      
cursor.execute("CREATE TABLE section_sched_remaining AS SELECT * FROM student_schedule") 
conn.commit()

conn.close()
