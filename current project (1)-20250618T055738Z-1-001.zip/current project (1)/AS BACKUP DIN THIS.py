#pwede to i as one function
import mysql.connector
from assignment_functions import *

conn = mysql.connector.connect(
    user='root',
    password='',
    database='adzu',
    host='localhost'
)
cursor = conn.cursor()
cursor.execute("DELETE FROM initial WHERE program = 'BSN'") #DELETE BSN MUNA
cursor.execute("DROP TABLE initial_backup")
cursor.execute("CREATE TABLE IF NOT EXISTS initial_backup AS SELECT * FROM initial")
cursor.execute("DELETE FROM assignment")
conn.commit()

program_year_section_assigned = {}
room_day_timeslots = {}   
programs_room = {'BSMATH':'STATLAB',
               'BSBIO': 'BIOLAB',
               'BSCS': 'COMLAB',
               'BSIT':'COMLAB',
               'BSCPE':'COMLAB',
               'BSPSY':'PSYCHOLOGYLAB',
               'BACOMM':'MASSCOMLAB',
               'BSECE':'ECELAB',
               'BSCE':'CELAB',
               'BSBME':'CELAB',
               'AEET':'ENGLAB',
               'BSNMCA':'COMLAB'
               }

#PE
cursor.execute("SELECT DISTINCT course_code, course_section FROM initial WHERE type = 'PE'")   
k = cursor.fetchall()
for l in k:
    print(l)
    print(room_day_timeslots)
    assigned = False
    course_code = l[0]
    course_section = l[1]
    timeslots, days = get_timeslots_days(type = 'PE')
    room_list = get_room(cursor, size = 'L' ,type = 'PE', dep_assigned = 'NONE')
    print(room_list)
    for room in room_list:
        if assigned:
            break
        for day in days:
            nextday = day
            if assigned:
                break
            for timeslot in timeslots:
                print(room, day, timeslot)
                check1, check2 = pe_checktimes(timeslot)
                room_combi_avail = check_dict(room_day_timeslots, room, day, nextday, check1 = timeslot, check2 = timeslot)
                if assigned:
                    break
                elif room_combi_avail:
                    student_available = student_avail_remove(cursor, course_code, course_section, day, nextday, check1, check2, program_year_section_assigned, conn)
                    if student_available:
                        removal_db("room_schedule", "room", room, cursor, conn, day, nextday, check1 = timeslot, check2 = timeslot) #kasi dapat separate timeslots ng mpcc para sa overlap di matanggal entirely
                        appending(room_day_timeslots, room, day, nextday, check1 = timeslot, check2 = timeslot)
                        for_printing_assignment(cursor, conn, day, course_code, course_section, nextday, timeslot, room)
                        assigned = True
                        break
                    else:
                        continue    
                else:
                    continue 


#NSTP
cursor.execute("SELECT DISTINCT course_code, course_section, size FROM initial WHERE course_code LIKE '%NSTP%'")   
k = cursor.fetchall()
for l in k:
    print(l)
    assigned = False
    course_code = l[0]
    course_section = l[1]
    size = l[2]
    timeslots, days = get_timeslots_days(type = 'NSTP')
    room_list = get_room(cursor, size ,type = 'LEC', dep_assigned = 'NONE')
    print(room_list)
    for day in days:
        if assigned:
            break
        for room in room_list:
            if assigned:
                break
            for timeslot in timeslots:
                check1, check2 = lec2_checktimes(timeslot)
                nextday = day
                room_combi_avail = check_dict(room_day_timeslots, room, day, nextday, check1, check2)
                if assigned:
                    break
                elif room_combi_avail:
                    student_available = student_avail_remove(cursor, course_code, course_section, day, nextday, check1, check2, program_year_section_assigned, conn)
                    if student_available:
                        removal_db("room_schedule", "room", room, cursor, conn, day, nextday, check1, check2)
                        appending(room_day_timeslots, room, day, nextday, check1, check2)
                        for_printing_assignment(cursor, conn, day, course_code, course_section, nextday, timeslot, room)
                        assigned = True
                        break
                    else:
                        continue
                else:
                    continue
                       
#gen subs
gen_subs = ['MOD','PHIHIS','UNDSELF','SPIECO','ARTAPP','CONWOR','ETHICS','ELECTLM','ELECTGB','PURCOM','SCITECS','VOCMIS','RIZAL','FFP']
for x in gen_subs:
    cursor.execute(f"SELECT DISTINCT course_code, course_section, size, department FROM initial WHERE course_code LIKE '%{x}%'") 
    print("here na") 
    k = cursor.fetchall()
    for l in k:
        print(l)
        assigned = False
        course_code = l[0]
        course_section = l[1]
        department = l[3]
        size = l[2]
        timeslots, days = get_timeslots_days(type = 'LEC')
        room_list = get_room(cursor, size ,type = 'LEC', dep_assigned = 'NONE')
        if not room_list:
            room_list = get_room(cursor, size = 'L' ,type = 'LEC', dep_assigned = 'NONE')
        print(room_list)
        for room in room_list:
            if assigned:
                break
            for day in days:
                if assigned:
                    break
                for timeslot in timeslots:
                    if assigned:
                        break
                    check1 = timeslot
                    check2 = timeslot
                    nextday = get_nextday(day)
                    room_combi_avail = check_dict(room_day_timeslots, room, day, nextday, check1, check2)
                    print(room_combi_avail)
                    if room_combi_avail:#here na
                        student_available = student_avail_remove(cursor, course_code, course_section, day, nextday, check1, check2, program_year_section_assigned, conn)
                        if student_available:
                            removal_db("room_schedule", "room", room, cursor, conn, day, nextday, check1, check2)
                            appending(room_day_timeslots, room, day, nextday, check1, check2)
                            for_printing_assignment(cursor, conn, day, course_code, course_section, nextday, timeslot, room)
                            assigned = True
                            break
                        else:
                            continue
                    else:
                        continue


#csite programs
for x in programs_room:
    cursor.execute(f"""
    SELECT DISTINCT course_code, course_section, size, department, type 
    FROM initial 
    WHERE program = '{x}' 
    AND type != 'OJT'
    ORDER BY 
        CASE 
            WHEN type LIKE '%LAB%' THEN 1 
            WHEN type LIKE '%LEC%' THEN 2 
            ELSE 3 
        END
    """)
    print("here na")
    k = cursor.fetchall()
    for l in k:
        print(l)
        assigned = False
        course_code = l[0]
        course_section = l[1]
        department = l[3]
        size = l[2]
        type1 = l[4]
        print(department)
        rtype = programs_room.get(x)
        timeslots, days = get_timeslots_days(type1)
        room_list = room_query(cursor, rtype, 'IGNORE', size)
        if not room_list:
            room_list = room_query(cursor, rtype, 'IGNORE', 'IGNORE')
        for day in days:
            if assigned:
                break
            for room in room_list:
                if assigned:
                    break
                for timeslot in timeslots:
                    check1, check2, nextday = get_timesdays(type1, timeslot, day)
                    if assigned:
                        break
                    print(nextday)
                    room_combi_avail = check_dict(room_day_timeslots, room, day, nextday, check1, check2)
                    print(room_combi_avail)
                    if room_combi_avail:
                        student_available = student_avail_remove(cursor, course_code, course_section, day, nextday, check1, check2, program_year_section_assigned, conn)
                        if student_available:
                            removal_db("room_schedule", "room", room, cursor, conn, day, nextday, check1, check2)
                            appending(room_day_timeslots, room, day, nextday, check1, check2)
                            for_printing_assignment(cursor, conn, day, course_code, course_section, nextday, timeslot, room)
                            assigned = True
                            break
                        else:
                            continue
                    else:
                        continue
        if not assigned:
            a = ws_consecutive(conn, cursor, course_code, course_section, room_list, program_year_section_assigned, room_day_timeslots)
            if a:
                assigned = True
            else:
                b = late(conn, cursor, course_code, days, course_section, room_list, program_year_section_assigned, room_day_timeslots)
                if b:
                    assigned = True
                print("notmuch room") #add late here if ever pwede pa gamitin ang labs as lecs
                

#lecs
cursor.execute("SELECT DISTINCT course_code, course_section, size, department FROM initial WHERE type != 'OJT'") 
print("here na")  
k = cursor.fetchall()
for l in k:
    print(l)
    assigned = False
    course_code = l[0]
    course_section = l[1]
    department = l[3]
    size = l[2]
    timeslots, days = get_timeslots_days('LEC')
    room_list = room_query(cursor, 'IGNORE', department, size)
    if not room_list:
        room_list = room_query(cursor, 'LEC', department, size)
        if not room_list:
            room_list = room_query(cursor, 'IGNORE', department, 'L')
            
    for room in room_list:
        if assigned:
            break
        for day in days:
            if assigned:
                break
            for timeslot in timeslots:
                check1, check2, nextday = get_timesdays(type1, timeslot, day)
                if assigned:
                    break
                print(nextday)
                room_combi_avail = check_dict(room_day_timeslots, room, day, nextday, check1, check2)
                print(room_combi_avail)
                if room_combi_avail:
                    student_available = student_avail_remove(cursor, course_code, course_section, day, nextday, check1, check2, program_year_section_assigned, conn)
                    if student_available:
                        removal_db("room_schedule", "room", room, cursor, conn, day, nextday, check1, check2)
                        appending(room_day_timeslots, room, day, nextday, check1, check2)
                        for_printing_assignment(cursor, conn, day, course_code, course_section, nextday, timeslot, room)
                        assigned = True
                        break
                    else:
                        continue
                else:
                    continue
    if not assigned:
        a = ws_consecutive(conn, cursor, course_code, course_section, room_list, program_year_section_assigned, room_day_timeslots)
        if a:
            assigned = True
        else:
            room_list = room_query(cursor, 'LEC', 'NONE', size)
            for room in room_list:
                if assigned:
                    break
                for day in days:
                    if assigned:
                        break
                    for timeslot in timeslots:
                        check1, check2, nextday = get_timesdays(type1, timeslot, day)
                        if assigned:
                            break
                        print(nextday)
                        room_combi_avail = check_dict(room_day_timeslots, room, day, nextday, check1, check2)
                        print(room_combi_avail)
                        if room_combi_avail:
                            student_available = student_avail_remove(cursor, course_code, course_section, day, nextday, check1, check2, program_year_section_assigned, conn)
                            if student_available:
                                removal_db("room_schedule", "room", room, cursor, conn, day, nextday, check1, check2)
                                appending(room_day_timeslots, room, day, nextday, check1, check2)
                                for_printing_assignment(cursor, conn, day, course_code, course_section, nextday, timeslot, room)
                                assigned = True
                                break
                            else:
                                continue
                        else:
                            continue
            if not assigned:
                a = ws_consecutive(conn, cursor, course_code, course_section, room_list, program_year_section_assigned, room_day_timeslots)
                if a:
                    assigned = True
                else:
                    room_list = room_query(cursor, 'LEC', 'NONE', size)
                    for room in room_list:
                        if assigned:
                            break
                        for day in days:
                            if assigned:
                                break
                            for timeslot in timeslots:
                                check1, check2, nextday = get_timesdays(type1, timeslot, day)
                                if assigned:
                                    break
                                print(nextday)
                                room_combi_avail = check_dict(room_day_timeslots, room, day, nextday, check1, check2)
                                print(room_combi_avail)
                                if room_combi_avail:
                                    student_available = student_avail_remove(cursor, course_code, course_section, day, nextday, check1, check2, program_year_section_assigned, conn)
                                    if student_available:
                                        removal_db("room_schedule", "room", room, cursor, conn, day, nextday, check1, check2)
                                        appending(room_day_timeslots, room, day, nextday, check1, check2)
                                        for_printing_assignment(cursor, conn, day, course_code, course_section, nextday, timeslot, room)
                                        assigned = True
                                        break
                                    else:
                                        continue
                                else:
                                    continue
                    if not assigned:
                        a = ws_consecutive(conn, cursor, course_code, course_section, room_list, program_year_section_assigned, room_day_timeslots)
                        if a:
                            assigned = True
                        else:
                            b = late(conn, cursor, course_code, days, course_section, room_list, program_year_section_assigned, room_day_timeslots)
                            if b:
                                assigned = True
                            print("notmuch room")
        
                    