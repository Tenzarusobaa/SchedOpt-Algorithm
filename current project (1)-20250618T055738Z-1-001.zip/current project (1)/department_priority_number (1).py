import mysql.connector

conn = mysql.connector.connect(
    user='root',
    password='',
    database='adzu',
    host='localhost'
)
cursor = conn.cursor()
cursor.execute("DELETE FROM department_data")
conn.commit()
cursor.execute("SELECT DISTINCT program FROM student_sections")
programs = cursor.fetchall()
for p in programs:
    program = p[0].replace(" ", "").upper()
    print({program})
    if program in ['BSED','BEED','BPED']:
        department = 'SED'
        pn = 4
    elif program == 'BSN':
        department = 'CON'
        pn = 1
    elif program in ['BACOMM','BAELS','BAINDIS','BAINTS','BAPHILO','BSPSY']:
        department = 'SLA'
        pn = 2
    elif program in ['BSAC','BSBA','BSLM','BSMA','BSOA']:
        department = 'SMA'
        pn = 3
    else:
        department = 'CSITE'
        pn = 5
    cursor.execute(f"INSERT INTO department_data(program, department, priority_number) VALUES ('{program}','{department}',{pn})")
    conn.commit()
    
conn.close()
    
