#pwede to ias one function def course_processing para icall lang and import later
import mysql.connector

conn = mysql.connector.connect(
    user='root',
    password='',
    database='adzu',
    host='localhost'
)
cursor = conn.cursor()

sem = 2 #dapat mainput this
cursor.execute("DELETE FROM initial")
conn.commit()
#program dictionary
programs={'AEET':'aeet',
          'BACOMM':'ba_comm',
          'BAELS':'ba_els',
          'BAINDIS':'ba_indis',
          'BAINTS':'ba_ints',
          'BAPHILO':'ba_philo',
          'BECED':'beced',
          'BEED':'beed',
          'BPED':'bped',
          'BSAC':'bsac_abm', #palitan pa to kasi wala major major muna
          'BSACNON':'bsac_nonabm',
          'BSBA':'bsba_entrep',#palitan to
          'BSBAFM':'bsba_fm',
          'BSBAMM':'bsba_mm',
          'BSBIO':'bsbio', #medicalbio to palitan rin
          'BSBIOBR':'bsbio_br',
          'BSBIOEB':'bsbio_eb',
          'BSBME':'bsbme',
          'BSCE':'bsce_cm',#palitan din to
          'BSCEGEO':'bsce_geo',
          'BSCES':'bsce_s',
          'BSCPE':'bscpe',
          'BSCS':'bscs',
          'BSECE':'bsece',
          'BSED':'bsed_english',#palitan din to
          'BSEDFIL':'bsed_filipino',
          'BSEDMATH':'bsed_math',
          'BSEDSCI':'bsed_science',
          'BSED_SOCS':'bsed_socstud',
          'BSEDVAL':'bsed_values',
          'BSIT':'bsit',
          'BSLM':'bslm',
          'BSMATH':'bsmath',
          'BSMA':'bsma_abm', #palitan too
          'BSMANON':'bsma_nonabm',
          'BSN':'bsn',
          'BSNMCA':'bsnmca',
          'BSOA':'bsoa',    
          'BSPSY':'bspsyc'
    
}

#COURSE DISTRIBUTION
cursor.execute("SELECT program, year, section, size FROM student_sections ORDER BY priority_number")
p = cursor.fetchall()
for x in p:
    program = x[0]
    year = x[1]
    section = x[2]
    size = x[3]
    cursor.execute(f"SELECT * FROM department_data WHERE program = '{program}'")
    d = cursor.fetchall()
    for a in d:
        department = a[1]
        priority_number = a[2]
    table_name = programs.get(program)
    if table_name:
        print(f"yes,{program}")
        cursor.execute(f"SELECT * FROM {table_name} WHERE sem = {sem} AND year = {year}")
        q = cursor.fetchall()
        for y in q:
            course_code = y[2]
            course_desc = y[3]
            units = y[4]
            type = y[5]
            print({program},{year},{department},{course_code})
            cursor.execute(f"INSERT INTO initial (course_code, course_section, program, section, year, department, size, type, course_desc) VALUES ('{course_code}','NONE','{program}','{section}',{year},'{department}','{size}','{type}','{course_desc}') ") #pone id per entry
            conn.commit()#BSN CHENE PA HYPEN EDIT IT
    else:
        print(f"NO CURRICULUM FOR {program}")

#COURSE SECTIONING
sections = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z','AA','BB','CC','DD','EE','FF','GG','HH','II','JJ','KK','LL','MM','NN','OO','PP','QQ','RR']
cursor.execute("SELECT course_code, COUNT(*) AS code_count FROM initial GROUP BY course_code")
s = cursor.fetchall()
for r in s:
    course_code = r[0]
    count = r[1]
    for n in range(count):
        print(n)
        course_section = sections[n]
        cursor.execute(f"SELECT program, section FROM initial WHERE course_code = '{course_code}' AND course_section = 'NONE' LIMIT 1")
        t = cursor.fetchall() #PANO BA IHANDLE ANG FETCHONE??? HAHAHAH
        print(t, course_section, course_code)
        for u in t:
            program = u[0]
            section = u[1]
            cursor.execute(f"UPDATE initial SET course_section = '{course_section}' WHERE program = '{program}' AND section ='{section}' AND course_code = '{course_code}'")
            conn.commit()

#COURSE COMBINATION
cursor.execute("SELECT * FROM initial WHERE size = 'S'")
c = cursor.fetchall()
for b in c:
    id1 = b[0]
    course_code = b[1]
    course_section = b[2]
    year1 = b[5]
    department = b[6] #need id entry
    type = b[8]
    cursor.execute(f"SELECT * FROM initial WHERE id = {id1} AND partnered IS NULL") #need icheck kung nageexist pa kasi ipara sa partner partner
    a = cursor.fetchall()
    if a:
        cursor.execute(f"SELECT * FROM initial WHERE course_code LIKE '%{course_code}%' AND department = '{department}' AND size = 'M'AND type = '{type}'LIMIT 1")
        e = cursor.fetchall()
        if e:
            for i in e:
                course_section = i[2]
                id2 = i[0]
                year2 = i[5]
                id_follow = min(id1,id2)
                id_to_be_updated = max(id1,id2)
                cursor.execute(f"SELECT course_section FROM initial where id = {id_follow}")
                k = cursor.fetchall()
                course_section_final = k[0][0]
                print(course_section_final)
                cursor.execute(f"UPDATE initial SET course_section = '{course_section_final}', size = 'L', partnered = 'YES' WHERE id = {id_to_be_updated}")
                cursor.execute(f"UPDATE initial SET size = 'L', partnered = 'YES' WHERE id = {id_follow}")
                conn.commit()            
        else:
            cursor.execute(f"SELECT * FROM initial WHERE course_code LIKE '%{course_code}%' AND department = '{department}' AND size = 'S' AND type = '{type}' AND id != {id1} LIMIT 1")
            f = cursor.fetchall()
            if f:
                for i in f:
                    id2 = i[0]
                    program2 = i[3]
                    section2 = i[4]
                    year2 = i[5]
                    id_follow = min(id1,id2)
                    id_to_be_updated = max(id1,id2)
                    cursor.execute(f"SELECT course_section FROM initial where id = {id_follow}")
                    k = cursor.fetchall()
                    course_section_final = k[0][0]
                    print(course_section_final)
                    cursor.execute(f"UPDATE initial SET course_section = '{course_section_final}', size = 'L', partnered = 'YES' WHERE id = {id_to_be_updated}")
                    cursor.execute(f"UPDATE initial SET size = 'L', partnered = 'YES' WHERE id = {id_follow}")
                    conn.commit()  
            else:
                continue            
    else:
        continue
    

    
                    
            
            
        
    



  



            
    
    