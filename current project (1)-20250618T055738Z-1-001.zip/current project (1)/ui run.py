from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
import sys
from PyQt5.uic import loadUiType

ui, _ = loadUiType(r'C:\Users\cielo\Downloads\current project\sched.ui')

class MainApp(QMainWindow, ui):
    def __init__(self):  
        QMainWindow.__init__(self)
        self.setupUi(self)
        
        self.tabWidget.setCurrentIndex(0)
        self.tabWidget.tabBar().setVisible(False)
        self.menubar.setVisible(False)
        self.b1.clicked.connect(self.login)
        
        
        
    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Return or event.key() == Qt.Key_Enter:
            self.login()
      
    #login   
    def login(self):
        un = self.a1.text()
        pw = self.a2.text()
        if (un == 'admin' and pw == 'registrar'):
            self.menubar.setVisible(True)
            self.tabWidget.setCurrentIndex(1)
        else:
            QMessageBox.information(self,'Schedule Optimizer','Invalid login')
            
        
        
    #department-programs
    
            
def main():
    app = QApplication(sys.argv)
    window = MainApp()
    window.show()
    app.exec_()
    
if __name__ == '__main__':
    main()
