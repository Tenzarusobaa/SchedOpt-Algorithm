#pwede to ias one function
import mysql.connector
from assignment_functions import *

conn = mysql.connector.connect(
    user='root',
    password='',
    database='adzu',
    host='localhost'
)
cursor = conn.cursor()

#di muna isali bsn
cursor.execute("DELETE FROM initial WHERE program = 'BSN'")
cursor.execute("DROP TABLE initial_backup")
cursor.execute("CREATE TABLE IF NOT EXISTS initial_backup AS SELECT * FROM initial")
cursor.execute("DELETE FROM assignment")
conn.commit()


program_year_section_assigned = {}
room_day_timeslots = {}      

#PE
cursor.execute("SELECT DISTINCT course_code, course_section FROM initial WHERE type = 'PE'")   
k = cursor.fetchall()
for l in k:
    print(l)
    assigned = False
    course_code = l[0]
    course_section = l[1]
    timeslots, days = get_timeslots_days(type = 'PE')
    room_list = get_room(cursor, size = 'L' ,type = 'PE', dep_assigned = 'NONE')
    print(room_list)
    for room in room_list:
        if assigned:
            break
        for day in days:
            nextday = day
            if assigned:
                break
            for timeslot in timeslots:
                check1, check2 = pe_checktimes(timeslot)
                room_combi_avail = check_dict(room_day_timeslots, room, day, nextday, check1 = timeslot, check2 = timeslot)
                if assigned:
                    break
                elif room_combi_avail:
                    student_available = student_avail_remove(cursor, course_code, course_section, day, nextday, check1, check2, program_year_section_assigned, conn)
                    if student_available:
                        removal_db("room_schedule", "room", room, cursor, conn, day, nextday, check1 = timeslot, check2 = timeslot) #kasi dapat separate timeslots ng mpcc para sa overlap di matanggal entirely
                        appending(room_day_timeslots, room, day, nextday, check1, check2)
                        for_printing_assignment(cursor, conn, day, course_code, course_section, nextday, timeslot, room)
                        assigned = True
                        break
                    else:
                        continue    
                else:
                    continue 

#NSTP
cursor.execute("SELECT DISTINCT course_code, course_section, size FROM initial WHERE course_code LIKE '%NSTP%'")   
k = cursor.fetchall()
for l in k:
    print(l)
    assigned = False
    course_code = l[0]
    course_section = l[1]
    size = l[2]
    timeslots, days = get_timeslots_days(type = 'NSTP')
    room_list = get_room(cursor, size ,type = 'LEC', dep_assigned = 'NONE')
    print(room_list)
    for day in days:
        if assigned:
            break
        for room in room_list:
            if assigned:
                break
            for timeslot in timeslots:
                check1, check2 = lec2_checktimes(timeslot)
                nextday = day
                room_combi_avail = check_dict(room_day_timeslots, room, day, nextday, check1, check2)
                if assigned:
                    break
                elif room_combi_avail:
                    student_available = student_avail_remove(cursor, course_code, course_section, day, nextday, check1, check2, program_year_section_assigned, conn)
                    if student_available:
                        removal_db("room_schedule", "room", room, cursor, conn, day, nextday, check1, check2)
                        appending(room_day_timeslots, room, day, nextday, check1, check2)
                        for_printing_assignment(cursor, conn, day, course_code, course_section, nextday, timeslot, room)
                        assigned = True
                        break
                    else:
                        continue
                else:
                    continue
                    
#LEC2 3HRX2
cursor.execute("SELECT DISTINCT course_code, course_section, size FROM initial WHERE type ='LEC2'")   
k = cursor.fetchall()
for l in k:
    print(l)
    assigned = False
    course_code = l[0]
    course_section = l[1]
    size = l[2]
    timeslots, days = get_timeslots_days(type = 'LEC2')
    room_list = get_room(cursor, size ,type = 'LEC', dep_assigned = 'NONE')
    print(room_list)
    for day in days:
        if assigned:
            break
        for room in room_list:
            if assigned:
                break
            for timeslot in timeslots:
                check1, check2 = lec2_checktimes(timeslot)
                nextday = get_nextday(day)
                room_combi_avail = check_dict(room_day_timeslots, room, day, nextday, check1, check2)
                if assigned:
                    break 
                elif room_combi_avail:
                    student_available = student_avail_remove(cursor, course_code, course_section, day, nextday, check1, check2, program_year_section_assigned, conn)
                    if student_available:
                        removal_db("room_schedule", "room", room, cursor, conn, day, nextday, check1, check2)
                        appending(room_day_timeslots, room, day, nextday, check1, check2)
                        for_printing_assignment(cursor, conn, day, course_code, course_section, nextday, timeslot, room)
                        assigned = True
                        break
                    else:
                        continue
                else:
                    continue
       
cursor.execute("SELECT DISTINCT course_code, course_section, size, department FROM initial WHERE type ='LEC'") 
print("here na")  
k = cursor.fetchall()
for l in k:
    print(l)
    assigned = False
    course_code = l[0]
    course_section = l[1]
    department = l[3]
    size = l[2]
    timeslots, days = get_timeslots_days(type = 'LEC')
    room_list = get_room(cursor, size ,type = 'LEC', dep_assigned = department)
    if room_list:
        room_list = room_list
    else:
        room_list = get_room(cursor, size ,type = 'LEC', dep_assigned = 'NONE')
    print(room_list)
    for room in room_list:
        if assigned:
            break
        for day in days:
            if assigned:
                break
            for timeslot in timeslots:
                check1 = timeslot
                check2 = timeslot
                nextday = get_nextday(day)
                room_combi_avail = check_dict(room_day_timeslots, room, day, nextday, check1, check2)
                print(room_combi_avail)
                if assigned:
                    break
                elif room_combi_avail:#here na
                    student_available = student_avail_remove(cursor, course_code, course_section, day, nextday, check1, check2, program_year_section_assigned, conn)
                    if student_available:
                        removal_db("room_schedule", "room", room, cursor, conn, day, nextday, check1, check2)
                        appending(room_day_timeslots, room, day, nextday, check1, check2)
                        for_printing_assignment(cursor, conn, day, course_code, course_section, nextday, timeslot, room)
                        assigned = True
                        break
                    else:
                        continue
                else:
                    continue
    if not assigned:
        a = wednesday_consecutive(conn, cursor, course_code, course_section, room_list, program_year_section_assigned, room_day_timeslots)
        if a:
            assigned = True     
        else:
            b = adjust_roomsize (conn, cursor, size, course_code, course_section, program_year_section_assigned, room_day_timeslots)
            if b:
                assigned = True
            else:
                print("course not assigned")
                
                
                
            
            
