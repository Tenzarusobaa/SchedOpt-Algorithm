<?xml version="1.0" encoding="UTF-8"?>
<ui version="4.0">
 <class>MainWindow</class>
 <widget class="QMainWindow" name="MainWindow">
  <property name="geometry">
   <rect>
    <x>0</x>
    <y>0</y>
    <width>792</width>
    <height>639</height>
   </rect>
  </property>
  <property name="sizePolicy">
   <sizepolicy hsizetype="Expanding" vsizetype="Expanding">
    <horstretch>0</horstretch>
    <verstretch>0</verstretch>
   </sizepolicy>
  </property>
  <property name="windowTitle">
   <string>MainWindow</string>
  </property>
  <widget class="QWidget" name="centralwidget">
   <property name="enabled">
    <bool>true</bool>
   </property>
   <property name="sizePolicy">
    <sizepolicy hsizetype="Expanding" vsizetype="Expanding">
     <horstretch>0</horstretch>
     <verstretch>0</verstretch>
    </sizepolicy>
   </property>
   <layout class="QVBoxLayout" name="verticalLayout">
    <property name="sizeConstraint">
     <enum>QLayout::SetDefaultConstraint</enum>
    </property>
    <property name="bottomMargin">
     <number>9</number>
    </property>
    <item>
     <widget class="QTabWidget" name="tabWidget">
      <property name="focusPolicy">
       <enum>Qt::NoFocus</enum>
      </property>
      <property name="autoFillBackground">
       <bool>false</bool>
      </property>
      <property name="currentIndex">
       <number>0</number>
      </property>
      <widget class="QWidget" name="tab">
       <property name="sizePolicy">
        <sizepolicy hsizetype="Expanding" vsizetype="Expanding">
         <horstretch>0</horstretch>
         <verstretch>0</verstretch>
        </sizepolicy>
       </property>
       <attribute name="title">
        <string>Login</string>
       </attribute>
       <layout class="QVBoxLayout" name="verticalLayout_2">
        <item>
         <widget class="QLabel" name="label">
          <property name="sizePolicy">
           <sizepolicy hsizetype="Expanding" vsizetype="Expanding">
            <horstretch>0</horstretch>
            <verstretch>0</verstretch>
           </sizepolicy>
          </property>
          <property name="text">
           <string/>
          </property>
          <property name="pixmap">
           <pixmap>../../.designer/backup/Ateneo_de_Zamboanga_University_seal.svg</pixmap>
          </property>
         </widget>
        </item>
        <item>
         <widget class="QLabel" name="label_2">
          <property name="sizePolicy">
           <sizepolicy hsizetype="Expanding" vsizetype="Expanding">
            <horstretch>0</horstretch>
            <verstretch>0</verstretch>
           </sizepolicy>
          </property>
          <property name="styleSheet">
           <string notr="true">font: 12pt &quot;Microsoft Sans Serif&quot;;</string>
          </property>
          <property name="text">
           <string>Username:</string>
          </property>
         </widget>
        </item>
        <item>
         <widget class="QLineEdit" name="a2">
          <property name="sizePolicy">
           <sizepolicy hsizetype="Expanding" vsizetype="Expanding">
            <horstretch>0</horstretch>
            <verstretch>0</verstretch>
           </sizepolicy>
          </property>
          <property name="maximumSize">
           <size>
            <width>16777215</width>
            <height>16777215</height>
           </size>
          </property>
          <property name="echoMode">
           <enum>QLineEdit::Password</enum>
          </property>
         </widget>
        </item>
        <item>
         <widget class="QLabel" name="label_3">
          <property name="sizePolicy">
           <sizepolicy hsizetype="Expanding" vsizetype="Expanding">
            <horstretch>0</horstretch>
            <verstretch>0</verstretch>
           </sizepolicy>
          </property>
          <property name="styleSheet">
           <string notr="true">font: 12pt &quot;Microsoft Sans Serif&quot;;</string>
          </property>
          <property name="text">
           <string>Password:</string>
          </property>
         </widget>
        </item>
        <item>
         <widget class="QLineEdit" name="a1">
          <property name="sizePolicy">
           <sizepolicy hsizetype="Expanding" vsizetype="Expanding">
            <horstretch>0</horstretch>
            <verstretch>0</verstretch>
           </sizepolicy>
          </property>
          <property name="maximumSize">
           <size>
            <width>16777215</width>
            <height>16777215</height>
           </size>
          </property>
         </widget>
        </item>
        <item>
         <widget class="QPushButton" name="b1">
          <property name="sizePolicy">
           <sizepolicy hsizetype="Expanding" vsizetype="Expanding">
            <horstretch>0</horstretch>
            <verstretch>0</verstretch>
           </sizepolicy>
          </property>
          <property name="maximumSize">
           <size>
            <width>500</width>
            <height>16777215</height>
           </size>
          </property>
          <property name="styleSheet">
           <string notr="true">background-color: rgb(0, 0, 127);
color: rgb(255, 255, 255);
font: 12pt &quot;Microsoft Sans Serif&quot;;</string>
          </property>
          <property name="text">
           <string>Login</string>
          </property>
          <property name="autoDefault">
           <bool>false</bool>
          </property>
          <property name="default">
           <bool>true</bool>
          </property>
         </widget>
        </item>
       </layout>
      </widget>
      <widget class="QWidget" name="tab_2">
       <property name="sizePolicy">
        <sizepolicy hsizetype="Expanding" vsizetype="Expanding">
         <horstretch>0</horstretch>
         <verstretch>0</verstretch>
        </sizepolicy>
       </property>
       <attribute name="title">
        <string>Home</string>
       </attribute>
       <widget class="QWidget" name="gridLayoutWidget">
        <property name="geometry">
         <rect>
          <x>190</x>
          <y>100</y>
          <width>451</width>
          <height>271</height>
         </rect>
        </property>
        <layout class="QGridLayout" name="gridLayout">
         <item row="0" column="0">
          <layout class="QHBoxLayout" name="horizontalLayout">
           <item>
            <layout class="QVBoxLayout" name="verticalLayout_3"/>
           </item>
          </layout>
         </item>
        </layout>
       </widget>
      </widget>
      <widget class="QWidget" name="tab_3">
       <property name="sizePolicy">
        <sizepolicy hsizetype="Expanding" vsizetype="Expanding">
         <horstretch>0</horstretch>
         <verstretch>0</verstretch>
        </sizepolicy>
       </property>
       <attribute name="title">
        <string>Department-programs</string>
       </attribute>
      </widget>
      <widget class="QWidget" name="tab_4">
       <attribute name="title">
        <string>Students Sections</string>
       </attribute>
      </widget>
      <widget class="QWidget" name="tab_5">
       <attribute name="title">
        <string>Classrooms</string>
       </attribute>
      </widget>
      <widget class="QWidget" name="tab_6">
       <attribute name="title">
        <string>Lab rooms</string>
       </attribute>
      </widget>
      <widget class="QWidget" name="tab_7">
       <attribute name="title">
        <string>Create/View Scheds</string>
       </attribute>
      </widget>
      <widget class="QWidget" name="tab_8">
       <attribute name="title">
        <string>Edit Scheds</string>
       </attribute>
      </widget>
     </widget>
    </item>
   </layout>
  </widget>
  <widget class="QMenuBar" name="menubar">
   <property name="geometry">
    <rect>
     <x>0</x>
     <y>0</y>
     <width>792</width>
     <height>26</height>
    </rect>
   </property>
   <property name="styleSheet">
    <string notr="true">background-color: rgb(0, 0, 127);
color: rgb(255, 255, 255);
font: 12pt &quot;Microsoft Sans Serif&quot;;</string>
   </property>
   <widget class="QMenu" name="menuStudents">
    <property name="title">
     <string>Student Data</string>
    </property>
    <addaction name="actiondepartments"/>
    <addaction name="actionStudent_Sections"/>
   </widget>
   <widget class="QMenu" name="menuRooms">
    <property name="title">
     <string>Room Data</string>
    </property>
    <addaction name="actionBLABLA"/>
    <addaction name="actionLab_rooms"/>
   </widget>
   <widget class="QMenu" name="menuSchedules">
    <property name="title">
     <string>Schedules</string>
    </property>
    <addaction name="actionblaBla"/>
    <addaction name="actionEdit_Adjust_Schedules"/>
   </widget>
   <addaction name="menuStudents"/>
   <addaction name="menuRooms"/>
   <addaction name="menuSchedules"/>
  </widget>
  <widget class="QStatusBar" name="statusbar"/>
  <action name="actiondepartments">
   <property name="text">
    <string>Departments-Programs</string>
   </property>
  </action>
  <action name="actionBLABLA">
   <property name="text">
    <string>Available Classrooms</string>
   </property>
  </action>
  <action name="actionblaBla">
   <property name="text">
    <string>Create/View Schedules</string>
   </property>
  </action>
  <action name="actionStudent_Sections">
   <property name="text">
    <string>Student Sections</string>
   </property>
  </action>
  <action name="actionLab_rooms">
   <property name="text">
    <string>Available Lab rooms</string>
   </property>
  </action>
  <action name="actionEdit_Adjust_Schedules">
   <property name="text">
    <string>Edit/Adjust Schedules</string>
   </property>
  </action>
 </widget>
 <resources/>
 <connections/>
</ui>
