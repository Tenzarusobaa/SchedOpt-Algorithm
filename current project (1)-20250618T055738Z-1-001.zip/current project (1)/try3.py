from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
import sys
from PyQt5.uic import loadUiType

ui, _ = loadUiType(r'C:\Users\cielo\Downloads\current project\sched.ui')

class MainApp(QMainWindow, ui):
    def __init__(self):  
        QMainWindow.__init__(self)
        self.setupUi(self)
        
        self.tabWidget.setCurrentIndex(0)
        self.tabWidget.tabBar().setVisible(False)
        self.menubar.setVisible(False)
        self.b1.clicked.connect(self.login)
        
        # Apply a layout to manage the buttons
        self.setup_layouts()
        
    def setup_layouts(self):
        """Setup layouts to allow buttons to resize with the window."""
        # Create a vertical layout for the login section
        login_layout = QVBoxLayout()
        
        # Add username and password input fields to the layout
        login_layout.addWidget(self.a1)  # Username input
        login_layout.addWidget(self.a2)  # Password input
        
        # Add the login button to the layout
        login_layout.addWidget(self.b1)  # Login button
        
        # Set the layout to a container widget
        login_container = QWidget()
        login_container.setLayout(login_layout)
        
        # Replace the central widget with the login container
        self.centralwidget.setLayout(QVBoxLayout())
        self.centralwidget.layout().addWidget(login_container)
        
    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Return or event.key() == Qt.Key_Enter:
            self.login()
      
    # Login function
    def login(self):
        un = self.a1.text()
        pw = self.a2.text()
        if un == 'admin' and pw == 'registrar':
            self.menubar.setVisible(True)
            self.tabWidget.setCurrentIndex(1)
        else:
            QMessageBox.information(self, 'Schedule Optimizer', 'Invalid login')

def main():
    app = QApplication(sys.argv)
    window = MainApp()
    window.show()
    app.exec_()
    
if __name__ == '__main__':
    main()
