cursor.execute("SELECT DISTINCT course_code, course_section, size FROM initial WHERE type ='LEC2'")   
k = cursor.fetchall()
for l in k:
    print(l)
    assigned = False
    course_code = l[0]
    course_section = l[1]
    size = l[2]
    timeslots, days = get_timeslots_days(type = 'LEC2')
    room_list = get_room(cursor, size ,type = 'LEC', dep_assigned = 'NONE')
    print(room_list)
    for day in days:
        if assigned:
            break
        for room in room_list:
            if assigned:
                break
            for timeslot in timeslots:
                if assigned:
                    break
                check1, check2 = lec2_checktimes(timeslot)
                nextday = get_nextday(day)
                room_combi_avail = check_dict(room_day_timeslots, room, day, nextday, check1, check2)
                if assigned:
                    break 
                elif room_combi_avail:
                    student_available = student_avail_remove(cursor, course_code, course_section, day, nextday, check1, check2, program_year_section_assigned, conn)
                    if student_available:
                        removal_db("room_schedule", "room", room, cursor, conn, day, nextday, check1, check2)
                        appending(room_day_timeslots, room, day, nextday, check1, check2)
                        for_printing_assignment(cursor, conn, day, course_code, course_section, nextday, timeslot, room)
                        assigned = True
                        break
                    else:
                        continue
                else:
                    continue