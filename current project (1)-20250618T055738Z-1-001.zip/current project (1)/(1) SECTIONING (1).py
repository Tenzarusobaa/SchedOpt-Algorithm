import mysql.connector
import math

conn = mysql.connector.connect(
    user='root',
    password='',
    database='adzu',
    host='localhost'
)
cursor = conn.cursor()

cursor.execute("DELETE FROM student_sections")
conn.commit()
cursor.execute("SELECT * FROM forecasted")
initial = cursor.fetchall()
sections = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z','AA','BB','CC','DD','EE','FF','GG','HH','II','JJ','KK','LL','MM','NN','OO','PP','QQ','RR']

#dapat nagiinput din sila data per program and corresping dept nun
def get_number(program):
    cursor.execute(f"SELECT priority_number FROM department_data WHERE program = '{program}'")
    x = cursor.fetchall()
    priority_number = x[0][0]
    return priority_number
    

for row in initial:
    program = row[0].replace(" ", "").upper()
    year =row[1]
    total_enrolled_count = row[2]
    if total_enrolled_count <= 40:
        section = 'A'
        print(program, total_enrolled_count,year, section)
        if total_enrolled_count <=10:
            size = 'S'
        elif total_enrolled_count <=20:
            size = 'M'
        else:
            size = 'L'
        priority_number = get_number(program)
        cursor.execute(f"INSERT INTO student_sections (program, year, section, size, priority_number) VALUES ('{program}', {year}, '{section}','{size}',{priority_number})")
        conn.commit()
    else:  
        print(f"total enrolled: {total_enrolled_count}")
        iterations = math.ceil(total_enrolled_count/35)
        print(iterations)
        for n in range(iterations):
            section = sections[n]
            priority_number = get_number(program)
            cursor.execute(f"INSERT INTO student_sections (program, year, section, size, priority_number) VALUES ('{program}', {year}, '{section}','L',{priority_number})")
            conn.commit()

conn.close()