import mysql.connector

# Connect to the MySQL database
conn = mysql.connector.connect(
    user='root',
    password='',
    database='adzu',
    host='localhost'
)
cursor = conn.cursor()

# Create the unified timetable table
cursor.execute("""
    CREATE TABLE IF NOT EXISTS timetable (
        room_name VARCHAR(255),
        day VARCHAR(50),
        timeslot VARCHAR(50),
        course_assigned TEXT
    )
""")
cursor.execute("DELETE FROM timetable")  # Clear the table before repopulating
conn.commit()

# Define timeslots and mappings for multi-slot periods
times = ['8:00-9:20', '9:30-10:50', '11:00-12:20', '12:30-1:50', '2:00-3:20', '3:30-4:30', '4:30-5:50', '6:00-7:20']
timeslot_mapping = {
    '8:00-10:50': ['8:00-9:20', '9:30-10:50'],
    '12:30-3:20': ['12:30-1:50', '2:00-3:20'],
    '4:30-7:20':['4:30-5:50', '6:00-7:20']
    # Add more mappings if necessary
}

# Day abbreviation to full name mapping
day_mapping = {
    'M': ['Monday'],
    'T': ['Tuesday'],
    'W': ['Wednesday'],
    'TH': ['Thursday'],
    'Th': ['Thursday'],
    'F': ['Friday'],
    'S': ['Saturday'],
    'MTH': ['Monday', 'Thursday'],
    'MTh': ['Monday', 'Thursday'],
    'WS': ['Wednesday', 'Saturday'],
    'TF': ['Tuesday', 'Friday'],# Multi-day mapping
}

# Fetch data from the assignment table
cursor.execute("""
    SELECT course_code_section, program_year_section, room, day, timeslot
    FROM assignment WHERE room != 'KIOSK' AND room NOT LIKE '%MPCC%'
""")
results = cursor.fetchall()

# Populate the unified timetable table
for row in results:
    course_code_section, program_year_section, room, day, timeslot = row
    course_assigned = f"{course_code_section}, ({program_year_section})"

    # Map day abbreviation to full day name(s)
    full_days = day_mapping.get(day, None)
    if not full_days:
        print(f"Unknown day abbreviation: {day}")
        continue

    # Handle timeslot splitting
    if timeslot in timeslot_mapping:
        smaller_slots = timeslot_mapping[timeslot]
        course_assigned = f"({timeslot})-{course_code_section}, ({program_year_section})"
        for slot in smaller_slots:
            for full_day in full_days:  # Insert for each day in the list
                cursor.execute("""
                    INSERT INTO timetable (room_name, day, timeslot, course_assigned, program_year_section)
                    VALUES (%s, %s, %s, %s, %s)
                """, (room, full_day, slot, course_assigned, program_year_section))
                conn.commit()
    else:
        # Directly insert for regular timeslots
        for full_day in full_days:  # Insert for each day in the list
            cursor.execute("""
                INSERT INTO timetable (room_name, day, timeslot, course_assigned, program_year_section)
                VALUES (%s, %s, %s, %s, %s)
            """, (room, full_day, timeslot, course_assigned, program_year_section))
            conn.commit()

# Close the database connection
cursor.close()
conn.close()
